# British Birds Expedition — Full Local / Codespaces Version

This is the **full original-style app**, not the stripped GitHub Pages demo. It keeps the Express server, Gemini-powered AI routes, generated/cached bird images and sounds, assets, the field guide, equipment, action cards, and the richer round structure.

## iPad development route

The iPad does not run Node/Vite locally. Use GitHub Codespaces in Safari or Chrome on the iPad. Codespaces runs Node in the cloud and forwards the app port back to your browser.

1. Upload this project folder to GitHub, or replace the current stripped repo contents with this folder.
2. Open the repo on GitHub.
3. Tap **Code → Codespaces → Create codespace on main**.
4. Wait for `npm install` to finish.
5. In the Codespaces terminal, run:

```bash
npm run dev
```

6. Open the forwarded **3000** port from the **Ports** tab.

## Gemini API key

Create a `.env.local` file in Codespaces or on your Windows machine:

```bash
GEMINI_API_KEY="your_key_here"
```

Do not commit `.env.local` or real API keys to GitHub.

The app has graceful fallbacks for AI image/audio generation failures, but the AI routes need a valid key for the full effect.

## Windows/local route later

On a Windows PC:

```bash
npm install
npm run dev
```

Then on the same Wi-Fi, open the Windows machine IP from your iPad, for example:

```text
http://192.168.1.25:3000
```

You can also use AnyDesk from the iPad to control the Windows machine, but opening the local web address in Safari/Chrome will usually feel smoother.

## Why this version exists

The GitHub Pages/static version removed too much: AI, assets, original gameplay structure, and server routes. This version is intended to restore the original app and then fix bugs carefully without downgrading the game.
