import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import fs from "fs";
import { BIRD_DATASET } from "./src/data/birds";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Initialize the GoogleGenAI client with required header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Cache map to store generated base64 strings so we don't exceed rate-limits
const birdImageCache = new Map<string, string>();

// Serve JSON body parsing middleware
app.use(express.json());

// Custom express route to serve dynamically generated or cached bird images
app.get("/images/birds/:filename", (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(process.cwd(), "public", "images", "birds", filename);
  if (fs.existsSync(filePath)) {
    return res.sendFile(filePath);
  }
  return res.status(404).send("Image not found on disk");
});

// Custom express route to serve dynamically generated or cached actual bio-acoustic bird sounds
app.get("/sounds/birds/:filename", (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(process.cwd(), "public", "sounds", "birds", filename);
  if (fs.existsSync(filePath)) {
    res.setHeader("Content-Type", "audio/wav");
    return res.sendFile(filePath);
  }
  return res.status(404).send("Sound file not found on disk");
});

const birdSoundCache = new Map<string, string>();

// API route: Generates deep realistic biological bird calls using Gemini Lyria or returns from filesystem disk
app.get("/api/birds/sound", async (req, res) => {
  const birdName = req.query.name as string;
  if (!birdName) {
    return res.status(400).json({ error: "Name parameter is required" });
  }

  // Find bird to locate its ID
  const bird = BIRD_DATASET.find(b => b.name.toLowerCase() === birdName.toLowerCase());
  const birdId = bird ? bird.id : "unknown";

  const publicDir = path.join(process.cwd(), "public", "sounds", "birds");
  
  if (birdId && birdId !== "unknown") {
    const filePath = path.join(publicDir, `${birdId}.wav`);
    if (fs.existsSync(filePath)) {
      return res.json({ url: `/sounds/birds/${birdId}.wav`, source: "disk" });
    }
  }

  const cachedUrl = birdSoundCache.get(birdName);
  if (cachedUrl) {
    return res.json({ url: cachedUrl, source: "memory" });
  }

  try {
    console.log(`Generating authentic bio-acoustic bird calls for real avian species: "${birdName}" using Gemini Lyria...`);

    // Call Google AI Lyria model for high-fidelity audio generation (music and clips)
    const responseStream = await ai.models.generateContentStream({
      model: "lyria-3-clip-preview",
      contents: `Generate a 6-second continuous authentic biological bird call, chirps, and vocalizations for the specific real-life wild bird species: "${birdName}". Beautiful raw nature outdoor soundscape. Absolutely no synthesized tones, no music instruments, no hums, no background speech.`,
      config: {
        responseModalities: ["AUDIO"],
      },
    });

    let audioBase64 = "";
    for await (const chunk of responseStream) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          audioBase64 += part.inlineData.data;
        }
      }
    }

    if (audioBase64) {
      if (!fs.existsSync(publicDir)) {
        fs.mkdirSync(publicDir, { recursive: true });
      }
      
      const filePath = path.join(publicDir, `${birdId}.wav`);
      fs.writeFileSync(filePath, Buffer.from(audioBase64, "base64"));
      
      const soundUrl = `/sounds/birds/${birdId}.wav`;
      birdSoundCache.set(birdName, soundUrl);
      
      console.log(`Successfully generated and cached real biological call for ${birdName} to disk!`);
      return res.json({ url: soundUrl, source: "gemini-lyria" });
    }

    throw new Error("No audio payload returned from Gemini Lyria model stream");
  } catch (err) {
    console.warn(`Gemini sound generation skipped for "${birdName}" (Either API key lacks Lyria access or region is unsupported). Falling back cleanly:`, err);
    return res.json({ url: null, error: "AI sound generation currently unavailable. Falling back beautifully to custom biophonic synth." });
  }
});

// Clean up base64 payload to ensure standard chunk padding length (% 4 === 0)
// and remove any illegal whitespace characters which can crash WebKit's native base64 parser.
function cleanBase64(data: string): string {
  if (!data) return "";
  let clean = data.replace(/\s+/g, "");
  if (clean.includes("base64,")) {
    clean = clean.split("base64,")[1];
  }
  // Remove any remaining illegal characters
  clean = clean.replace(/[^A-Za-z0-9+/=]/g, "");
  // Pad with '=' if length is not a multiple of 4
  while (clean.length % 4 !== 0) {
    clean += "=";
  }
  return clean;
}

// Helper function: Generates a base64 image string for a bird species trying multiple distinct models
async function generateBirdImageBase64(birdName: string): Promise<string> {
  const errors: string[] = [];

  // Try 1: gemini-3.1-flash-image (Most recent high-performance model)
  try {
    console.log(`[ImageGen] Trying gemini-3.1-flash-image for bird: "${birdName}" (512px optimized)`);
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-image",
      contents: {
        parts: [
          {
            text: `A detailed, realistic, biological scientific color field-guide illustration of the real living avian BIRD species: "${birdName}". This image MUST depict an organic wild bird with layers of feathers, realistic avian wings, bird eyes, and clawed feet. Perched calmly on a vintage woodland twig or mossy stone branch. Isolated design on a clean, solid, soft cream-colored natural-paper studies background. Strictly NO mechanical components, NO cars, NO motor vehicles, NO artificial wheels, NO labels, and NO letters or borders in the drawing.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "512px"
        },
      },
    });

    if (response?.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData?.data) {
          console.log(`[ImageGen] Successfully generated "${birdName}" via gemini-3.1-flash-image!`);
          return cleanBase64(part.inlineData.data);
        }
      }
    }
  } catch (err: any) {
    console.warn(`[ImageGen] gemini-3.1-flash-image failed:`, err.message || err);
    errors.push(`gemini-3.1-flash-image: ${err.message || err}`);
  }

  // Try 2: imagen-3.0-generate-002 (Official GenAI SDK method)
  try {
    console.log(`[ImageGen] Trying imagen-3.0-generate-002 for bird: "${birdName}"`);
    const imgResponse = await ai.models.generateImages({
      model: "imagen-3.0-generate-002",
      prompt: `A detailed, realistic, biological scientific color field-guide illustration of the real living avian BIRD species: "${birdName}". organic wild bird with layers of feathers, realistic avian wings, bird eyes, and clawed feet. Perched calmly on a vintage woodland twig or mossy stone branch. Isolated design on a clean, solid, soft cream-colored natural-paper studies background. Strictly NO mechanical components, NO cars, NO motor vehicles, NO artificial wheels, NO labels, and NO letters or borders in the drawing.`,
      config: {
        numberOfImages: 1,
        outputMimeType: "image/jpeg",
        aspectRatio: "1:1",
      },
    });

    const base64Data = imgResponse?.generatedImages?.[0]?.image?.imageBytes;
    if (base64Data) {
      console.log(`[ImageGen] Successfully generated "${birdName}" via imagen-3.0-generate-002!`);
      return cleanBase64(base64Data);
    }
  } catch (err: any) {
    console.warn(`[ImageGen] imagen-3.0-generate-002 failed:`, err.message || err);
    errors.push(`imagen-3.0-generate-002: ${err.message || err}`);
  }

  // Try 3: gemini-2.5-flash-image
  try {
    console.log(`[ImageGen] Trying gemini-2.5-flash-image for bird: "${birdName}" (512px optimized)`);
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            text: `A detailed, realistic, biological scientific color field-guide illustration of the real living avian BIRD species: "${birdName}". This image MUST depict an organic wild bird with layers of feathers, realistic avian wings, bird eyes, and clawed feet. Perched calmly on a vintage woodland twig or mossy stone branch. Isolated design on a clean, solid, soft cream-colored natural-paper studies background. Strictly NO mechanical components, NO cars, NO motor vehicles, NO artificial wheels, NO labels, and NO letters or borders in the drawing.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "512px"
        },
      },
    });

    if (response?.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData?.data) {
          console.log(`[ImageGen] Successfully generated "${birdName}" via gemini-2.5-flash-image!`);
          return cleanBase64(part.inlineData.data);
        }
      }
    }
  } catch (err: any) {
    console.warn(`[ImageGen] gemini-2.5-flash-image failed:`, err.message || err);
    errors.push(`gemini-2.5-flash-image: ${err.message || err}`);
  }

  throw new Error(`All bird illustration generation models failed. Errors: ${errors.join("; ")}`);
}

// Helper function: Generates a base64 player avatar image trying multiple distinct models
async function generateAvatarImageBase64(name: string, gender: string): Promise<string> {
  const errors: string[] = [];

  // Try 1: gemini-3.1-flash-image (Most recent high-performance model)
  try {
    console.log(`[AvatarGen] Trying gemini-3.1-flash-image for player: "${name}" (${gender}) (512px optimized)`);
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-image",
      contents: {
        parts: [
          {
            text: `A vibrant, highly detailed, beautifully polished 3D CGI cartoon movie character portrait of a friendly British birdwatcher/explorer and ornithologist explorer named "${name}". Gender appearance: ${gender}. Style: Charming Pixar or Disney 3D character style, cute facial expressions, soft warm dramatic photographic studio lighting, wearing a stylish vintage explorer hat or field cap and outdoor adventurer gear. Warm blurred soft forest background, solid, elegant color tones. Perfect smooth digital rendering, centered composition. Close-up profile avatar.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "512px"
        },
      },
    });

    if (response?.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData?.data) {
          console.log(`[AvatarGen] Successfully generated avatar for player: "${name}" via gemini-3.1-flash-image!`);
          return cleanBase64(part.inlineData.data);
        }
      }
    }
  } catch (err: any) {
    console.warn(`[AvatarGen] gemini-3.1-flash-image failed:`, err.message || err);
    errors.push(`gemini-3.1-flash-image: ${err.message || err}`);
  }

  // Try 2: imagen-3.0-generate-002
  try {
    console.log(`[AvatarGen] Trying imagen-3.0-generate-002 for player: "${name}" (${gender})`);
    const imgResponse = await ai.models.generateImages({
      model: "imagen-3.0-generate-002",
      prompt: `A vibrant, highly detailed, beautifully polished 3D CGI cartoon movie character portrait of a friendly British birdwatcher/explorer and ornithologist explorer named "${name}". Gender appearance: ${gender}. Style: Charming Pixar or Disney 3D character style, cute facial expressions, soft warm dramatic photographic studio lighting, wearing a stylish vintage explorer hat or field cap and outdoor adventurer gear. Warm blurred soft forest background, solid, elegant color tones. Perfect smooth digital rendering, centered composition. Close-up profile avatar.`,
      config: {
        numberOfImages: 1,
        outputMimeType: "image/jpeg",
        aspectRatio: "1:1",
      },
    });

    const base64Data = imgResponse?.generatedImages?.[0]?.image?.imageBytes;
    if (base64Data) {
      console.log(`[AvatarGen] Successfully generated avatar for player: "${name}" via imagen-3.0-generate-002!`);
      return cleanBase64(base64Data);
    }
  } catch (err: any) {
    console.warn(`[AvatarGen] imagen-3.0-generate-002 failed:`, err.message || err);
    errors.push(`imagen-3.0-generate-002: ${err.message || err}`);
  }

  // Try 3: gemini-2.5-flash-image
  try {
    console.log(`[AvatarGen] Trying gemini-2.5-flash-image for player: "${name}" (${gender}) (512px optimized)`);
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            text: `A vibrant, highly detailed, beautifully polished 3D CGI cartoon movie character portrait of a friendly British birdwatcher/explorer and ornithologist explorer named "${name}". Gender appearance: ${gender}. Style: Charming Pixar or Disney 3D character style, cute facial expressions, soft warm dramatic photographic studio lighting, wearing a stylish vintage explorer hat or field cap and outdoor adventurer gear. Warm blurred soft forest background, solid, elegant color tones. Perfect smooth digital rendering, centered composition. Close-up profile avatar.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "512px"
        },
      },
    });

    if (response?.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData?.data) {
          console.log(`[AvatarGen] Successfully generated avatar for player: "${name}" via gemini-2.5-flash-image!`);
          return cleanBase64(part.inlineData.data);
        }
      }
    }
  } catch (err: any) {
    console.warn(`[AvatarGen] gemini-2.5-flash-image failed:`, err.message || err);
    errors.push(`gemini-2.5-flash-image: ${err.message || err}`);
  }

  throw new Error(`All avatar generation models failed. Errors: ${errors.join("; ")}`);
}

// API route: Generates a high-quality scientific bird illustration using Gemini or returns from cache
app.get("/api/birds/image", async (req, res) => {
  const birdName = req.query.name as string;
  if (!birdName) {
    return res.status(400).json({ error: "Name parameter is required" });
  }

  // Find bird to locate its ID
  const bird = BIRD_DATASET.find(b => b.name.toLowerCase() === birdName.toLowerCase());
  const birdId = bird ? bird.id : null;

  // Check if image already exists in public/images/birds/
  const publicDir = path.join(process.cwd(), "public", "images", "birds");
  if (birdId) {
    const filePath = path.join(publicDir, `${birdId}.png`);
    if (fs.existsSync(filePath)) {
      return res.json({ url: `/images/birds/${birdId}.png` });
    }
  }

  const cachedUrl = birdImageCache.get(birdName);
  if (cachedUrl) {
    return res.json({ url: cachedUrl });
  }

  try {
    const base64Data = await generateBirdImageBase64(birdName);

    if (base64Data) {
      if (birdId) {
        if (!fs.existsSync(publicDir)) {
          fs.mkdirSync(publicDir, { recursive: true });
        }
        const filePath = path.join(publicDir, `${birdId}.png`);
        fs.writeFileSync(filePath, Buffer.from(base64Data, "base64"));
        const imageUrl = `/images/birds/${birdId}.png`;
        birdImageCache.set(birdName, imageUrl);
        return res.json({ url: imageUrl });
      } else {
        const imageUrl = `data:image/png;base64,${base64Data}`;
        birdImageCache.set(birdName, imageUrl);
        return res.json({ url: imageUrl });
      }
    }

    // Default Fallback
    throw new Error("No image data parsed from any image models");

  } catch (error) {
    console.error(`AI image generation completely failed for ${birdName}, utilizing high-quality photo fallback:`, error);
    
    // Fail-safe consistent high-quality fallback based on standard picsum photo seeded by species name
    const seed = birdName.replace(/\s+/g, "").toLowerCase();
    const fallbackUrl = `https://picsum.photos/seed/${seed}/400/400`;
    
    return res.json({ url: fallbackUrl });
  }
});

// API route: Generates a premium 3D CGI explorer character avatar based on player name and gender
app.post("/api/avatar/generate", async (req, res) => {
  const { name, gender } = req.body;
  if (!name) {
    return res.status(400).json({ error: "Name is required" });
  }

  const normalizedGender = gender || "Diverse";

  try {
    const base64Data = await generateAvatarImageBase64(name, normalizedGender);

    if (base64Data) {
      const imageUrl = `data:image/png;base64,${base64Data}`;
      console.log(`Successfully generated AI CGI avatar for player: ${name}!`);
      return res.json({ url: imageUrl });
    }

    throw new Error("No image data parsed from any model");
  } catch (error) {
    console.warn(`AI Avatar generation failed for player "${name}", utilizing high-quality adventurer vector fallback:`, error);
    // Use high quality adventurer design fallback
    const seed = name.replace(/\s+/g, "").toLowerCase();
    const fallbackUrl = `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(seed)}`;
    return res.json({ url: fallbackUrl });
  }
});

// API route: Generates a whimsical Ornithology fun name and CGI Explorer Bio Profile based on Real Name and Sex
app.post("/api/profile/generate", async (req, res) => {
  const { realName, sex } = req.body;
  if (!realName) {
    return res.status(400).json({ error: "Real Name is required" });
  }

  const normalizedSex = sex || "Diverse";

  try {
    console.log(`Generating AI Fun Name and CGI Profile for: "${realName}" (${normalizedSex})...`);

    // Call Gemini 3.5-flash to get structured fun name + bio
    const profileResponse = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Create a whimsical, funny, British birdwatching roleplay explorer name (e.g. prefix + nature/field surname like 'Warden Robinwood' or 'Lady Kestrelshaw') and a cute, highly engaging 1-sentence CGI adventurer bio/profile detailing their field quirks, favorite bird, or odd scientific habits, for a real person named "${realName}" who is of biological sex/gender "${normalizedSex}". Emphasize British field guide studies. Respond in JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            funName: {
              type: Type.STRING,
              description: "A whimsical, funny birdwatcher explorer pseudonym (e.g., 'Captain Tealfeather')."
            },
            cgiProfile: {
              type: Type.STRING,
              description: "A cute, 1-sentence humorous 3D CGI character bio / profile detailing their field quirks."
            }
          },
          required: ["funName", "cgiProfile"]
        }
      }
    });

    let generatedData = { funName: "", cgiProfile: "" };
    try {
      const text = profileResponse.text;
      if (text) {
        let cleanText = text.trim();
        if (cleanText.startsWith("```")) {
          cleanText = cleanText.replace(/^```(?:json)?\n?/i, "").replace(/\n?```$/, "");
        }
        generatedData = JSON.parse(cleanText);
      }
    } catch (e) {
      console.warn("JSON parsing of profile response failed. Raw text:", profileResponse.text, e);
    }

    // Fallbacks if JSON structure was missing/malformed
    if (!generatedData.funName) {
      const prefixes = {
        Male: ["Sir", "Captain", "Inspector", "Warden", "Professor", "Major", "Doctor", "Squire"],
        Female: ["Lady", "Baroness", "Inspector", "Warden", "Professor", "Major", "Doctor", "Countess"],
        Diverse: ["Companion", "Ranger", "Warden", "Professor", "Major", "Doctor", "Explorer"]
      };
      const list = prefixes[normalizedSex as "Male" | "Female" | "Diverse"] || prefixes.Diverse;
      const prefix = list[Math.floor(Math.random() * list.length)];
      const birds = ["Starling", "Hawthorn", "Puffin", "Heron", "Owlsen", "Wrenwood", "Rookshaw", "Mallard"];
      const surname = birds[Math.floor(Math.random() * birds.length)];
      generatedData.funName = `${prefix} ${surname}`;
    }

    if (!generatedData.cgiProfile) {
      generatedData.cgiProfile = `A passionate outdoor specialist equipped with professional binoculars and an immense catalog of customized whistling tactics.`;
    }

    // Now, generate the corresponding 3D CGI Avatar image using our robust multi-model fallback avatar helper
    let avatarUrl = "";
    try {
      const base64Data = await generateAvatarImageBase64(generatedData.funName, normalizedSex);
      if (base64Data) {
        avatarUrl = `data:image/png;base64,${base64Data}`;
      } else {
        throw new Error("No image data parsed from avatar helper");
      }
    } catch (avatarError) {
      console.warn("AI CGI avatar generation during profile generation failed. Using high-quality seeded vector fallback:", avatarError);
      const seed = (generatedData.funName + normalizedSex).replace(/\s+/g, "").toLowerCase();
      avatarUrl = `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(seed)}`;
    }

    return res.json({
      funName: generatedData.funName,
      cgiProfile: generatedData.cgiProfile,
      avatarUrl: avatarUrl
    });

  } catch (error) {
    console.error("Complete character profile summoning failed:", error);
    
    // Total fail-safe fallback
    const fallbackFunName = `Ranger ${realName}`;
    const seed = (fallbackFunName + normalizedSex).replace(/\s+/g, "").toLowerCase();
    const fallbackAvatar = `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(seed)}`;
    const fallbackBio = `An outstanding field researcher registered in the Field Ornithology Guild, always ready for remote pass-and-play matches across the countryside.`;

    return res.json({
      funName: fallbackFunName,
      cgiProfile: fallbackBio,
      avatarUrl: fallbackAvatar
    });
  }
});

// Setting up Vite Middleware / Production static serve
async function setupApp() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Aviary] Server is listening on http://0.0.0.0:${PORT}`);
    console.log(`[Aviary] In Codespaces, open the forwarded ${PORT} port. On a local network, open http://<this-computer-ip>:${PORT} from your iPad.`);
  });
}

setupApp();
