import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import { BIRD_DATASET } from "../src/data/birds";

// Load environment variables (.env)
dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("❌ ERROR: GEMINI_API_KEY environment variable is not defined!");
  process.exit(1);
}

// Initialize GoogleGenAI client with the required user-agent header
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const outputDir = path.join(process.cwd(), "public", "images", "birds");

// Ensure directory exists
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Sleep utility to respect rate limits
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function run() {
  console.log(`🤖 Starting generation of scientific illustrations for ${BIRD_DATASET.length} bird species...`);
  console.log(`📂 Destination: ${outputDir}\n`);

  let successCount = 0;
  let skippedCount = 0;
  let errorCount = 0;

  for (let i = 0; i < BIRD_DATASET.length; i++) {
    const bird = BIRD_DATASET[i];
    const fileName = `${bird.id}.png`;
    const filePath = path.join(outputDir, fileName);

    // Simple cache check to avoid re-generating already existing artwork
    if (fs.existsSync(filePath)) {
      console.log(`[${i + 1}/${BIRD_DATASET.length}] Spared: "${bird.name}" already has an illustration.`);
      skippedCount++;
      continue;
    }

    console.log(`[${i + 1}/${BIRD_DATASET.length}] Generating for "${bird.name}" (${bird.scientificName})...`);

    let attempts = 0;
    let base64Data = "";

    while (attempts < 3) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              {
                text: `A detailed, beautiful, realistic scientific color field-guide illustration of the bird species: "${bird.name}" (scientific name: "${bird.scientificName}"). Crisp plumage colors, elegant natural field posture, isolated on a clean, solid, soft cream-colored natural studies background. Digital painting, clean style, no labels, no text, no margins.`,
              },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1",
            },
          },
        });

        if (response?.candidates?.[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData?.data) {
              base64Data = part.inlineData.data;
              break;
            }
          }
        }

        if (base64Data) {
          break; // Successful generation
        } else {
          throw new Error("Empty image payload from Gemini candidate response parts.");
        }

      } catch (err: any) {
        attempts++;
        console.warn(`  ⚠️ Attempt ${attempts} failed for "${bird.name}": ${err?.message || err}`);
        if (attempts < 3) {
          console.log("  ⏳ Retrying in 4 seconds...");
          await sleep(4000);
        }
      }
    }

    if (base64Data) {
      try {
        fs.writeFileSync(filePath, Buffer.from(base64Data, "base64"));
        console.log(`  ✅ Saved illustration as "${fileName}"`);
        successCount++;
      } catch (writeErr: any) {
        console.error(`  ❌ Failed to write file for "${bird.name}":`, writeErr);
        errorCount++;
      }
    } else {
      console.error(`  ❌ Failed to generate illustration for "${bird.name}" after 3 attempts.`);
      errorCount++;
    }

    // Rate-limiting delay to breathe/prevent hitting the quote limits
    await sleep(2000);
  }

  console.log("\n=================================");
  console.log("Illustration Generation Complete!");
  console.log(`🎉 Successes: ${successCount}`);
  console.log(`⏭️ Skipped: ${skippedCount}`);
  console.log(`⚠️ Errors/Failures: ${errorCount}`);
  console.log("=================================\n");
}

run().catch((err) => {
  console.error("Fatal error during script execution:", err);
  process.exit(1);
});
