import React, { useState } from "react";
import { Player, PlayerGender } from "../types";
import { ExplorerAvatar, ForestLeafIcon } from "./BirdIcons";
import { playUiClick, playUiAward } from "../utils/audio";
import { ROUNDS_SET } from "../data/rounds";
import { drawRandomActionCards } from "../data/actionCards";

interface PlayerSetupProps {
  onComplete: (players: Player[]) => void;
}

export default function PlayerSetup({ onComplete }: PlayerSetupProps) {
  const [numPlayers, setNumPlayers] = useState<number>(2);
  const [players, setPlayers] = useState<Array<{
    realName: string;
    gender: PlayerGender; // Used as biological sex
    name: string; // The "Fun Name"
    seed: number;
    avatarUrl?: string; // CGI Avatar Image
    cgiProfile?: string; // CGI Bio Profile description
  }>>([
    {
      realName: "Robin S.",
      gender: "Diverse",
      name: "Ranger Robin",
      seed: 42,
      cgiProfile: "Armed with ancient field guidebooks and a persistent habit of whistling at wood warblers."
    },
    {
      realName: "Heather M.",
      gender: "Female",
      name: "Baroness Heron",
      seed: 101,
      cgiProfile: "A legendary salt-marsh explorer who tracks migratory wigeon pairs across the coastal mudflats."
    },
    {
      realName: "Jack K.",
      gender: "Male",
      name: "Captain Kestrel",
      seed: 77,
      cgiProfile: "He has spent a decade mapping bird nesting grounds on the craggy peaks of the western highlands."
    },
    {
      realName: "Dana O.",
      gender: "Diverse",
      name: "Doctor Owl",
      seed: 213,
      cgiProfile: "A quiet deep-woods researcher skilled at mimicking twilight owls and locating secret woodpecker holes."
    },
  ]);

  const [loadingProfiles, setLoadingProfiles] = useState<Record<number, boolean>>({});

  const handleGenerateAIProfile = async (index: number) => {
    const player = players[index];
    if (!player.realName.trim()) return;

    setLoadingProfiles((prev) => ({ ...prev, [index]: true }));
    try {
      const response = await fetch("/api/profile/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          realName: player.realName,
          sex: player.gender
        }),
      });

      const data = await response.json();
      if (data) {
        const updated = [...players];
        if (data.funName) updated[index].name = data.funName;
        if (data.cgiProfile) updated[index].cgiProfile = data.cgiProfile;
        if (data.avatarUrl) updated[index].avatarUrl = data.avatarUrl;
        setPlayers(updated);

        // Play procedural audio celebration if possible
        try {
          playUiAward();
        } catch (_) {}
      }
    } catch (e) {
      console.error("Error creating AI profile dossier:", e);
    } finally {
      setLoadingProfiles((prev) => ({ ...prev, [index]: false }));
    }
  };

  const handleSexChange = (index: number, sex: PlayerGender) => {
    const updated = [...players];
    updated[index].gender = sex;
    updated[index].seed = updated[index].seed + 19; // Shifts avatar default look
    setPlayers(updated);
  };

  const handleRealNameChange = (index: number, value: string) => {
    const updated = [...players];
    updated[index].realName = value;
    setPlayers(updated);
  };

  const handleFunNameChange = (index: number, value: string) => {
    const updated = [...players];
    updated[index].name = value;
    setPlayers(updated);
  };

  const handleCgiProfileChange = (index: number, value: string) => {
    const updated = [...players];
    updated[index].cgiProfile = value;
    setPlayers(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalPlayers: Player[] = players.slice(0, numPlayers).map((p, idx) => ({
      id: `p-${idx + 1}`,
      name: p.name.trim() || `Explorer ${idx + 1}`,
      gender: p.gender,
      avatarSeed: p.seed,
      avatarUrl: p.avatarUrl,
      realName: p.realName.trim() || `Player ${idx + 1}`,
      cgiProfile: p.cgiProfile || `An enthusiastic field observer.`,
      score: 0,
      streak: 0,
      gear: {
        binoculars: 1,
        sonic: 1,
        thermal: 1,
        lures: 0,
        shields: 0
      },
      cardsInHand: drawRandomActionCards(4),
      stats: {
        roundsWon: 0,
        birdsCollected: [],
        correctAnswers: 0,
        totalAnswers: 0,
        bestStreak: 0,
      },
    }));
    onComplete(finalPlayers);
  };

  return (
    <div
      className="max-w-4xl mx-auto bg-stone-950/80 backdrop-blur-xl border-2 border-amber-500/30 rounded-3xl p-6 md:p-10 shadow-[0_0_80px_rgba(0,0,0,0.8),inset_0_0_40px_rgba(245,158,11,0.05),0_0_40px_rgba(16,185,129,0.15)] text-white flex flex-col gap-6 relative overflow-hidden"
      id="player-setup-container"
    >
      {/* Immersive Guild Gilded Corner Accents */}
      <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-amber-500/40 rounded-tl-2xl pointer-events-none" />
      <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-amber-500/40 rounded-tr-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-amber-500/40 rounded-bl-2xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-amber-500/40 rounded-br-2xl pointer-events-none" />

      <div className="text-center relative z-10">
        <div className="flex justify-center mb-2">
          <div className="text-amber-400 bg-amber-400/10 p-3 rounded-full border border-amber-400/30">
            <ForestLeafIcon size={44} className="animate-pulse" />
          </div>
        </div>
        <h2 className="font-serif text-3xl md:text-4xl font-black text-white tracking-tight uppercase">
          Ornithologist Registration
        </h2>
        <p className="text-stone-300 text-sm mt-1 max-w-lg mx-auto opacity-90 italic font-serif">
          Introduce your real name and biological sex, then instruct our local Gemini AI model to construct a comical field watchdog persona, a CGI digital avatar representation, and an immersive description dossier!
        </p>
      </div>

      {/* Selector for number of players */}
      <div className="flex flex-col items-center gap-2 bg-stone-900/60 p-4 rounded-2xl border border-emerald-950/30 shadow-inner relative z-10">
        <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold font-mono">
          Establish Active Player Volume
        </span>
        <div className="flex gap-4 mt-1">
          {[2, 3, 4].map((num) => (
            <button
              key={num}
              type="button"
              onClick={() => {
                playUiClick();
                setNumPlayers(num);
              }}
              className={`px-5 py-2.5 rounded-xl text-xs uppercase font-black tracking-widest transition-all duration-300 transform cursor-pointer border-b-4 ${
                numPlayers === num
                  ? "bg-amber-500 text-black border-amber-700 shadow-lg scale-110"
                  : "bg-emerald-900/20 hover:bg-emerald-900/40 text-emerald-200 border-emerald-950/60 hover:text-white"
              }`}
            >
              {num} Players
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
          {players.slice(0, numPlayers).map((player, index) => (
            <div
              key={index}
              className="bg-stone-900/60 border border-emerald-900/30 rounded-2xl p-5 flex flex-col gap-4 transition-all hover:border-amber-500/20 hover:bg-stone-900/80"
            >
              {/* Top Details: Info and Photo Row */}
              <div className="flex gap-4 items-start">
                {/* Left Column: Explorer avatar preview */}
                <div className="flex flex-col items-center gap-1.5 min-w-[90px]">
                  <div className="p-1 rounded-full bg-stone-950 border-2 border-emerald-500/40 relative overflow-hidden">
                    {loadingProfiles[index] && (
                      <div className="absolute inset-0 bg-black/75 rounded-full flex flex-col items-center justify-center z-20">
                        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-1" />
                        <span className="text-[8px] uppercase tracking-wider text-amber-400 font-mono font-bold animate-pulse">Summoning...</span>
                      </div>
                    )}
                    <ExplorerAvatar
                      gender={player.gender}
                      seed={player.seed}
                      size={80}
                      avatarUrl={player.avatarUrl}
                    />
                  </div>
                  <span className="text-[9px] uppercase font-mono tracking-wider font-bold text-emerald-400 text-center">
                    {player.gender} Watcher
                  </span>
                </div>

                {/* Right Column: Key Prompts */}
                <div className="flex-1 flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <label className="text-xs uppercase tracking-wider text-amber-400 font-black">
                      Watcher {index + 1} Inputs
                    </label>
                  </div>

                  {/* Ask for Real Name */}
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-stone-400 uppercase tracking-wider font-mono font-bold">Real Name</span>
                    <input
                      type="text"
                      maxLength={20}
                      value={player.realName}
                      onChange={(e) => handleRealNameChange(index, e.target.value)}
                      placeholder="e.g., Robin Miller"
                      className="bg-stone-950 border border-emerald-900/60 rounded-xl px-3 py-1.5 text-sm font-bold text-white placeholder-emerald-800/60 focus:outline-none focus:border-amber-500/50"
                    />
                  </div>

                  {/* Ask for biological sex */}
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-stone-400 uppercase tracking-wider font-mono font-bold">Sex</span>
                    <div className="flex gap-2">
                      {(["Male", "Female", "Diverse"] as PlayerGender[]).map((sexOption) => (
                        <button
                          key={sexOption}
                          type="button"
                          disabled={loadingProfiles[index]}
                          onClick={() => {
                            playUiClick();
                            handleSexChange(index, sexOption);
                          }}
                          className={`flex-1 py-1 rounded-lg text-[9px] uppercase font-black tracking-widest transition-all cursor-pointer border disabled:opacity-50 ${
                            player.gender === sexOption
                              ? "bg-amber-500 text-stone-950 border-amber-600 font-extrabold shadow-md"
                              : "bg-stone-950 border-stone-800 text-stone-400 hover:text-white"
                          }`}
                        >
                          {sexOption}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Middle Row: Generate Button */}
              <button
                type="button"
                disabled={loadingProfiles[index] || !player.realName.trim()}
                onClick={() => {
                  playUiClick();
                  handleGenerateAIProfile(index);
                }}
                className={`w-full py-2.5 px-4 rounded-xl text-xs uppercase font-mono font-black tracking-wider transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                  loadingProfiles[index]
                    ? "bg-stone-950 text-amber-500 border-amber-500/20 animate-pulse"
                    : player.realName.trim()
                      ? "bg-gradient-to-r from-amber-500 via-amber-600 to-emerald-600 hover:from-amber-400 hover:to-emerald-500 text-black border-amber-500 shadow-md hover:scale-[1.01] active:scale-95"
                      : "bg-stone-950 border-stone-800 text-stone-600 cursor-not-allowed"
                }`}
              >
                {loadingProfiles[index] ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                    Connecting to Gemini AI...
                  </>
                ) : player.cgiProfile ? (
                  "✨ Re-summon AI Character & Fun Name"
                ) : (
                  "✨ Summon AI Fun Name & CGI Profile"
                )}
              </button>

              {/* Dossier Sheet: Beautiful view of the AI generated values */}
              {(player.name || player.cgiProfile) && (
                <div className="bg-stone-950/90 border border-amber-500/20 rounded-xl p-3 flex flex-col gap-2 relative overflow-hidden bg-gradient-to-b from-stone-950 to-stone-900/60 shadow-lg">
                  <div className="absolute top-0 right-0 py-0.5 px-2 bg-amber-500/10 border-l border-b border-amber-500/20 text-[7.5px] uppercase font-mono text-amber-400 font-bold tracking-widest">
                    Guild Dossier
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-[8px] text-amber-500 uppercase tracking-widest font-mono font-bold">Generated Fun Name</span>
                    <input
                      type="text"
                      value={player.name}
                      onChange={(e) => handleFunNameChange(index, e.target.value)}
                      placeholder="Funny Watcher Name..."
                      className="bg-transparent border-b border-amber-500/10 focus:border-amber-500/30 text-amber-200 font-serif font-black text-sm py-0.5 focus:outline-none"
                    />
                  </div>

                  {player.cgiProfile && (
                    <div className="flex flex-col gap-1 mt-1">
                      <span className="text-[8px] text-emerald-400 uppercase tracking-widest font-mono font-bold">CGI Profile Biography</span>
                      <textarea
                        rows={2}
                        value={player.cgiProfile}
                        onChange={(e) => handleCgiProfileChange(index, e.target.value)}
                        placeholder="Character Biography..."
                        className="bg-transparent text-stone-300 font-serif italic text-xs leading-relaxed resize-none focus:outline-none border-b border-emerald-900/10 focus:border-emerald-500/30 py-0.5"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        <button
          type="submit"
          onClick={() => {
            playUiClick();
          }}
          className="w-full bg-amber-500 hover:bg-amber-400 text-black rounded-2xl font-sans font-black text-xl tracking-widest py-4 border-b-4 border-amber-700 active:translate-y-1 hover:scale-[1.01] transition-all cursor-pointer shadow-2xl mt-2 uppercase"
          id="btn-register-play"
        >
          BEGIN EXPEDITION ({ROUNDS_SET.length} ROUNDS)
        </button>
      </form>
    </div>
  );
}
