import { useEffect, useRef } from "react";

export default function ForestAmbientBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Particle class definition within hook
    class Particle {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      rotation: number;
      rotationSpeed: number;
      opacity: number;
      type: "leaf" | "spore";
      color: string;

      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height - height;
        this.size = Math.random() * 10 + 6; // slightly larger for cinematic visibility
        this.speedX = Math.random() * 0.9 - 0.45;
        this.speedY = Math.random() * 1.2 + 0.6; // gentle breeze falling rate
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() * 0.03 - 0.015) * 0.5;
        this.opacity = Math.random() * 0.3 + 0.15; // optimal high-fidelity organic transparency
        this.type = Math.random() > 0.45 ? "spore" : "leaf";
        
        // High visibility organic color palette
        const leafColors = [
          "rgba(16, 185, 129, 0.7)", // rich emerald green
          "rgba(245, 158, 11, 0.65)", // natural golden amber
          "rgba(110, 231, 183, 0.75)", // bright minty leaf
          "rgba(139, 92, 26, 0.55)",  // wooden forest brown
        ];
        this.color = this.type === "leaf" 
          ? leafColors[Math.floor(Math.random() * leafColors.length)]
          : "rgba(251, 191, 36, 0.85)"; // glowing golden spore focus highlight
      }

      update() {
        this.y += this.speedY;
        // Natural waving wind drift
        this.x += this.speedX + Math.sin(this.y * 0.015) * 0.25;
        this.rotation += this.rotationSpeed;

        // Reset particle if it drifts off screen
        if (this.y > height + 20 || this.x < -20 || this.x > width + 20) {
          this.y = -20;
          this.x = Math.random() * width;
          this.speedY = Math.random() * 1.2 + 0.6;
          this.speedX = Math.random() * 0.9 - 0.45;
        }
      }

      draw(context: CanvasRenderingContext2D) {
        context.save();
        context.globalAlpha = this.opacity;
        
        if (this.type === "leaf") {
          context.translate(this.x, this.y);
          context.rotate(this.rotation);
          
          context.fillStyle = this.color;
          // Render a stylized organic pointed oval leaf shape
          context.beginPath();
          context.moveTo(0, -this.size);
          context.quadraticCurveTo(this.size * 0.7, 0, 0, this.size);
          context.quadraticCurveTo(-this.size * 0.7, 0, 0, -this.size);
          context.fill();

          // Leaf center line vein
          context.strokeStyle = "rgba(255, 255, 255, 0.25)";
          context.lineWidth = 1;
          context.beginPath();
          context.moveTo(0, -this.size);
          context.lineTo(0, this.size * 0.82);
          context.stroke();
        } else {
          // Render glowing spore
          context.beginPath();
          const grad = context.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size);
          grad.addColorStop(0, this.color);
          grad.addColorStop(0.3, "rgba(251, 191, 36, 0.45)");
          grad.addColorStop(1, "rgba(251, 191, 36, 0)");
          context.fillStyle = grad;
          context.arc(this.x, this.y, this.size, 0, Math.PI * 2);
          context.fill();
        }

        context.restore();
      }
    }

    // Handle high pixel density screens properly (retina displays)
    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);

    // Populate particles
    const particleCount = Math.min(32, Math.floor((width * height) / 45000));
    const particles: Particle[] = Array.from({ length: particleCount }).map(() => new Particle());

    const tick = () => {
      ctx.clearRect(0, 0, width, height);

      // Render & update particles representing natural elements
      for (const p of particles) {
        p.update();
        p.draw(ctx as unknown as CanvasRenderingContext2D);
      }

      animationFrameId = requestAnimationFrame(tick);
    };

    tick();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-[40] block"
    />
  );
}
