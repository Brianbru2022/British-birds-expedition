import { useEffect, useRef } from "react";
import { getAudioAnalyser } from "../utils/audio";

interface AudioSpectrogramProps {
  className?: string;
  type?: "wave" | "bars";
  color?: "emerald" | "amber" | "mixed";
  height?: number;
}

export default function AudioSpectrogram({
  className = "",
  type = "wave",
  color = "mixed",
  height = 54,
}: AudioSpectrogramProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Dynamic sizing to guarantee correct sharpness on high density screens
    const handleResize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);

      const dpr = window.devicePixelRatio || 1;
      const width = canvas.width / dpr;
      const heightVal = canvas.height / dpr;

      // Draw semi-transparent background to create a smooth retro phosphorescent trailing fade!
      ctx.fillStyle = "rgba(12, 19, 16, 0.18)";
      ctx.fillRect(0, 0, width, heightVal);

      const analyser = getAudioAnalyser();
      const activeBufferLength = analyser ? analyser.frequencyBinCount : 128;
      const dataArray = new Uint8Array(activeBufferLength);

      if (type === "wave") {
        if (analyser) {
          analyser.getByteTimeDomainData(dataArray);
        }

        ctx.lineWidth = 2.5;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        // Setup gorgeous gradient matching our brand
        const gradient = ctx.createLinearGradient(0, 0, width, 0);
        if (color === "emerald") {
          gradient.addColorStop(0, "rgba(52, 211, 153, 0.4)");
          gradient.addColorStop(0.5, "rgba(16, 185, 129, 0.95)");
          gradient.addColorStop(1, "rgba(5, 150, 105, 0.4)");
        } else if (color === "amber") {
          gradient.addColorStop(0, "rgba(251, 191, 36, 0.4)");
          gradient.addColorStop(0.5, "rgba(245, 158, 11, 0.95)");
          gradient.addColorStop(1, "rgba(217, 119, 6, 0.4)");
        } else {
          // Mixed Emerald + Amber gold
          gradient.addColorStop(0, "rgba(16, 185, 129, 0.4)");
          gradient.addColorStop(0.3, "rgba(52, 211, 153, 0.9)");
          gradient.addColorStop(0.7, "rgba(245, 158, 11, 0.9)");
          gradient.addColorStop(1, "rgba(217, 119, 6, 0.4)");
        }

        ctx.strokeStyle = gradient;

        // Draw shadow glow
        ctx.shadowBlur = 8;
        ctx.shadowColor = color === "emerald" ? "#10b981" : color === "amber" ? "#f59e0b" : "#34d399";

        ctx.beginPath();

        const sliceWidth = width / activeBufferLength;
        let x = 0;

        // Calculate maximum amplitude to add micro-movements even when silent
        let hasActiveSignal = false;
        if (analyser) {
          for (let i = 0; i < activeBufferLength; i++) {
            const v = dataArray[i] / 128.0;
            if (Math.abs(v - 1.0) > 0.015) {
              hasActiveSignal = true;
              break;
            }
          }
        }

        for (let i = 0; i < activeBufferLength; i++) {
          let v = analyser ? (dataArray[i] / 128.0) : 1.0; // range 0 to 2

          // Add a subtle ambient organic breathing idle wave when no sound plays
          if (!hasActiveSignal) {
            const time = Date.now() * 0.004;
            v += Math.sin(i * 0.12 + time) * 0.04 * Math.sin(time * 0.5) * (1 - Math.abs(i - activeBufferLength / 2) / (activeBufferLength / 2));
          }

          const y = (v * heightVal) / 2;

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }

          x += sliceWidth;
        }

        ctx.lineTo(width, heightVal / 2);
        ctx.stroke();
        
        // Reset shadow for performance
        ctx.shadowBlur = 0;
      } else {
        // Frequency bars visualizer
        if (analyser) {
          analyser.getByteFrequencyData(dataArray);
        }

        // Draw subtle ambient noise bars if fully silent
        let sum = 0;
        if (analyser) {
          for (let i = 0; i < activeBufferLength; i++) sum += dataArray[i];
        }
        const isSilent = !analyser || (sum < 30);

        const barWidth = (width / activeBufferLength) * 1.5;
        let barHeight;
        let x = 0;

        for (let i = 0; i < activeBufferLength; i++) {
          if (isSilent) {
            // Idle breathing waves
            const timeIdx = Date.now() * 0.002;
            barHeight = (Math.sin(i * 0.25 + timeIdx) + 1) * 3 + Math.random() * 2;
          } else {
            barHeight = (dataArray[i] / 255.0) * heightVal * 0.95;
          }

          const grad = ctx.createLinearGradient(0, heightVal - barHeight, 0, heightVal);
          if (color === "emerald") {
            grad.addColorStop(0, "#34d399");
            grad.addColorStop(1, "#065f46");
          } else if (color === "amber") {
            grad.addColorStop(0, "#fbbf24");
            grad.addColorStop(1, "#78350f");
          } else {
            grad.addColorStop(0, "#fbbf24");
            grad.addColorStop(0.5, "#10b981");
            grad.addColorStop(1, "#022c22");
          }

          ctx.fillStyle = grad;
          ctx.fillRect(x, heightVal - barHeight, barWidth - 1, barHeight);

          x += barWidth;
        }
      }
    };

    draw();

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [type, color, height]);

  return (
    <div className={`relative bg-stone-950/80 border border-emerald-900/30 rounded-xl overflow-hidden shadow-inner ${className}`}>
      <canvas
        ref={canvasRef}
        style={{ width: "100%", height: `${height}px`, display: "block" }}
        className="pointer-events-none"
      />
      
      {/* Decorative radar horizontal grid markings */}
      <div className="absolute inset-0 pointer-events-none opacity-5 flex flex-col justify-between p-1.5 font-mono text-[7px] text-emerald-400">
        <div className="flex justify-between border-b border-emerald-500/30 pb-0.5">
          <span>8.0 kHz [MAX]</span>
          <span>96 dB</span>
        </div>
        <div className="border-b border-dashed border-emerald-500/20 w-full" />
        <div className="flex justify-between border-t border-emerald-500/30 pt-0.5">
          <span>0.1 kHz [MIN]</span>
          <span>Procedural Synthesizer Active</span>
        </div>
      </div>
    </div>
  );
}
