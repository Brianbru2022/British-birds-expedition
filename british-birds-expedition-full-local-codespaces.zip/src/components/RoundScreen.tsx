import React, { useState, useEffect } from "react";
import { Player, BirdCard, RoundInfo, RarityLevel, ActionCard } from "../types";
import BirdCardComponent from "./BirdCardComponent";
import AudioSpectrogram from "./AudioSpectrogram";
import { GroupIconSelector, ForestLeafIcon, ExplorerAvatar } from "./BirdIcons";
import { playBirdSong, playUiClick, playUiAward, startAmbientForest, stopAmbientForest } from "../utils/audio";
import { unlockBird } from "../utils/journal";
import { ROUNDS_SET } from "../data/rounds";
import { getSanitizedQuestionPrompt } from "../utils/questionSanitizer";
import { drawRandomActionCards } from "../data/actionCards";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

// Helper to shuffle arrays
function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

function getBirdVocalizationDescription(bird: BirdCard): string {
  const name = bird.name.toLowerCase();
  if (name.includes("robin")) return "A sweet warbling cascade of silvery liquid notes, often ending on thin creaky chirps.";
  if (name.includes("tawny owl")) return "An iconic ghostly quivering duet, 'ke-wick' followed by a long, deep hollow 'hoo-hoo-oooo'.";
  if (name.includes("cuckoo")) return "A rhythmic, clear double-whistle 'cuc-koo', echoing far across hills and woodlands.";
  if (name.includes("barn owl")) return "A blood-curdling, long, dry raspy screech of pure horror echoing in drafty old barns.";
  if (name.includes("kingfisher")) return "A piercingly high, icy metallic whistle 'zitt-zitt' issued in rapid flight streaks.";
  if (name.includes("woodlark")) return "A gorgeous, melancholic cascading run of liquid woodwind whistles 'lu-lu-lu-lu' dropping in pitch.";
  if (name.includes("nightingale")) return "A famously rich, powerful midnight symphony combining rich gurgles, whistles, and deep crescendos.";
  if (name.includes("nightjar")) return "An bizarre, extremely rapid mechanical churring rattle that shifts gears like a motorcycle engine in the dark.";
  if (name.includes("bittern")) return "A deep, primeval mist-shrub foghorn 'boom' carrying over reedbeds for miles.";
  if (name.includes("starling")) return "A chaotic, chatter box collage of whistles, clicks, rattles, and mimicry of car alarms or whistles.";
  if (name.includes("herring gull") || name.includes("gull")) return "A noisy, laughing seaside clarion call 'kyow-kyow-kyow' echoing over ocean breezes.";
  if (name.includes("woodpigeon")) return "A deep, comforting but repetitive five-note cooing song 'coo-coo-coo, coo-coo'.";
  if (name.includes("skylark")) return "A breathless, non-stop soaring rocket stream of ecstatic high-frequency silver tweets and trills.";
  if (name.includes("blackbird")) return "A rich, lazy, flute-like melodic song flowing smoothly from tall chimneys and tree canopies.";
  if (name.includes("wren")) return "An unbelievably loud, rapid-fire machine gun burst of high whistles and ringing metallic trills.";
  if (name.includes("nuthatch")) return "A bold, ringing, metallic whistle 'twit-twit-twit-twit' delivered head-down on tree trunks.";
  if (name.includes("chiffchaff")) return "A repetitive, metronomic song sounding like 'chiff-chaff, chiff-chaff' marking spring.";
  if (name.includes("green woodpecker") || name.includes("yaffle")) return "A loud, ringing, laughing 'yaffle' whinny delivered from garden lawns.";
  if (name.includes("curlew")) return "A haunting, bubbling, rising fluted whistle 'cour-li' rising into a wild torrent on coastal mudflats.";
  if (name.includes("corncrake")) return "A repetitive, dry dark hours rasping 'crex-crex', sounding like a fingernail on a plastic comb.";
  
  if (bird.group === "Raptors") return "A sharp, repetitive, high-pitched screeching or mewing chatter characteristic of a solitary peak bird of prey.";
  if (bird.group === "Seabirds") return "A loud, screaming, sea-breeze laughing cry or guttural rattle echoing around wild oceanic cliffs.";
  if (bird.group === "Waterfowl") return "A sudden, comforting cackling cackle or nasally low quacking whistle issuing from marsh waterways.";
  if (bird.group === "Songbirds") return "A sweet, chattering, melodic sequence of liquid chirps and high-pitch whistles from the hedgerows.";
  return `A signature vocalization, highly adapted to survive in its '${bird.habitat}' home.`;
}

interface RoundScreenProps {
  round: RoundInfo;
  players: Player[];
  deck: BirdCard[];
  onRoundComplete: (
    scoresGained: Record<string, number>,
    finalGearCharges?: Record<string, { binoculars: number; sonic: number; thermal: number }>,
    finalCardsInHand?: Record<string, ActionCard[]>,
    finalBirdsCollected?: Record<string, string[]>,
    streakProtected?: Record<string, boolean>
  ) => void;
  activeModifierKey?: string;
  activeModifierRule?: string;
  activeDestinationName?: string;
}

export default function RoundScreen({
  round,
  players,
  deck,
  onRoundComplete,
  activeModifierKey,
  activeModifierRule,
  activeDestinationName,
}: RoundScreenProps) {
  // --- CORE GAME SESSION STATES ---
  const [activePlayerIndex, setActivePlayerIndex] = useState<number>(0);
  const [roundScores, setRoundScores] = useState<Record<string, number>>({});
  const [roundPhase, setRoundPhase] = useState<"tutorial" | "play" | "compare" | "scoreReport">("tutorial");
  
  // Custom states shared or swapped per question type
  const [targetBird, setTargetBird] = useState<BirdCard | null>(null);
  const [decoyBirds, setDecoyBirds] = useState<BirdCard[]>([]);
  const [activePool, setActivePool] = useState<BirdCard[]>([]);
  const [draftedCards, setDraftedCards] = useState<Record<string, BirdCard>>({}); // playerId -> card
  const [round2Drafts, setRound2Drafts] = useState<Record<string, BirdCard[]>>({}); // playerId -> card array for Round 2
  const [sortedCards, setSortedCards] = useState<BirdCard[]>([]);
  const [rarityLevelPool, setRarityLevelPool] = useState<BirdCard[]>([]);
  const [tfQuestion, setTfQuestion] = useState<{ text: string; answer: boolean; explanation: string; bird: BirdCard } | null>(null);
  const [targetCategory, setTargetCategory] = useState<string>("");
  const [selectedMultiIds, setSelectedMultiIds] = useState<string[]>([]);
  const [latinMatches, setLatinMatches] = useState<Array<{ id: string; name: string; scientificName: string }>>([]);
  const [shuffledScientificNames, setShuffledScientificNames] = useState<Array<{ id: string; name: string; scientificName: string }>>([]);
  const [selectedLatinBird, setSelectedLatinBird] = useState<BirdCard | null>(null);
  const [matchedLatinIds, setMatchedLatinIds] = useState<string[]>([]);

  // Grid / Memory Game states (Round 12)
  const [gridCards, setGridCards] = useState<Array<{ id: string; bird: BirdCard; flipped: boolean; matched: boolean }>>([]);
  const [selectedGridIndices, setSelectedGridIndices] = useState<number[]>([]);
  const [gridTurnScore, setGridTurnScore] = useState<Record<string, number>>({});

  // Raptor Trump states (Round 13)
  const [trumpCards, setTrumpCards] = useState<Record<string, BirdCard>>({}); // playerId -> Raptor card
  const [selectedTrumpStat, setSelectedTrumpStat] = useState<"wingspanAvg" | "weightAvg" | "lengthAvg" | "clutchAvg" | null>(null);

  // Grand Finale states (Round 15)
  const [finalePlacements, setFinalePlacements] = useState<Record<string, BirdCard[]>>({}); // playerId -> 3 cards in slots

  // Feedbacks
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; type: "success" | "error" | "info" } | null>(null);
  const [handoffPlayerName, setHandoffPlayerName] = useState<string | null>(null);
  
  // --- SPEEDRUN / TUTORIAL SKIP STATE ---
  const [speedrunEnabled, setSpeedrunEnabled] = useState<boolean>(() => {
    return localStorage.getItem("speedrun_mode") === "true";
  });
  
  // --- WILD EXPLORER EQUIPMENT STATES ---
  const [playerGearCharges, setPlayerGearCharges] = useState<Record<string, { binoculars: number; sonic: number; thermal: number }>>({});

  useEffect(() => {
    if (players) {
      const initialCharges: Record<string, { binoculars: number; sonic: number; thermal: number }> = {};
      players.forEach(p => {
        initialCharges[p.id] = {
          binoculars: p.gear?.binoculars ?? 1,
          sonic: p.gear?.sonic ?? 1,
          thermal: p.gear?.thermal ?? 1,
        };
      });
      setPlayerGearCharges(initialCharges);
    }
  }, [players, round.number]);

  const [playerGear, setPlayerGear] = useState<Record<string, { binocularsUsed: boolean; sonicUsed: boolean; thermalUsed: boolean }>>({});
  const [disabledDecoyIds, setDisabledDecoyIds] = useState<string[]>([]);
  const [sonicHint, setSonicHint] = useState<string | null>(null);
  const [thermalClue, setThermalClue] = useState<string | null>(null);

  // --- ACTION CARDS WORKFLOW ---
  const [playerCards, setPlayerCards] = useState<Record<string, ActionCard[]>>({});
  const [roundBirdsCollected, setRoundBirdsCollected] = useState<Record<string, string[]>>({});
  const [activeDoublePoints, setActiveDoublePoints] = useState<Record<string, boolean>>({});
  const [activeStreakProtected, setActiveStreakProtected] = useState<Record<string, boolean>>({});
  const [activeRevealedFamily, setActiveRevealedFamily] = useState<string | null>(null);

  useEffect(() => {
    if (players) {
      const initialCards: Record<string, ActionCard[]> = {};
      const initialCollected: Record<string, string[]> = {};
      players.forEach(p => {
        initialCards[p.id] = p.cardsInHand ?? [];
        initialCollected[p.id] = [];
      });
      setPlayerCards(initialCards);
      setRoundBirdsCollected(initialCollected);
      setActiveDoublePoints({});
      setActiveStreakProtected({});
      setActiveRevealedFamily(null);
    }
  }, [players, round.number]);

  const handlePlayActionCard = (card: ActionCard) => {
    if (!activePlayer || feedbackMsg || reviewData) return;
    
    // Check if card is run by active player
    const hand = playerCards[activePlayer.id] || [];
    if (!hand.some(c => c.id === card.id)) return;

    // Remove card from hand
    const remainingCards = hand.filter(c => c.id !== card.id);
    setPlayerCards(prev => ({
      ...prev,
      [activePlayer.id]: remainingCards
    }));

    // Trigger action based on type
    if (card.actionType === "remove_wrong") {
      let wrongOptions: BirdCard[] = [];
      if (round.style === "SINGLE_CHOICE" && targetBird) {
        wrongOptions = decoyBirds.filter(b => b.id !== targetBird.id && !disabledDecoyIds.includes(b.id));
      } else if (round.style === "MIGRATION_QUEST" && targetBird) {
        wrongOptions = decoyBirds.filter(b => b.migratoryStatus !== targetBird.migratoryStatus && !disabledDecoyIds.includes(b.id));
      }
      if (wrongOptions.length > 0) {
        const randomWrongIdx = Math.floor(Math.random() * wrongOptions.length);
        const discardId = wrongOptions[randomWrongIdx].id;
        setDisabledDecoyIds(prev => [...prev, discardId]);
      }
    } else if (card.actionType === "double_points") {
      setActiveDoublePoints(prev => ({
        ...prev,
        [activePlayer.id]: true
      }));
    } else if (card.actionType === "protect_streak") {
      setActiveStreakProtected(prev => ({
        ...prev,
        [activePlayer.id]: true
      }));
    } else if (card.actionType === "reveal_family") {
      if (targetBird) {
        setActiveRevealedFamily(targetBird.group);
      }
    } else if (card.actionType === "swap_options") {
      if (targetBird) {
        const unusedBirds = deck.filter(b => b.id !== targetBird.id);
        if (unusedBirds.length > 0) {
          const newTarget = unusedBirds[Math.floor(Math.random() * unusedBirds.length)];
          setTargetBird(newTarget);
          setSonicHint(`Horns of change blow! The storm swap has brought a new species: ${newTarget.name}!`);
          setTimeout(() => setSonicHint(null), 4000);
        }
      }
    } else if (card.actionType === "gain_binoculars") {
      setPlayerGearCharges(prev => {
        const pCharges = prev[activePlayer.id] || { binoculars: 0, sonic: 0, thermal: 0 };
        return {
          ...prev,
          [activePlayer.id]: {
            ...pCharges,
            binoculars: pCharges.binoculars + 1
          }
        };
      });
    }

    try {
      playUiClick();
    } catch {}
  };

  const [timerCount, setTimerCount] = useState<number>(15);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [reviewData, setReviewData] = useState<{
    bird: BirdCard;
    title: string;
    text: string;
    isCorrect: boolean;
    onContinue: () => void;
  } | null>(null);

  const handleReviewContinue = () => {
    if (reviewData) {
      reviewData.onContinue();
      setReviewData(null);
    }
  };

  useEffect(() => {
    if (reviewData) {
      playBirdSong(reviewData.bird.group, reviewData.bird.name);
    }
  }, [reviewData]);

  const activePlayer = players[activePlayerIndex];

  useEffect(() => {
    if (roundPhase === "play" && players.length > 1 && activePlayer) {
      setHandoffPlayerName(activePlayer.name);
    } else {
      setHandoffPlayerName(null);
    }
  }, [activePlayerIndex, roundPhase]);

  useEffect(() => {
    setDisabledDecoyIds([]);
    setSonicHint(null);
    setThermalClue(null);
  }, [activePlayerIndex, round.number]);

  // Initialize round settings
  useEffect(() => {
    initRoundData();
    // Reset round scores
    const initialScores: Record<string, number> = {};
    players.forEach((p) => {
      initialScores[p.id] = 0;
    });
    setRoundScores(initialScores);
    
    if (speedrunEnabled) {
      setRoundPhase("play");
      setTimerCount(15);
    } else {
      setRoundPhase("tutorial");
    }
    
    setActivePlayerIndex(0);
    setFeedbackMsg(null);
    setIsTransitioning(false);
  }, [round.number]);

  const handleUseBinoculars = () => {
    if (!activePlayer || feedbackMsg || reviewData) return;
    
    // Check local charges capacity first
    const charges = playerGearCharges[activePlayer.id] || { binoculars: 0, sonic: 0, thermal: 0 };
    if (charges.binoculars <= 0) return;

    // Check if player already used it this round turn
    const gear = playerGear[activePlayer.id] || { binocularsUsed: false, sonicUsed: false, thermalUsed: false };
    if (gear.binocularsUsed) return;

    // We can support SINGLE_CHOICE, ODD_ONE_OUT, MIGRATION_QUEST, and SPECTATE
    let wrongOptions: BirdCard[] = [];
    if (round.style === "SINGLE_CHOICE" && targetBird) {
      wrongOptions = decoyBirds.filter(b => b.id !== targetBird.id);
    } else if (round.style === "ODD_ONE_OUT") {
      const maxRarity = Math.max(...rarityLevelPool.map((b) => b.rarity));
      wrongOptions = rarityLevelPool.filter(b => b.rarity !== maxRarity);
    } else if (round.style === "MIGRATION_QUEST" && targetBird) {
      wrongOptions = decoyBirds.filter(b => b.migratoryStatus !== targetBird.migratoryStatus);
    }

    // Filter out already disabled ones
    const availableWrong = wrongOptions.filter(b => !disabledDecoyIds.includes(b.id));
    if (availableWrong.length > 0) {
      // Pick one random wrong option to discard
      const chosen = availableWrong[Math.floor(Math.random() * availableWrong.length)];
      setDisabledDecoyIds(prev => [...prev, chosen.id]);
      playUiAward(); // play a cool sound feedback!
      
      // Save used status
      setPlayerGear(prev => ({
        ...prev,
        [activePlayer.id]: {
          binocularsUsed: true,
          sonicUsed: prev[activePlayer.id]?.sonicUsed || false,
          thermalUsed: prev[activePlayer.id]?.thermalUsed || false
        }
      }));

      // Decrement charges
      setPlayerGearCharges(prev => ({
        ...prev,
        [activePlayer.id]: {
          ...prev[activePlayer.id],
          binoculars: Math.max(0, charges.binoculars - 1)
        }
      }));
    }
  };

  const handleUseSonicParabola = () => {
    if (!activePlayer || feedbackMsg || reviewData) return;

    const charges = playerGearCharges[activePlayer.id] || { binoculars: 0, sonic: 0, thermal: 0 };
    if (charges.sonic <= 0) return;

    const gear = playerGear[activePlayer.id] || { binocularsUsed: false, sonicUsed: false, thermalUsed: false };
    if (gear.sonicUsed) return;

    // Find the correct bird of this round style to play its song and give a group hint
    let correctBird: BirdCard | null = null;
    if (round.style === "SINGLE_CHOICE" || round.style === "MIGRATION_QUEST") {
      correctBird = targetBird;
    } else if (round.style === "ODD_ONE_OUT") {
      const maxRarity = Math.max(...rarityLevelPool.map((b) => b.rarity));
      correctBird = rarityLevelPool.find(b => b.rarity === maxRarity) || null;
    }

    if (correctBird) {
      playBirdSong(correctBird.group, correctBird.name);
      setSonicHint(`📡 ACOUSTIC ANALYSIS: Frequency spectra indicates a member of the '${correctBird.group}' group!`);
      
      // Save used status
      setPlayerGear(prev => ({
        ...prev,
        [activePlayer.id]: {
          binocularsUsed: prev[activePlayer.id]?.binocularsUsed || false,
          sonicUsed: true,
          thermalUsed: prev[activePlayer.id]?.thermalUsed || false
        }
      }));

      // Decrement charges
      setPlayerGearCharges(prev => ({
        ...prev,
        [activePlayer.id]: {
          ...prev[activePlayer.id],
          sonic: Math.max(0, charges.sonic - 1)
        }
      }));
    }
  };

  const handleUseThermalScope = () => {
    if (!activePlayer || feedbackMsg || reviewData) return;

    const charges = playerGearCharges[activePlayer.id] || { binoculars: 0, sonic: 0, thermal: 0 };
    if (charges.thermal <= 0) return;

    const gear = playerGear[activePlayer.id] || { binocularsUsed: false, sonicUsed: false, thermalUsed: false };
    if (gear.thermalUsed) return;

    let correctBird: BirdCard | null = null;
    if (round.style === "SINGLE_CHOICE" || round.style === "MIGRATION_QUEST") {
      correctBird = targetBird;
    } else if (round.style === "ODD_ONE_OUT") {
      const maxRarity = Math.max(...rarityLevelPool.map((b) => b.rarity));
      correctBird = rarityLevelPool.find(b => b.rarity === maxRarity) || null;
    }

    if (correctBird) {
      const formattedWeight = correctBird.weightAvg >= 1000 ? `${(correctBird.weightAvg / 1000).toFixed(1)}kg` : `${correctBird.weightAvg}g`;
      setThermalClue(`🔥 THERMAL SPECTRUM LOCK: Body Mass: ~${formattedWeight} | Primary Habitat: '${correctBird.habitat}'!`);
      playUiAward();

      setPlayerGear(prev => ({
        ...prev,
        [activePlayer.id]: {
          binocularsUsed: prev[activePlayer.id]?.binocularsUsed || false,
          sonicUsed: prev[activePlayer.id]?.sonicUsed || false,
          thermalUsed: true
        }
      }));

      // Decrement charges
      setPlayerGearCharges(prev => ({
        ...prev,
        [activePlayer.id]: {
          ...prev[activePlayer.id],
          thermal: Math.max(0, charges.thermal - 1)
        }
      }));
    }
  };

  const initRoundData = () => {
    const shuffledDeck = shuffle(deck);

    switch (round.style) {
      case "SINGLE_CHOICE": {
        // Find 1 bird, and 3 decoys
        const target = shuffledDeck[0];
        const decoys = shuffledDeck.slice(1, 4);
        setTargetBird(target);
        setDecoyBirds(shuffle([target, ...decoys]));
        break;
      }
      case "SONIC_IDENTIFY":
      case "CALL_CHALLENGE": {
        const target = shuffledDeck[0];
        const decoys = shuffledDeck.slice(1, 4);
        setTargetBird(target);
        setDecoyBirds(shuffle([target, ...decoys]));
        break;
      }
      case "SORT_WEIGHT": {
        setSortedCards(shuffledDeck.slice(0, 4));
        break;
      }
      case "GROUP_MATCH": {
        const uniqueGroupBirds: BirdCard[] = [];
        const seenGroups = new Set<string>();
        for (const b of shuffledDeck) {
          if (!seenGroups.has(b.group)) {
            uniqueGroupBirds.push(b);
            seenGroups.add(b.group);
            if (uniqueGroupBirds.length === 4) break;
          }
        }
        while (uniqueGroupBirds.length < 4 && shuffledDeck.length > uniqueGroupBirds.length) {
          const fallback = shuffledDeck.find(b => !uniqueGroupBirds.some(u => u.id === b.id));
          if (fallback) uniqueGroupBirds.push(fallback);
          else break;
        }
        setLatinMatches(uniqueGroupBirds.map(b => ({ id: b.id, name: b.name, scientificName: b.group })));
        setShuffledScientificNames(shuffle(uniqueGroupBirds.map(b => ({ id: b.id, name: b.name, scientificName: b.group }))));
        setMatchedLatinIds([]);
        setSelectedLatinBird(null);
        break;
      }
      case "DRAFT_WEIGHT": {
        const numPlayers = players.length;
        const poolSize = Math.max(8, Math.ceil(8 / numPlayers) * numPlayers);
        setActivePool(shuffledDeck.slice(0, poolSize));
        setRound2Drafts({});
        break;
      }
      case "DRAFT_LIGHTEST":
      case "DRAFT_CLUTCH": {
        // Layout 6 distinct bird cards for communal picking
        setActivePool(shuffledDeck.slice(0, 7));
        setDraftedCards({});
        break;
      }
      case "DIET_CLAIM": {
        const pool = shuffledDeck.slice(0, 6);
        setActivePool(pool);
        const diets = pool.map(b => b.primaryDiet);
        const randomDiet = diets[Math.floor(Math.random() * diets.length)];
        setTargetCategory(randomDiet);
        setDraftedCards({});
        break;
      }
      case "HABITAT_CLAIM": {
        const pool = shuffledDeck.slice(0, 6);
        setActivePool(pool);
        const habitats = pool.map(b => b.habitat);
        const randomHabitat = habitats[Math.floor(Math.random() * habitats.length)];
        setTargetCategory(randomHabitat);
        setDraftedCards({});
        break;
      }
      case "SORT_WINGSPAN": {
        // Deal the active player 4 birds to sort
        setSortedCards(shuffledDeck.slice(0, 4));
        break;
      }
      case "ODD_ONE_OUT": {
        // Find 1 higher rarity bird and 3 lower rarity birds
        let target: BirdCard | null = null;
        let decoys: BirdCard[] = [];
        const sortedByRarityDesc = [...shuffledDeck].sort((a, b) => b.rarity - a.rarity);
        
        for (const candidate of sortedByRarityDesc) {
          const potentialDecoys = shuffledDeck.filter(b => b.id !== candidate.id && b.rarity < candidate.rarity);
          if (potentialDecoys.length >= 3) {
            target = candidate;
            decoys = shuffle(potentialDecoys).slice(0, 3);
            break;
          }
        }
        
        if (target && decoys.length === 3) {
          setRarityLevelPool(shuffle([target, ...decoys]));
        } else {
          const fallbackTarget = shuffledDeck.find(b => b.rarity > 1) || shuffledDeck[0];
          const fallbackDecoys = shuffledDeck.filter(b => b.id !== fallbackTarget.id && b.rarity < fallbackTarget.rarity).slice(0, 3);
          setRarityLevelPool(shuffle([fallbackTarget, ...fallbackDecoys]));
        }
        break;
      }
      case "TRUE_FALSE": {
        // Generate a true/false statement about a random bird
        const bird = shuffledDeck[0];
        const prompts = [
          {
            text: `Is the UK conservation rating for the ${bird.name} classified as RED (endangered)?`,
            answer: bird.conservationStatus === "Red",
            explanation: `The UK conservation status for the ${bird.name} is actually '${bird.conservationStatus}'.`,
          },
          {
            text: `Does the ${bird.name} belong to the '${bird.group}' avian group?`,
            answer: true,
            explanation: `Indeed, the ${bird.name} belongs to the ${bird.group} group.`,
          },
          {
            text: `Is the average wingspan of the ${bird.name} greater than 50 cm?`,
            answer: bird.wingspanAvg > 50,
            explanation: `The average wingspan of the ${bird.name} is exactly ${bird.wingspanAvg} cm.`,
          },
          {
            text: `Does the ${bird.name} typically migrate as a 'Summer Visitor' of Great Britain?`,
            answer: bird.migratoryStatus === "Summer Visitor",
            explanation: `The migratory status for the ${bird.name} is actually '${bird.migratoryStatus}'.`,
          },
        ];
        const pickedPrompt = prompts[Math.floor(Math.random() * prompts.length)];
        setTfQuestion({ text: pickedPrompt.text, answer: pickedPrompt.answer, explanation: pickedPrompt.explanation, bird });
        break;
      }
      case "MIGRATION_QUEST": {
        const target = shuffledDeck.find(b => b.migratoryStatus !== "Resident") || shuffledDeck[0];
        setTargetBird(target);
        // Find 3 other birds that have a DIFFERENT migratory status to ensure exactly one correct answer!
        const decoys = shuffledDeck.filter(b => b.id !== target.id && b.migratoryStatus !== target.migratoryStatus).slice(0, 3);
        setDecoyBirds(shuffle([target, ...decoys]));
        break;
      }
      case "LATIN_MATCH": {
        const pool = shuffledDeck.slice(0, 4);
        const matches = pool.map((b) => ({ id: b.id, name: b.name, scientificName: b.scientificName }));
        setLatinMatches(matches);
        setShuffledScientificNames(shuffle([...matches]));
        setMatchedLatinIds([]);
        setSelectedLatinBird(null);
        break;
      }
      case "GRID_SEARCH": {
        // Select 6 birds, duplicate their groups to create 12 match cards
        const sample = shuffledDeck.slice(0, 6);
        const doubleList = [...sample, ...sample].map((bird, idx) => ({
          id: `tile-${idx}`,
          bird,
          flipped: false,
          matched: false,
        }));
        setGridCards(shuffle(doubleList));
        setSelectedGridIndices([]);
        setGridTurnScore({});
        break;
      }
      case "RAPTOR_TRUMP": {
        // Find 4 raptors for players
        const raptors = deck.filter((b) => b.group === "Raptors");
        const shuffledRaptors = shuffle(raptors.length >= 4 ? raptors : deck);
        const map: Record<string, BirdCard> = {};
        players.forEach((p, idx) => {
          map[p.id] = shuffledRaptors[idx % shuffledRaptors.length];
        });
        setTrumpCards(map);
        setSelectedTrumpStat(null);
        break;
      }
      case "TRIVIA_MULTI": {
        const selected = shuffledDeck.slice(0, 6);
        setDecoyBirds(selected);
        setSelectedMultiIds([]);
        break;
      }
      case "GRAND_FINALE": {
        // Deal each player 3 random cards
        const placementMap: Record<string, BirdCard[]> = {};
        players.forEach((p, index) => {
          placementMap[p.id] = shuffledDeck.slice(index * 3, index * 3 + 3);
        });
        setFinalePlacements(placementMap);
        break;
      }
    }
  };

  const handleStartRound = () => {
    setRoundPhase("play");
    setTimerCount(15);
  };

  const registerPoints = (pId: string, pts: number, birdObj?: BirdCard | null) => {
    let finalPts = pts;

    const actualBird = birdObj !== undefined ? birdObj : targetBird;

    // Apply bioregional destination modifiers if positive points are being recorded
    if (pts > 0 && actualBird) {
      if (activeModifierKey === "WOODLAND_BOOST") {
        if (actualBird.group === "Songbirds" || actualBird.group === "Woodpeckers") {
          finalPts += 5; // Direct flat bonus
        }
      } else if (activeModifierKey === "MIGRATION_FAVOR") {
        if (actualBird.migratoryStatus === "Summer Visitor" || actualBird.migratoryStatus === "Winter Visitor") {
          finalPts += 10;
        }
      } else if (activeModifierKey === "WETLAND_GRAINS") {
        if (actualBird.primaryDiet === "Fish" || actualBird.primaryDiet === "Insects") {
          finalPts += 12;
        }
      } else if (activeModifierKey === "DIET_SEED") {
        if (actualBird.primaryDiet === "Seeds" || actualBird.primaryDiet === "Omnivore") {
          finalPts += 10;
        }
      }
    }

    // Apply double points Action Card multiplier
    if (pts > 0 && activeDoublePoints[pId]) {
      finalPts *= 2;
    }

    // Record correct bird collection
    if (pts > 0 && actualBird) {
      setRoundBirdsCollected(prev => {
        const current = prev[pId] || [];
        if (!current.includes(actualBird.id)) {
          return {
            ...prev,
            [pId]: [...current, actualBird.id]
          };
        }
        return prev;
      });

      // Draw random action card if hand size under 4
      const currentHand = playerCards[pId] || [];
      if (currentHand.length < 4) {
        const [drawnCard] = drawRandomActionCards(1);
        setPlayerCards(prev => ({
          ...prev,
          [pId]: [...(prev[pId] || []), drawnCard]
        }));
      }
    }

    setRoundScores((prev) => ({
      ...prev,
      [pId]: (prev[pId] || 0) + finalPts,
    }));
  };

  const rotateOrComplete = (customWait = 1800) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setFeedbackMsg(null);
      if (activePlayerIndex < players.length - 1) {
        // Reload round parameters where a new target bird is needed per solo player
        const nextIdx = activePlayerIndex + 1;
        setHandoffPlayerName(players[nextIdx].name);

        setActivePlayerIndex(nextIdx);
        
        // Re-randomize single target questions for the next player
        const shuffledDeck = shuffle(deck);
        if (round.style === "SINGLE_CHOICE") {
          const target = shuffledDeck[0];
          const decoys = shuffledDeck.slice(1, 4);
          setTargetBird(target);
          setDecoyBirds(shuffle([target, ...decoys]));
        } else if (round.style === "SONIC_IDENTIFY" || round.style === "CALL_CHALLENGE") {
          const target = shuffledDeck[0];
          const decoys = shuffledDeck.slice(1, 4);
          setTargetBird(target);
          setDecoyBirds(shuffle([target, ...decoys]));
        } else if (round.style === "SORT_WEIGHT") {
          setSortedCards(shuffledDeck.slice(0, 4));
        } else if (round.style === "GROUP_MATCH") {
          const uniqueGroupBirds: BirdCard[] = [];
          const seenGroups = new Set<string>();
          for (const b of shuffledDeck) {
            if (!seenGroups.has(b.group)) {
              uniqueGroupBirds.push(b);
              seenGroups.add(b.group);
              if (uniqueGroupBirds.length === 4) break;
            }
          }
          while (uniqueGroupBirds.length < 4 && shuffledDeck.length > uniqueGroupBirds.length) {
            const fallback = shuffledDeck.find(b => !uniqueGroupBirds.some(u => u.id === b.id));
            if (fallback) uniqueGroupBirds.push(fallback);
            else break;
          }
          setLatinMatches(uniqueGroupBirds.map(b => ({ id: b.id, name: b.name, scientificName: b.group })));
          setShuffledScientificNames(shuffle(uniqueGroupBirds.map(b => ({ id: b.id, name: b.name, scientificName: b.group }))));
          setMatchedLatinIds([]);
          setSelectedLatinBird(null);
        } else if (round.style === "TRUE_FALSE") {
          const bird = shuffledDeck[0];
          const prompts = [
            {
              text: `Is the UK conservation rating for the ${bird.name} classified as RED (endangered)?`,
              answer: bird.conservationStatus === "Red",
              explanation: `The UK conservation status for the ${bird.name} is actually '${bird.conservationStatus}'.`,
            },
            {
              text: `Does the ${bird.name} belong to the '${bird.group}' avian group?`,
              answer: true,
              explanation: `Indeed, the ${bird.name} belongs to the ${bird.group} group.`,
            },
            {
              text: `Is the average wingspan of the ${bird.name} greater than 40 cm?`,
              answer: bird.wingspanAvg > 40,
              explanation: `The average wingspan of the ${bird.name} is exactly ${bird.wingspanAvg} cm.`,
            },
            {
              text: `Does the ${bird.name} typically migrate as a 'Summer Visitor' of Great Britain?`,
              answer: bird.migratoryStatus === "Summer Visitor",
              explanation: `The migratory status for the ${bird.name} is actually '${bird.migratoryStatus}'.`,
            },
          ];
          const pickedPrompt = prompts[Math.floor(Math.random() * prompts.length)];
          setTfQuestion({ text: pickedPrompt.text, answer: pickedPrompt.answer, explanation: pickedPrompt.explanation, bird });
        } else if (round.style === "SORT_WINGSPAN") {
          setSortedCards(shuffledDeck.slice(0, 4));
        } else if (round.style === "MIGRATION_QUEST") {
          const target = shuffledDeck.find(b => b.migratoryStatus !== "Resident") || shuffledDeck[0];
          setTargetBird(target);
          const decoys = shuffledDeck.filter(b => b.id !== target.id && b.migratoryStatus !== target.migratoryStatus).slice(0, 3);
          setDecoyBirds(shuffle([target, ...decoys]));
        } else if (round.style === "ODD_ONE_OUT") {
          // Find 1 higher rarity bird and 3 lower rarity birds
          let target: BirdCard | null = null;
          let decoys: BirdCard[] = [];
          const sortedByRarityDesc = [...shuffledDeck].sort((a, b) => b.rarity - a.rarity);
          
          for (const candidate of sortedByRarityDesc) {
            const potentialDecoys = shuffledDeck.filter(b => b.id !== candidate.id && b.rarity < candidate.rarity);
            if (potentialDecoys.length >= 3) {
              target = candidate;
              decoys = shuffle(potentialDecoys).slice(0, 3);
              break;
            }
          }
          
          if (target && decoys.length === 3) {
            setRarityLevelPool(shuffle([target, ...decoys]));
          } else {
            const fallbackTarget = shuffledDeck.find(b => b.rarity > 1) || shuffledDeck[0];
            const fallbackDecoys = shuffledDeck.slice(0, 3);
            setRarityLevelPool(shuffle([fallbackTarget, ...fallbackDecoys]));
          }
        } else if (round.style === "DIET_CLAIM") {
          setActivePool((currentPool) => {
            if (currentPool.length > 0) {
              const diets = currentPool.map(b => b.primaryDiet);
              const randomDiet = diets[Math.floor(Math.random() * diets.length)];
              setTargetCategory(randomDiet);
            }
            return currentPool;
          });
        } else if (round.style === "HABITAT_CLAIM") {
          setActivePool((currentPool) => {
            if (currentPool.length > 0) {
              const habitats = currentPool.map(b => b.habitat);
              const randomHabitat = habitats[Math.floor(Math.random() * habitats.length)];
              setTargetCategory(randomHabitat);
            }
            return currentPool;
          });
        } else if (round.style === "LATIN_MATCH") {
          const pool = shuffledDeck.slice(0, 4);
          const matches = pool.map((b) => ({ id: b.id, name: b.name, scientificName: b.scientificName }));
          setLatinMatches(matches);
          setShuffledScientificNames(shuffle([...matches]));
          setMatchedLatinIds([]);
          setSelectedLatinBird(null);
        } else if (round.style === "TRIVIA_MULTI") {
          const selected = shuffledDeck.slice(0, 6);
          setDecoyBirds(selected);
          setSelectedMultiIds([]);
        }

        setTimerCount(15);
      } else {
        // All players done
        setRoundPhase("scoreReport");
      }
      setIsTransitioning(false);
    }, customWait);
  };

  // --- TRIVIA CHECKS (Round 1) ---
  const handleSingleAnswer = (bird: BirdCard) => {
    if (isTransitioning) return;
    if (!targetBird) return;
    const isCorrect = bird.id === targetBird.id;
    if (isCorrect) {
      setFeedbackMsg({ text: "Superb sight! That's correct! (+15 points)", type: "success" });
      registerPoints(activePlayer.id, 15);
      activePlayer.stats.correctAnswers++;
      unlockBird(targetBird.id, activePlayer.name);
    } else {
      setFeedbackMsg({ text: `Incorrect! It was actually the ${targetBird.name}.`, type: "error" });
    }
    activePlayer.stats.totalAnswers++;

    setReviewData({
      bird: targetBird,
      title: isCorrect ? "Excellent Spotting!" : "Sighting Unconfirmed",
      text: isCorrect 
        ? "Brilliant! You correctly identified the species from its unique behaviors and traits." 
        : `Unfortunate! That was the ${targetBird.name}. Better luck in your next field observations!`,
      isCorrect,
      onContinue: () => rotateOrComplete(0)
    });
  };

  // --- SHOREBIRD DRAFTS (Round 2, 6, 9) ---
  const handleDraftPick = (bird: BirdCard) => {
    if (isTransitioning) return;
    if (round.style === "DRAFT_WEIGHT") {
      // Check if already drafted
      const isAlreadyDrafted = (Object.values(round2Drafts) as BirdCard[][]).some(cards => cards.some(c => c.id === bird.id));
      if (isAlreadyDrafted) return;

      const currentDraftsForPlayer = round2Drafts[activePlayer.id] || [];
      const updatedDrafts: Record<string, BirdCard[]> = {
        ...round2Drafts,
        [activePlayer.id]: [...currentDraftsForPlayer, bird],
      };
      setRound2Drafts(updatedDrafts);

      setFeedbackMsg({ text: `${activePlayer.name} drafted the ${bird.name}!`, type: "info" });

      // Count total drafted cards
      const totalDraftedCount = (Object.values(updatedDrafts) as BirdCard[][]).reduce((acc, cards) => acc + cards.length, 0);
      const expectedTotal = activePool.length;

      if (totalDraftedCount === expectedTotal) {
        // Compute winners and assign points:
        // Winner gets 20 pts, losers get 0 pts.
        const playerTotals = players.map((p) => {
          const list = updatedDrafts[p.id] || [];
          const sum = list.reduce((acc, b) => acc + b.weightAvg, 0);
          return { pId: p.id, sum };
        });

        let highestWeight = -1;
        playerTotals.forEach((pt) => {
          if (pt.sum > highestWeight) {
            highestWeight = pt.sum;
          }
        });

        const winners = playerTotals.filter((pt) => pt.sum === highestWeight && pt.sum > 0);
        winners.forEach((w) => {
          registerPoints(w.pId, 20);
          const p = players.find(player => player.id === w.pId);
          if (p) {
            p.stats.correctAnswers++;
          }
        });

        players.forEach(p => {
          p.stats.totalAnswers++;
        });

        // Go to compare phase after delay
        setIsTransitioning(true);
        setTimeout(() => {
          setIsTransitioning(false);
          setRoundPhase("compare");
        }, 1500);
      } else {
        setIsTransitioning(true);
        setTimeout(() => {
          setIsTransitioning(false);
          setFeedbackMsg(null);
          // Rotate to next player
          setActivePlayerIndex((p) => (p + 1) % players.length);
        }, 1000);
      }
    } else {
      // Save draft (standard Round 6 & 9)
      const updatedDrafts = { ...draftedCards, [activePlayer.id]: bird };
      setDraftedCards(updatedDrafts);
      
      // Remove from active pool list
      setActivePool((prev) => prev.filter((b) => b.id !== bird.id));

      setFeedbackMsg({ text: `${activePlayer.name} selected ${bird.name}!`, type: "info" });

      // Rotate or calculate champion
      if (Object.keys(updatedDrafts).length === players.length) {
        // Calculate winner inside event handler to avoid react state render crash
        let winnerId = "";
        let winningValue = round.style === "DRAFT_LIGHTEST" ? 99999 : -1;

        players.forEach((p) => {
          const b = updatedDrafts[p.id];
          if (!b) return;

          if (round.style === "DRAFT_LIGHTEST") {
            if (b.weightAvg < winningValue) {
              winningValue = b.weightAvg;
              winnerId = p.id;
            }
          } else if (round.style === "DRAFT_CLUTCH") {
            if (b.clutchAvg > winningValue) {
              winningValue = b.clutchAvg;
              winnerId = p.id;
            }
          }
        });

        if (winnerId) {
          const factor = round.number === 15 ? 2 : 1;
          const pts = 25 * factor;
          registerPoints(winnerId, pts);
          
          const winningPlayer = players.find(p => p.id === winnerId);
          if (winningPlayer) {
            winningPlayer.stats.correctAnswers++;
          }
        }

        players.forEach(p => {
          p.stats.totalAnswers++;
        });

        setIsTransitioning(true);
        setTimeout(() => {
          setIsTransitioning(false);
          setRoundPhase("compare");
        }, 1000);
      } else {
        setIsTransitioning(true);
        setTimeout(() => {
          setIsTransitioning(false);
          setFeedbackMsg(null);
          setActivePlayerIndex((p) => (p + 1) % players.length);
        }, 800);
      }
    }
  };

  const resolveDraftTournament = () => {
    const formatWeightLocal = (grams: number) => {
      if (grams >= 1000) {
        return `${(grams / 1000).toFixed(1)}kg`;
      }
      return `${grams}g`;
    };

    if (round.style === "DRAFT_WEIGHT") {
      const playerTotals = players.map((p) => {
        const list = round2Drafts[p.id] || [];
        const sum = list.reduce((acc, b) => acc + b.weightAvg, 0);
        return { pId: p.id, name: p.name, sum, list };
      });

      let highestWeight = -1;
      playerTotals.forEach((pt) => {
        if (pt.sum > highestWeight) {
          highestWeight = pt.sum;
        }
      });

      const winners = playerTotals.filter((pt) => pt.sum === highestWeight && pt.sum > 0);
      const winnerIds = winners.map((w) => w.pId);

      let desc = "";
      if (winners.length === 1) {
        desc = `${winners[0].name} wins the heavyweight championship with a total of ${formatWeightLocal(winners[0].sum)} across ${winners[0].list.length} birds! (+20 pts)`;
      } else if (winners.length > 1) {
        desc = `It's a tie between ${winners.map(w => w.name).join(" and ")} with a total of ${formatWeightLocal(highestWeight)}! (+20 pts each)`;
      } else {
        desc = "No birds were drafted.";
      }

      return (
        <div className="flex flex-col items-center gap-6 py-6 text-center animate-fade-in max-w-4xl mx-auto w-full">
          <h4 className="font-serif text-2xl sm:text-3xl font-bold text-amber-400">Heavyweight Draft Results</h4>
          <p className="text-stone-300 font-medium max-w-lg mb-4 text-xs sm:text-sm">{desc}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full px-4">
            {players.map((p) => {
              const list = round2Drafts[p.id] || [];
              const total = list.reduce((sum, b) => sum + b.weightAvg, 0);
              const isWinner = winnerIds.includes(p.id);
              
              return (
                <div key={p.id} className={`flex flex-col gap-4 bg-stone-900 border ${isWinner ? 'border-emerald-500 bg-stone-900/90 shadow-[0_0_15px_rgba(16,185,129,0.15)]' : 'border-stone-800 bg-stone-900/50'} p-5 rounded-2xl shadow-xl relative`}>
                  {isWinner && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-500 text-stone-950 text-[10px] uppercase font-extrabold px-3 py-1 rounded-full shadow tracking-wider">
                      🏆 Winner (+20 pts)
                    </div>
                  )}
                  
                  <div className="flex justify-between items-center border-b border-stone-850 pb-2 mt-2">
                    <span className="text-sm uppercase tracking-wider text-amber-500 font-black">{p.name}</span>
                    <span className="text-base font-black text-white">{formatWeightLocal(total)}</span>
                  </div>

                  <div className="flex flex-col gap-2">
                    <span className="text-[10px] font-mono text-stone-400 uppercase text-left">Drafted Birds:</span>
                    <div className="grid grid-cols-2 gap-2">
                      {list.map((bird) => (
                        <div key={bird.id} className="flex justify-between items-center bg-stone-950/70 border border-stone-850/80 px-2.5 py-2 rounded-xl">
                          <span className="text-xs font-semibold text-stone-200 truncate pr-1" title={bird.name}>{bird.name}</span>
                          <span className="text-xs font-mono font-black text-amber-400 shrink-0">{formatWeightLocal(bird.weightAvg)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <button
            onClick={() => setRoundPhase("scoreReport")}
            className="bg-amber-500 text-stone-950 font-bold font-serif px-8 py-3 rounded-xl hover:bg-amber-400 text-sm mt-4 tracking-wider transition-all shadow-lg active:scale-95"
          >
            Proceed to Round Summary
          </button>
        </div>
      );
    }

    let winnerId = "";
    let winningValue = round.style === "DRAFT_LIGHTEST" ? 99999 : -1;
    let desc = "";

    players.forEach((p) => {
      const bird = draftedCards[p.id];
      if (!bird) return;

      if (round.style === "DRAFT_WEIGHT") {
        if (bird.weightAvg > winningValue) {
          winningValue = bird.weightAvg;
          winnerId = p.id;
        }
      } else if (round.style === "DRAFT_LIGHTEST") {
        if (bird.weightAvg < winningValue) {
          winningValue = bird.weightAvg;
          winnerId = p.id;
        }
      } else if (round.style === "DRAFT_CLUTCH") {
        if (bird.clutchAvg > winningValue) {
          winningValue = bird.clutchAvg;
          winnerId = p.id;
        }
      }
    });

    const winner = players.find((p) => p.id === winnerId);
    if (winner) {
      const factor = round.number === 15 ? 2 : 1;
      const pts = 25 * factor;
      desc = `${winner.name} wins the Round with the ${draftedCards[winnerId].name}! (+${pts} pts)`;
    } else {
      desc = "No winner could be determined.";
    }

    return (
      <div className="flex flex-col items-center gap-6 py-6 text-center animate-fade-in">
        <h4 className="font-serif text-2xl font-bold text-amber-400">Draft Results Showdown</h4>
        <p className="text-stone-300 font-medium max-w-lg">{desc}</p>
        
        <div className="flex flex-wrap justify-center gap-4 my-2">
          {players.map((p) => {
            const bird = draftedCards[p.id];
            if (!bird) return null;
            return (
              <div key={p.id} className="flex flex-col items-center gap-2 bg-stone-900 border border-stone-800 p-4 rounded-xl shadow">
                <span className="text-xs uppercase tracking-widest text-amber-500 font-bold">{p.name}</span>
                <span className="text-[10px] text-stone-400">{bird.name}</span>
                <span className="text-lg font-bold text-stone-200">
                  {round.style === "DRAFT_CLUTCH" ? `${bird.clutchAvg} eggs` : `${bird.weightAvg >= 1000 ? (bird.weightAvg/1000).toFixed(1)+'kg' : bird.weightAvg+'g'}`}
                </span>
                {p.id === winnerId && (
                  <span className="text-xs font-bold text-emerald-400 mt-1 uppercase animate-bounce leading-none">🏆 Winner</span>
                )}
              </div>
            );
          })}
        </div>
        
        <button
          onClick={() => setRoundPhase("scoreReport")}
          className="bg-amber-500 text-stone-950 font-bold font-serif px-6 py-2.5 rounded-xl hover:bg-amber-400 text-sm mt-4 tracking-wider"
        >
          Proceed to Round Summary
        </button>
      </div>
    );
  };

  // --- WINGSPAN SORTING (Round 3) ---
  const handleMoveSort = (index: number, direction: "up" | "down") => {
    const list = [...sortedCards];
    if (direction === "up" && index > 0) {
      const temp = list[index - 1];
      list[index - 1] = list[index];
      list[index] = temp;
    } else if (direction === "down" && index < list.length - 1) {
      const temp = list[index + 1];
      list[index + 1] = list[index];
      list[index] = temp;
    }
    setSortedCards(list);
  };

  const submitSortedList = () => {
    if (isTransitioning) return;
    const isWeightSort = round.style === "SORT_WEIGHT";
    const sortedAnswers = isWeightSort
      ? [...sortedCards].sort((a, b) => b.weightAvg - a.weightAvg)
      : [...sortedCards].sort((a, b) => b.wingspanAvg - a.wingspanAvg);
    let scoreGained = 0;
    sortedCards.forEach((c, idx) => {
      if (c.id === sortedAnswers[idx].id) {
        scoreGained += 5; // 5 pts per correct card position
      }
    });

    registerPoints(activePlayer.id, scoreGained);
    const correctOrderStr = isWeightSort
      ? sortedAnswers.map(c => `${c.name} (${c.weightAvg} g)`).join(" ➔ ")
      : sortedAnswers.map(c => `${c.name} (${c.wingspanAvg} cm)`).join(" ➔ ");
    setFeedbackMsg({
      text: `Sorting finalized! ${activePlayer.name} earned ${scoreGained} points. Correct Order was: ${correctOrderStr}`,
      type: scoreGained > 10 ? "success" : "info",
    });

    const primaryBird = sortedAnswers[0];
    setReviewData({
      bird: primaryBird,
      title: isWeightSort ? "Weights Balanced!" : "Wingspans Formulated!",
      text: isWeightSort
        ? `${activePlayer.name} finished sorting the weight order. The heaviest species among these is the ${primaryBird.name} weighing an average of ${primaryBird.weightAvg} grams! Correct sequence: ${correctOrderStr}`
        : `${activePlayer.name} finished sorting the wingspan order. The largest species among these is the dynamic ${primaryBird.name} with an impressive ${primaryBird.wingspanAvg} cm wingspan! Correct sequence: ${correctOrderStr}`,
      isCorrect: scoreGained >= 15,
      onContinue: () => rotateOrComplete(0)
    });
  };

  // --- MULTI CHOICE & OTHERS ---
  const handleTrueFalse = (userAnswer: boolean) => {
    if (isTransitioning) return;
    if (!tfQuestion) return;
    const correct = userAnswer === tfQuestion.answer;
    if (correct) {
      setFeedbackMsg({ text: `Brilliant! Your conservation files are perfect. ${tfQuestion.explanation} (+15 pts)`, type: "success" });
      registerPoints(activePlayer.id, 15);
      activePlayer.stats.correctAnswers++;
      unlockBird(tfQuestion.bird.id, activePlayer.name);
    } else {
      setFeedbackMsg({ text: `Incorrect field estimation! ${tfQuestion.explanation} Statement was actually ${tfQuestion.answer ? "TRUE" : "FALSE"}.`, type: "error" });
    }
    activePlayer.stats.totalAnswers++;

    setReviewData({
      bird: tfQuestion.bird,
      title: correct ? "Fact Checked Perfectly!" : "Telemetry Discrepancy",
      text: correct 
        ? `Spot on! ${tfQuestion.explanation}`
        : `Ah, mismatch under observation! ${tfQuestion.explanation}`,
      isCorrect: correct,
      onContinue: () => rotateOrComplete(0)
    });
  };

  const handleSpotRarity = (bird: BirdCard) => {
    if (isTransitioning) return;
    // Find the max rarity card out of rarityLevelPool
    const maxRarity = Math.max(...rarityLevelPool.map((b) => b.rarity));
    const isCorrect = bird.rarity === maxRarity;
    const winningBird = rarityLevelPool.find((b) => b.rarity === maxRarity) || bird;
    if (isCorrect) {
      setFeedbackMsg({ text: `Expert Spotting! The ${bird.name} is indeed the scarcest of this flock with Rarity Level ${maxRarity}! (+20 pts)`, type: "success" });
      registerPoints(activePlayer.id, 20);
      activePlayer.stats.correctAnswers++;
      unlockBird(winningBird.id, activePlayer.name);
    } else {
      const correctBird = rarityLevelPool.find((b) => b.rarity === maxRarity);
      setFeedbackMsg({ text: `Incorrect! The ${correctBird?.name} (Rarity: ${maxRarity}) was the scarcest option. Your choice ${bird.name} has Rarity Level ${bird.rarity}.`, type: "error" });
    }
    activePlayer.stats.totalAnswers++;

    setReviewData({
      bird: winningBird,
      title: isCorrect ? "Master Conservationist!" : "Field Rarity Surveyed",
      text: isCorrect
        ? `Indeed! The scarcest species in this group is the ${winningBird.name} (Rarity level: ${winningBird.rarity}).`
        : `Actually, the ${winningBird.name} holds the highest Rarity level of ${winningBird.rarity} in this flock. Your choice ${bird.name} has a rarity of ${bird.rarity}.`,
      isCorrect,
      onContinue: () => rotateOrComplete(0)
    });
  };

  // --- GRID SEARCH / MEMORY (Round 12) ---
  const handleGridCardClick = (index: number) => {
    if (isTransitioning) return;
    if (gridCards[index].flipped || gridCards[index].matched || selectedGridIndices.length >= 2) return;

    const list = [...gridCards];
    list[index].flipped = true;
    setGridCards(list);

    const updatedGridIndices = [...selectedGridIndices, index];
    setSelectedGridIndices(updatedGridIndices);

    if (updatedGridIndices.length === 2) {
      const [firstIdx, secondIdx] = updatedGridIndices;
      const b1 = list[firstIdx].bird;
      const b2 = list[secondIdx].bird;

      if (b1.group === b2.group) {
        // MATCH!
        setIsTransitioning(true);
        setTimeout(() => {
          setIsTransitioning(false);
          const matchedList = [...list];
          matchedList[firstIdx].matched = true;
          matchedList[secondIdx].matched = true;
          setGridCards(matchedList);
          setSelectedGridIndices([]);
          registerPoints(activePlayer.id, 8);
          setFeedbackMsg({ text: `Match Spot! Both belong to '${b1.group}'! (+8 pts)`, type: "success" });
          
          // Check if game complete
          if (matchedList.every(tile => tile.matched)) {
            setIsTransitioning(true);
            setTimeout(() => {
              setIsTransitioning(false);
              setRoundPhase("scoreReport");
            }, 1200);
          }
        }, 850);
      } else {
        // MISMATCH
        setIsTransitioning(true);
        setTimeout(() => {
          setIsTransitioning(false);
          const resetList = [...list];
          resetList[firstIdx].flipped = false;
          resetList[secondIdx].flipped = false;
          setGridCards(resetList);
          setSelectedGridIndices([]);
          setFeedbackMsg(null);
          
          // Rotate active player so both have chance to search!
          setActivePlayerIndex((p) => (p + 1) % players.length);
        }, 1500);
      }
    }
  };

  // --- TRUMP CARD WARFARE (Round 13) ---
  const handleChooseTrumpStat = (statName: "wingspanAvg" | "weightAvg" | "lengthAvg" | "clutchAvg") => {
    if (isTransitioning) return;
    setSelectedTrumpStat(statName);

    // Resolve Trump fight
    let winnerId = "";
    let winningValue = -1;

    players.forEach((p) => {
      const card = trumpCards[p.id];
      if (!card) return;
      const val = card[statName];
      if (val > winningValue) {
        winningValue = val;
        winnerId = p.id;
      }
    });

    setIsTransitioning(true);
    setTimeout(() => {
      setIsTransitioning(false);
      if (winnerId) {
        registerPoints(winnerId, 25);
      }
      setRoundPhase("compare");
    }, 1500);
  };

  const renderTrumpShowdown = () => {
    let winnerId = "";
    let winningValue = -1;
    let desc = "";

    if (selectedTrumpStat) {
      players.forEach((p) => {
        const card = trumpCards[p.id];
        if (!card) return;
        const val = card[selectedTrumpStat];
        if (val > winningValue) {
          winningValue = val;
          winnerId = p.id;
        }
      });
      const winner = players.find((p) => p.id === winnerId);
      desc = winner
        ? `${winner.name} wins the Trump Battle with ${trumpCards[winnerId].name}! (+25 pts)`
        : "Draw!";
    }

    return (
      <div className="flex flex-col items-center gap-6 py-6 text-center animate-fade-in text-stone-100">
        <h4 className="font-serif text-2xl font-bold text-amber-500 uppercase">Trump Arena Battle results</h4>
        <p className="text-stone-300 font-semibold max-w-lg">{desc}</p>
        
        <div className="flex flex-wrap justify-center gap-6 my-4">
          {players.map((p) => {
            const card = trumpCards[p.id];
            if (!card) return null;
            return (
              <div key={p.id} className="flex flex-col items-center gap-2">
                <span className="text-xs uppercase tracking-widest text-amber-500 font-bold">{p.name}</span>
                <BirdCardComponent bird={card} isFlipped={false} />
                <span className="text-sm font-mono text-stone-300 bg-stone-900 border border-stone-800 px-3 py-1 rounded-full mt-2">
                  Stat: {selectedTrumpStat ? String(card[selectedTrumpStat]) : "-"}
                </span>
                {p.id === winnerId && (
                  <span className="text-sm font-bold text-emerald-400 mt-1 uppercase animate-bounce">🏆 Winner</span>
                )}
              </div>
            );
          })}
        </div>
        
        <button
          onClick={() => setRoundPhase("scoreReport")}
          className="bg-amber-500 text-stone-950 font-serif font-bold px-6 py-2.5 rounded-xl hover:bg-amber-400 text-sm mt-4 tracking-wider"
        >
          See Round Leaderboard
        </button>
      </div>
    );
  };

  // --- LATIN MATCHING (Round 11) ---
  const handleLatinBirdSelect = (bird: BirdCard) => {
    if (isTransitioning) return;
    setSelectedLatinBird(bird);
  };

  const handleLatinScientificSelect = (scName: string) => {
    if (isTransitioning) return;
    if (!selectedLatinBird) return;
    
    const isGroupMatchStyle = round.style === "GROUP_MATCH";
    const targetCheck = isGroupMatchStyle ? selectedLatinBird.group : selectedLatinBird.scientificName;
    
    if (targetCheck === scName) {
      const newMatched = [...matchedLatinIds, selectedLatinBird.id];
      setMatchedLatinIds(newMatched);
      registerPoints(activePlayer.id, 8);
      setFeedbackMsg({
        text: isGroupMatchStyle 
          ? `Sensational Familial Knowledge! Matched ${selectedLatinBird.name} to its group: ${selectedLatinBird.group}! (+8 pts)`
          : `Sensational Latin Knowledge! Matched ${selectedLatinBird.name} to ${selectedLatinBird.scientificName}! (+8 pts)`,
        type: "success"
      });
      
      if (newMatched.length === latinMatches.length) {
        setReviewData({
          bird: selectedLatinBird,
          title: isGroupMatchStyle ? "Taxonomic Groups Cleared!" : "Latin Taxonomy Cleared!",
          text: isGroupMatchStyle
            ? `Sensational classification skills! You matched all regional bird cards correctly to their scientific family groups!`
            : `Sensational taxonomy skills! You matched all regional bird classifications correctly to their ancient scientific Latin tags!`,
          isCorrect: true,
          onContinue: () => rotateOrComplete(0)
        });
      }
    } else {
      setFeedbackMsg({
        text: isGroupMatchStyle
          ? `Incorrect familial link! The taxonomic group for ${selectedLatinBird.name} is '${selectedLatinBird.group}'. Try matching again.`
          : `Incorrect taxonomic link! The scientific name for ${selectedLatinBird.name} is '${selectedLatinBird.scientificName}'. Try matching again.`,
        type: "error"
      });
    }
    setSelectedLatinBird(null);
  };

  // --- TRIVIA MULTI-SELECT (Round 14) ---
  const handleToggleMultiSelect = (id: string) => {
    if (isTransitioning) return;
    if (selectedMultiIds.includes(id)) {
      setSelectedMultiIds(prev => prev.filter(x => x !== id));
    } else {
      setSelectedMultiIds(prev => [...prev, id]);
    }
  };

  const submitMultiSelect = () => {
    if (isTransitioning) return;
    // Correct answers are RED conservation status
    const correctBirds = decoyBirds.filter(b => b.conservationStatus === "Red");
    const correctIds = correctBirds.map(b => b.id);
    let correctCount = 0;
    let incorrectCount = 0;
    
    selectedMultiIds.forEach(id => {
      if (correctIds.includes(id)) {
        correctCount++;
      } else {
        incorrectCount++;
      }
    });

    const scoreGained = Math.max(0, (correctCount * 8) - (incorrectCount * 4)); // 8 pts for match, minus 4 penalty

    registerPoints(activePlayer.id, scoreGained);
    const correctNamesStr = correctBirds.map(b => b.name).join(", ");
    setFeedbackMsg({
      text: `${activePlayer.name} finished. Correctly flagged ${correctCount} of ${correctIds.length} red-listed species (Incorrect choices: ${incorrectCount}). Earned ${scoreGained} pts! The correct red-listed species are: ${correctNamesStr || "None in this flock"}.`,
      type: "success",
    });

    const showcaseBird = correctBirds[0] || decoyBirds[0] || deck[0];
    setReviewData({
      bird: showcaseBird,
      title: "Red-Listed Species Audited!",
      text: `${activePlayer.name} finished searching conservation records. Found ${correctCount} of ${correctIds.length} red-listed species (Penalty: ${incorrectCount}). List of correct species: ${correctNamesStr || "None present"}. Featured species on display: ${showcaseBird.name}.`,
      isCorrect: scoreGained >= 15,
      onContinue: () => rotateOrComplete(0)
    });
  };

  // --- GRAND FINALE PLACEMENTS (Round 15) ---
  const handleRearrangeFinale = (pId: string, index: number, direction: "up" | "down") => {
    if (isTransitioning) return;
    const list = [...(finalePlacements[pId] || [])];
    if (direction === "up" && index > 0) {
      const temp = list[index - 1];
      list[index - 1] = list[index];
      list[index] = temp;
    } else if (direction === "down" && index < list.length - 1) {
      const temp = list[index + 1];
      list[index + 1] = list[index];
      list[index] = temp;
    }
    setFinalePlacements(prev => ({ ...prev, [pId]: list }));
  };

  const submitFinaleScore = () => {
    if (isTransitioning) return;
    const hand = finalePlacements[activePlayer.id] || [];
    // Score formulation: (Card 1 rarity * 10) + (Card 2 wingspan * 0.5) + (Card 3 weight * 0.05) - ALL DOUBLED
    const r1 = hand[0]?.rarity || 1;
    const w2 = hand[1]?.wingspanAvg || 20;
    const wt3 = hand[2]?.weightAvg || 50;

    const calcBase = Math.floor(r1 * 10 + w2 * 0.5 + Math.min(100, wt3 * 0.05));
    const finalPts = calcBase * 2; // Doubled for finale!

    registerPoints(activePlayer.id, finalPts);
    setFeedbackMsg({
      text: `${activePlayer.name} placed cards on the scale. Aggregate score registered as ${finalPts} points (DOUBLE Rarity & Size scale combined)!`,
      type: "success",
    });

    const highlightBird = hand[0] || deck[0];
    setReviewData({
      bird: highlightBird,
      title: "Scale Balanced in Finale!",
      text: `${activePlayer.name} balanced their three specimina. The centerpiece of their scale is the rare ${highlightBird.name} adding enormous scale value! Total registered points are: ${finalPts}!`,
      isCorrect: true,
      onContinue: () => rotateOrComplete(0)
    });
  };

  // --- DIET / HABITAT CLAIMS ---
  const handleClaimMapping = (bird: BirdCard) => {
    if (isTransitioning) return;
    const isDiet = round.style === "DIET_CLAIM";
    const actualValue = isDiet ? bird.primaryDiet : bird.habitat;
    const isCorrect = actualValue === targetCategory;
    
    if (isCorrect) {
      setFeedbackMsg({ 
        text: `Excellent Claim! The ${bird.name} matches the target ${isDiet ? "diet" : "habitat"} of [${targetCategory}]! (+15 pts)`, 
        type: "success" 
      });
      registerPoints(activePlayer.id, 15);
      activePlayer.stats.correctAnswers++;
    } else {
      setFeedbackMsg({ 
        text: `Incorrect Claim! The ${bird.name}'s ${isDiet ? "diet" : "habitat"} is actually [${actualValue}], not [${targetCategory}].`, 
        type: "error" 
      });
    }
    activePlayer.stats.totalAnswers++;
    
    // Filter active cards pool
    setActivePool(prev => prev.filter(x => x.id !== bird.id));

    setReviewData({
      bird: bird,
      title: isCorrect ? "Survival ecology verified!" : "Ecology Claim Rejected",
      text: isCorrect
        ? `Superb! The ${bird.name} correctly inhabits/consumes [${actualValue}].`
        : `The ${bird.name}'s true classification is [${actualValue}], which does not qualify as [${targetCategory}].`,
      isCorrect,
      onContinue: () => rotateOrComplete(0)
    });
  };


  // --- MAIN RENDERERS FOR PLAY MECHANICS ---
  const renderInteractiveGameplay = () => {
    if (reviewData) {
      return (
        <div className="flex flex-col items-center gap-6 text-center animate-fade-in w-full max-w-2xl mx-auto py-2">
          {/* Completion Badge */}
          <div className="flex items-center gap-2">
            <span className={`text-xs font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow ${
              reviewData.isCorrect 
                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/45" 
                : "bg-rose-500/20 text-rose-300 border border-rose-500/45"
            }`}>
              {reviewData.isCorrect ? "✦ OBSERVATION CONFIRMED ✦" : "✦ SIGHTING MISMATCH ✦"}
            </span>
          </div>

          <p className="font-serif text-lg text-stone-200 tracking-tight leading-relaxed max-w-xl">
            {reviewData.text}
          </p>

          {/* Majestic Species Dossier Card */}
          <div className="bg-stone-900/90 border border-stone-850 p-5 sm:p-6 rounded-3xl w-full flex flex-col md:flex-row items-center gap-6 shadow-2xl relative">
            {/* Real Bird Illustration */}
            <div className="shrink-0 scale-95 sm:scale-100">
              <BirdCardComponent 
                bird={reviewData.bird} 
                isFlipped={false} 
                disabled={true} 
              />
            </div>

            {/* Dossier info sheet */}
            <div className="text-left flex-1 min-w-0 w-full">
              <span className="text-[10px] bg-amber-500/10 text-amber-400 py-1 px-3 rounded-full uppercase tracking-widest font-mono font-bold">
                SPECIES FIELD DOSSIER
              </span>
              <h4 className="text-2xl font-serif font-black text-amber-400 uppercase tracking-tight mt-2.5">
                {reviewData.bird.name}
              </h4>
              <span className="block font-mono text-xs italic text-stone-400 uppercase tracking-widest">
                {reviewData.bird.scientificName}
              </span>

              {/* Bio Block with fun fact */}
              <div className="mt-4 p-3 bg-stone-950/50 rounded-xl border border-stone-800/80">
                <span className="block text-[8px] font-mono text-stone-500 uppercase tracking-wider mb-1">FIELD OBSERVATION RECORD</span>
                <p className="font-serif italic text-xs leading-relaxed text-stone-300">
                  "{reviewData.bird.funFact}"
                </p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 mt-4 text-xs font-mono">
                <div className="flex justify-between border-b border-stone-800 pb-1">
                  <span className="text-stone-500 uppercase text-[10px]">HABITAT:</span>
                  <span className="text-stone-300 font-bold truncate max-w-[120px]">{reviewData.bird.habitat}</span>
                </div>
                <div className="flex justify-between border-b border-stone-800 pb-1">
                  <span className="text-stone-500 uppercase text-[10px]">DIET:</span>
                  <span className="text-stone-300 font-bold truncate max-w-[120px]">{reviewData.bird.primaryDiet}</span>
                </div>
                <div className="flex justify-between border-b border-stone-800 pb-1">
                  <span className="text-stone-500 uppercase text-[10px]">WINGSPAN:</span>
                  <span className="text-amber-400 font-black">{reviewData.bird.wingspanAvg} cm</span>
                </div>
                <div className="flex justify-between border-b border-stone-800 pb-1">
                  <span className="text-stone-500 uppercase text-[10px]">RARITY:</span>
                  <span className={`font-black ${
                    reviewData.bird.rarity >= 4 ? "text-rose-400" : reviewData.bird.rarity >= 3 ? "text-amber-400" : "text-emerald-400"
                  }`}>Level {reviewData.bird.rarity}</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={handleReviewContinue}
            className="w-full max-w-xs bg-amber-500 hover:bg-amber-400 text-stone-950 font-sans font-black tracking-widest text-sm py-4 rounded-xl shadow-lg transition-all transform active:scale-95 duration-150 uppercase cursor-pointer"
            id="continue-after-answer"
          >
            Continue Expedition ➔
          </button>
        </div>
      );
    }

    switch (round.style) {
      case "SINGLE_CHOICE": {
        if (!targetBird) return null;
        
        // If they have made a choice, display the actual bird illustration and name in full glory!
        if (feedbackMsg) {
          return (
            <div className="flex flex-col items-center gap-4 text-center animate-fade-in">
              <span className="text-[10px] bg-amber-500/20 text-amber-300 py-1.5 px-4 rounded-full uppercase tracking-wider font-mono font-bold block mb-1">
                ✦ IDENTIFICATION REVEAL ✦
              </span>
              <BirdCardComponent 
                bird={targetBird} 
                isFlipped={false} 
                disabled={true} 
              />
              <div className="text-center max-w-sm">
                <span className="block text-[8px] font-mono text-stone-400 uppercase tracking-widest leading-none">Correct Species</span>
                <span className="block text-xl font-serif font-black text-amber-400 uppercase tracking-wide leading-tight mt-1">
                  {targetBird.name}
                </span>
                <p className="font-serif italic text-sm text-stone-300 mt-3 leading-relaxed bg-stone-950/40 p-3 rounded-xl border border-stone-800">
                  "{targetBird.funFact}"
                </p>
              </div>
            </div>
          );
        }

        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in">
            <div className="bg-stone-950/40 p-4 rounded-xl border border-stone-800 max-w-xl">
              <span className="text-[10px] text-amber-500 font-bold uppercase tracking-widest block mb-1">
                ✦ FIELD SIGHTING MEMORANDUM
              </span>
              <p className="font-serif italic text-base text-stone-200">
                "{getSanitizedQuestionPrompt(targetBird)}"
              </p>
            </div>

            <span className="text-xs text-stone-400 mt-2 mb-2">
              Which species has these distinctive habits? Click the correct visual card to identify:
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {decoyBirds.map((bird) => {
                const isDiscarded = disabledDecoyIds.includes(bird.id);
                return (
                  <div key={bird.id} className="transition-transform hover:scale-103 duration-300 relative">
                    {isDiscarded ? (
                      <div className="relative opacity-25 grayscale cursor-not-allowed">
                        <div className="absolute inset-0 bg-stone-950/80 z-20 rounded-2xl flex items-center justify-center border-2 border-stone-800">
                          <span className="font-mono text-[9px] text-stone-500 font-extrabold uppercase tracking-widest">DISCARDED</span>
                        </div>
                        <BirdCardComponent
                          bird={bird}
                          isFlipped={false}
                          obscuredStats={["conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg", "rarity"]}
                          disabled={true}
                        />
                      </div>
                    ) : (
                      <BirdCardComponent
                        bird={bird}
                        isFlipped={false}
                        obscuredStats={["conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg", "rarity"]}
                        onClick={() => handleSingleAnswer(bird)}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "SONIC_IDENTIFY": {
        if (!targetBird) return null;
        return (
          <div className="flex flex-col items-center gap-5 text-center animate-fade-in w-full max-w-xl">
            <span className="text-[10px] bg-emerald-500/10 text-emerald-300 py-1.5 px-4 rounded-full uppercase tracking-wider font-mono font-bold block">
              ✦ ACOUSTIC SPECTRUM FIELD ANALYZER ✦
            </span>

            {/* Simulated Audiogram Waveform Interface */}
            <div className="w-full bg-stone-950/80 border border-stone-850 rounded-3xl p-6 flex flex-col items-center gap-4 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500/20 via-amber-500/40 to-emerald-500/20" />
              
              <div className="flex items-center gap-4 justify-center">
                <button
                  onClick={() => playBirdSong(targetBird.group, targetBird.name)}
                  className="w-16 h-16 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 font-black flex items-center justify-center shadow-lg active:scale-95 transition-all text-xl cursor-pointer hover:shadow-amber-500/20"
                >
                  🔊
                </button>
                <div className="text-left leading-tight">
                  <span className="text-stone-400 font-mono text-[9px] uppercase tracking-wider block">Procedural Biophonic Sound</span>
                  <span className="text-sm font-sans font-black text-amber-400 uppercase tracking-tight block mt-0.5">PLAY ACOUSTIC CALL</span>
                  <span className="text-stone-500 font-mono text-[8px] leading-tight block mt-1">Realistic Biophonic Synthesis Engine</span>
                </div>
              </div>

              {/* Genuine High-Fidelity Audio Spectrogram Waves reacting live to Web Audio API */}
              <div className="w-full max-w-md mt-2 p-1.5 rounded-xl bg-stone-900/80 border border-stone-825 overflow-hidden">
                <AudioSpectrogram className="h-12 w-full border-0 rounded-lg bg-[#0c1310]/60" type="wave" color="mixed" />
              </div>
            </div>

            <span className="text-xs text-stone-400 uppercase tracking-wider mt-2 mb-1">
              Select the correct vocalist below after listening:
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {decoyBirds.map((bird) => {
                const isDiscarded = disabledDecoyIds.includes(bird.id);
                return (
                  <div key={bird.id} className="transition-transform hover:scale-103 duration-300 relative">
                    {isDiscarded ? (
                      <div className="relative opacity-25 grayscale cursor-not-allowed">
                        <div className="absolute inset-0 bg-stone-950/80 z-20 rounded-2xl flex items-center justify-center border-2 border-stone-800">
                          <span className="font-mono text-[9px] text-stone-500 font-extrabold uppercase tracking-widest">DISCARDED</span>
                        </div>
                        <BirdCardComponent bird={bird} isFlipped={false} disabled={true} obscuredStats={["conservationStatus"]} />
                      </div>
                    ) : (
                      <BirdCardComponent
                        bird={bird}
                        isFlipped={false}
                        obscuredStats={["conservationStatus"]}
                        onClick={() => handleSingleAnswer(bird)}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "CALL_CHALLENGE": {
        if (!targetBird) return null;
        return (
          <div className="flex flex-col items-center gap-5 text-center animate-fade-in w-full max-w-xl">
            <span className="text-[10px] bg-amber-500/10 text-amber-300 py-1.5 px-4 rounded-full uppercase tracking-wider font-mono font-bold block leading-none">
              ✦ ONOMATOPOEIA ACOUSTIC DOSSIER ✦
            </span>

            {/* Sound description badge */}
            <div className="w-full bg-stone-900 border-2 border-amber-500/20 rounded-3xl p-6 shadow-xl relative text-stone-200">
              <span className="text-[9px] font-mono text-amber-500 uppercase font-black block tracking-widest mb-1.5">TRANSCRIPT OF VOCAL DESCRIPTION:</span>
              <p className="font-serif text-[15px] sm:text-base italic leading-relaxed text-amber-100 bg-stone-950/50 p-4 border border-stone-800 rounded-2xl min-h-[50px]">
                "{getBirdVocalizationDescription(targetBird)}"
              </p>
            </div>

            <span className="text-xs text-stone-400 uppercase tracking-wider mt-2 mb-1">
              Which species matches this phonetic sound signature?
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {decoyBirds.map((bird) => {
                const isDiscarded = disabledDecoyIds.includes(bird.id);
                return (
                  <div key={bird.id} className="transition-transform hover:scale-103 duration-300 relative">
                    {isDiscarded ? (
                      <div className="relative opacity-25 grayscale cursor-not-allowed">
                        <div className="absolute inset-0 bg-stone-950/80 z-20 rounded-2xl flex items-center justify-center border-2 border-stone-800">
                          <span className="font-mono text-[9px] text-stone-500 font-extrabold uppercase tracking-widest">DISCARDED</span>
                        </div>
                        <BirdCardComponent bird={bird} isFlipped={false} disabled={true} obscuredStats={["conservationStatus"]} />
                      </div>
                    ) : (
                      <BirdCardComponent
                        bird={bird}
                        isFlipped={false}
                        obscuredStats={["conservationStatus"]}
                        onClick={() => handleSingleAnswer(bird)}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "SORT_WEIGHT": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full">
            <span className="text-xs text-stone-400 uppercase tracking-wider">
              Rearrange cards using arrows until they descend from HEAVIEST (left) to LIGHTEST (right) average weight
            </span>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-4">
              {sortedCards.map((bird, idx) => (
                <div key={bird.id} className="flex flex-col items-center gap-2 bg-stone-900/60 p-2.5 rounded-xl border border-stone-800">
                  <span className="text-[10px] font-mono text-stone-400">Position {idx + 1}</span>
                  <BirdCardComponent bird={bird} isFlipped={false} disabled={true} obscuredStats={["weightAvg"]} />
                  
                  {/* Sorting controls */}
                  <div className="flex gap-2 w-full justify-between items-center mt-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => handleMoveSort(idx, "up")}
                      className="px-2.5 py-1 bg-stone-800/80 hover:bg-amber-500 rounded text-xs text-stone-200 disabled:opacity-25"
                    >
                      ◀
                    </button>
                    <span className="text-[10px] font-mono font-bold text-amber-400">
                      Weight: ???
                    </span>
                    <button
                      type="button"
                      disabled={idx === sortedCards.length - 1}
                      onClick={() => handleMoveSort(idx, "down")}
                      className="px-2.5 py-1 bg-stone-800/80 hover:bg-amber-500 rounded text-xs text-stone-200 disabled:opacity-25"
                    >
                      ▶
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={submitSortedList}
              className="bg-emerald-600 hover:bg-emerald-500 text-stone-100 font-serif font-bold text-sm px-8 py-3 rounded-2xl mx-auto shadow mt-6 tracking-wide uppercase"
            >
              Verify Weights Sorting positions
            </button>
          </div>
        );
      }

      case "GROUP_MATCH": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in max-w-3xl w-full">
            {selectedLatinBird ? (
              <div className="flex flex-col items-center gap-3 bg-stone-900 border border-stone-850 p-6 rounded-3xl max-w-xl w-full mb-2 shadow-xl animate-fade-in">
                <span className="text-[10px] bg-amber-500/20 text-amber-300 py-1 px-3 rounded-full uppercase tracking-wider font-bold block">
                  ✦ TARGET GROUP LINKUP
                </span>
                
                <div className="flex flex-col sm:flex-row items-center gap-6 mt-2 w-full">
                  <BirdCardComponent
                    bird={selectedLatinBird}
                    isFlipped={false}
                    disabled={true}
                    obscuredStats={["scientificName", "conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg", "rarity"]}
                  />
                  <div className="text-center sm:text-left leading-snug flex-1">
                    <span className="block text-[8px] font-mono text-stone-400 uppercase tracking-widest">Selected Species</span>
                    <h4 className="text-xl font-serif font-black text-amber-400 uppercase tracking-tight mt-0.5">{selectedLatinBird.name}</h4>
                    <span className="block text-[11px] text-stone-300 font-mono italic uppercase mt-1">Avian Group: Hidden 🛈</span>
                    <p className="font-serif italic text-sm text-stone-300 mt-4 leading-relaxed bg-stone-950/40 p-3 rounded-xl border border-stone-850">
                      "{getSanitizedQuestionPrompt(selectedLatinBird)}"
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-stone-900/60 border border-stone-850 p-4 rounded-2xl max-w-sm mb-2 text-stone-400 text-xs tracking-wide">
                Please <span className="text-amber-400 font-bold">Select a bird name</span> in the column below to reveal its visual card and unlock Taxonomic Group matching!
              </div>
            )}

            <span className="text-xs text-stone-400 uppercase tracking-wider mb-2">
              Select a bird on the left, then click its corresponding scientific taxonomic family group on the right.
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full mt-2">
              {/* Left Column: English Birds */}
              <div className="flex flex-col gap-2 bg-stone-950/50 p-4 rounded-2xl border border-stone-850">
                <span className="text-xs font-mono text-amber-500 font-bold uppercase mb-2">English Names</span>
                {latinMatches.map((birdObj) => {
                  const bCard = deck.find(b => b.id === birdObj.id);
                  if (!bCard) return null;
                  const isMatched = matchedLatinIds.includes(bCard.id);
                  const isSelected = selectedLatinBird?.id === bCard.id;

                  return (
                    <button
                      key={bCard.id}
                      disabled={isMatched}
                      onClick={() => handleLatinBirdSelect(bCard)}
                      type="button"
                      className={`py-3 px-4 rounded-xl text-left font-serif font-black text-sm uppercase transition-all duration-300 flex justify-between items-center ${
                        isMatched
                          ? "bg-zinc-800/40 text-stone-600 border border-zinc-900 line-through cursor-not-allowed"
                          : isSelected
                          ? "bg-amber-500 text-stone-950 font-bold"
                          : "bg-stone-900 hover:bg-stone-800 text-stone-100 border border-stone-800"
                      }`}
                    >
                      <span>{bCard.name}</span>
                      {isMatched && <span className="text-[9px] text-emerald-500">✓ Connected</span>}
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Taxonomy Groups */}
              <div className="flex flex-col gap-2 bg-stone-950/50 p-4 rounded-2xl border border-stone-850">
                <span className="text-xs font-mono text-amber-500 font-bold uppercase mb-2">Phylogenetic Avian Group</span>
                {shuffledScientificNames.map((birdObj) => {
                  // Find if we have already matched this family
                  const isMatched = matchedLatinIds.includes(birdObj.id);

                  return (
                    <button
                      key={birdObj.id}
                      disabled={isMatched || !selectedLatinBird}
                      onClick={() => handleLatinScientificSelect(birdObj.scientificName)}
                      type="button"
                      className={`py-3 px-4 rounded-xl text-left font-mono font-bold text-sm transition-all duration-300 flex justify-between items-center ${
                        isMatched
                          ? "bg-zinc-800/40 text-stone-600 border border-zinc-900 line-through cursor-not-allowed"
                          : selectedLatinBird
                          ? "bg-stone-900 hover:bg-amber-600/30 text-stone-100 border border-amber-800/50 cursor-pointer"
                          : "bg-stone-900/40 text-stone-500 border border-stone-950 cursor-not-allowed"
                      }`}
                    >
                      <span>{birdObj.scientificName}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        );
      }
      
      case "DRAFT_WEIGHT": {
        const poolLabel = `Draft heavy birds - select all of them and the highest total weight wins! (${activePool.length} options)`;

        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full">
            <span className="text-sm font-semibold text-amber-500 uppercase tracking-wider">{poolLabel}</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {activePool.map((bird) => {
                const draftedByPlayerId = Object.keys(round2Drafts).find(pId => round2Drafts[pId]?.some(b => b.id === bird.id));
                const draftedByPlayer = draftedByPlayerId ? players.find(p => p.id === draftedByPlayerId) : null;

                return (
                  <div key={bird.id} className="relative transition-transform hover:scale-105 duration-300">
                    <BirdCardComponent
                      bird={bird}
                      isFlipped={false}
                      disabled={!!draftedByPlayer}
                      obscuredStats={["weightAvg"]}
                      onClick={() => handleDraftPick(bird)}
                    />
                    {draftedByPlayer && (
                      <div className="absolute inset-0 bg-stone-950/85 flex flex-col items-center justify-center rounded-2xl border-4 border-amber-500/65 z-10 p-4 select-none">
                        <span className="text-[10px] bg-amber-500/20 text-amber-400 py-1 px-2.5 rounded-full uppercase tracking-widest font-extrabold mb-2">
                          Stamped Select
                        </span>
                        <span className="text-sm font-black text-white uppercase tracking-wider text-center break-words max-w-[200px]">
                          {draftedByPlayer.name}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "DRAFT_LIGHTEST":
      case "DRAFT_CLUTCH": {
        const poolLabel = 
          round.style === "DRAFT_LIGHTEST" ? "Draft small/light bird - lightest average weights win!"
          : "Draft nesting champion - maximum egg clutching counts win!";

        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in">
            <span className="text-sm font-semibold text-amber-500 uppercase tracking-wider">{poolLabel}</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {activePool.map((bird) => (
                <div key={bird.id} className="transition-transform hover:scale-105 duration-300">
                  <BirdCardComponent
                    bird={bird}
                    isFlipped={false}
                    obscuredStats={round.style === "DRAFT_CLUTCH" ? ["clutchAvg"] : ["weightAvg"]}
                    onClick={() => handleDraftPick(bird)}
                  />
                </div>
              ))}
            </div>
          </div>
        );
      }

      case "SORT_WINGSPAN": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full">
            <span className="text-xs text-stone-400 uppercase tracking-wider">
              Rearrange cards using arrows until they descend from LARGEST WINGSPAN (left) to SMALLEST (right)
            </span>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-4">
              {sortedCards.map((bird, idx) => (
                <div key={bird.id} className="flex flex-col items-center gap-2 bg-stone-900/60 p-2.5 rounded-xl border border-stone-800">
                  <span className="text-[10px] font-mono text-stone-400">Position {idx + 1}</span>
                  <BirdCardComponent bird={bird} isFlipped={false} disabled={true} obscuredStats={["wingspanAvg"]} />
                  
                  {/* Sorting controls */}
                  <div className="flex gap-2 w-full justify-between items-center mt-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => handleMoveSort(idx, "up")}
                      className="px-2.5 py-1 bg-stone-800/80 hover:bg-amber-500 rounded text-xs text-stone-200 disabled:opacity-25"
                    >
                      ◀
                    </button>
                    <span className="text-[10px] font-mono font-bold text-amber-500">
                      Wingspan: ???
                    </span>
                    <button
                      type="button"
                      disabled={idx === sortedCards.length - 1}
                      onClick={() => handleMoveSort(idx, "down")}
                      className="px-2.5 py-1 bg-stone-800/80 hover:bg-amber-500 rounded text-xs text-stone-200 disabled:opacity-25"
                    >
                      ▶
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={submitSortedList}
              className="bg-emerald-600 hover:bg-emerald-500 text-stone-100 font-serif font-bold text-sm px-8 py-3 rounded-2xl mx-auto shadow mt-6 tracking-wide uppercase"
            >
              Verify Sorting positions
            </button>
          </div>
        );
      }

      case "ODD_ONE_OUT": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in">
            <span className="text-xs text-stone-400 uppercase tracking-wider">
              Assess card specifications. Click on the bird that has the HIGHEST RARITY ranking (1 = Standard, 5 = Elusive/Rare)
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {rarityLevelPool.map((bird) => {
                const isDiscarded = disabledDecoyIds.includes(bird.id);
                return (
                  <div key={bird.id} className="transition-transform hover:scale-105 duration-300 relative">
                    {isDiscarded ? (
                      <div className="relative opacity-25 grayscale cursor-not-allowed">
                        <div className="absolute inset-0 bg-stone-950/80 z-20 rounded-2xl flex items-center justify-center border-2 border-stone-800">
                          <span className="font-mono text-[9px] text-stone-500 font-extrabold uppercase tracking-widest">DISCARDED</span>
                        </div>
                        <BirdCardComponent
                          bird={bird}
                          isFlipped={false}
                          obscuredStats={["conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg"]}
                          disabled={true}
                        />
                      </div>
                    ) : (
                      <BirdCardComponent
                        bird={bird}
                        isFlipped={false}
                        obscuredStats={["conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg"]}
                        onClick={() => handleSpotRarity(bird)}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "TRUE_FALSE": {
        if (!tfQuestion) return null;
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in">
            <div className="flex flex-col sm:flex-row items-center gap-6 bg-stone-900 border border-stone-850 p-6 rounded-3xl max-w-2xl">
              <BirdCardComponent
                bird={tfQuestion.bird}
                isFlipped={false}
                disabled={true}
                obscuredStats={["conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg", "rarity"]}
              />
              
              <div className="flex flex-col justify-center items-center sm:items-start gap-3 flex-1">
                <span className="text-[10px] bg-amber-500/20 text-amber-300 py-1 px-3 rounded-full uppercase tracking-wider font-bold">
                  ✦ RAPID FIELD ACCURACY
                </span>
                
                {/* Embedded Beautiful Species Header Banner */}
                <div className="bg-stone-950/60 p-3 rounded-2xl border border-stone-800/80 w-full flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#FAF8F5] p-0.5 border border-amber-500/50 flex items-center justify-center shrink-0">
                    <img 
                      src={`/images/birds/${tfQuestion.bird.id}.png`} 
                      alt={tfQuestion.bird.name} 
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        const target = e.currentTarget;
                        target.src = `https://picsum.photos/seed/${tfQuestion.bird.name.replace(/\s+/g, "").toLowerCase()}/100/100`;
                      }}
                    />
                  </div>
                  <div className="text-left leading-tight">
                    <span className="block text-[8px] font-mono text-stone-400 uppercase tracking-widest">{tfQuestion.bird.scientificName}</span>
                    <span className="block text-sm font-sans font-black text-amber-400 uppercase tracking-tight mt-0.5">{tfQuestion.bird.name}</span>
                  </div>
                </div>

                <p className="font-serif text-lg tracking-tight text-stone-200 text-center sm:text-left leading-snug my-1">
                  {tfQuestion.text}
                </p>
                
                <div className="flex gap-3 w-full max-w-xs mt-1">
                  <button
                    onClick={() => handleTrueFalse(true)}
                    className="flex-1 bg-emerald-700 hover:bg-emerald-500 transition-colors text-white text-sm font-bold py-3.5 rounded-xl uppercase tracking-wider shadow"
                  >
                    True
                  </button>
                  <button
                    onClick={() => handleTrueFalse(false)}
                    className="flex-1 bg-rose-700 hover:bg-rose-500 transition-colors text-white text-sm font-bold py-3.5 rounded-xl uppercase tracking-wider shadow"
                  >
                    False
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      }

      case "DIET_CLAIM":
      case "HABITAT_CLAIM": {
        const isDiet = round.style === "DIET_CLAIM";
        const descLabel = isDiet 
          ? "Identify dietary associations. Select a card matching the targeted primary feed category!"
          : "Match to the targeted ecological region. Map a bird card to the target native habitat!";
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in text-stone-100">
            <div className="bg-stone-904 bg-stone-900/90 border border-stone-800 p-4 rounded-2xl max-w-md w-full shadow-lg">
              <span className="text-[10px] text-amber-500 font-bold block mb-1 uppercase tracking-widest">Target to Claim</span>
              <p className="font-serif text-xl py-1 text-amber-400 font-bold uppercase tracking-wide">
                {isDiet ? `Primary Diet: "${targetCategory}"` : `Native Habitat: "${targetCategory}"`}
              </p>
            </div>
            <span className="text-xs text-stone-400 uppercase tracking-wider">{descLabel}</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {activePool.map((bird) => (
                <div key={bird.id} className="flex flex-col items-center gap-2">
                  <BirdCardComponent
                    bird={bird}
                    isFlipped={false}
                    onClick={() => handleClaimMapping(bird)}
                  />
                  <div className="bg-stone-950/80 border border-stone-800 px-3 py-1 text-xs font-serif font-bold text-stone-400 uppercase rounded-full mt-2">
                    {isDiet ? "Diet: ?" : "Habitat: ?"}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      }

      case "MIGRATION_QUEST": {
        if (!targetBird) return null;
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full">
            <div className="bg-stone-900 border border-stone-800 max-w-md p-4 rounded-xl text-stone-200 mb-2">
              <span className="text-[10px] text-amber-500 font-bold block mb-1">TARGET MIGRATORY CATEGORY</span>
              <p className="font-serif text-lg py-1">
                Find the species that travels as a <span className="text-amber-400 font-bold">'{targetBird.migratoryStatus}'</span> in the British Isles!
              </p>
            </div>

            <span className="text-xs text-stone-400 uppercase tracking-widest mt-1 mb-2">
              Click the correct visual species card below to match:
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-5xl justify-items-center justify-center mt-2">
              {decoyBirds.map((bird) => {
                const isDiscarded = disabledDecoyIds.includes(bird.id);
                return (
                  <div key={bird.id} className="transition-transform hover:scale-103 duration-300 relative">
                    {isDiscarded ? (
                      <div className="relative opacity-25 grayscale cursor-not-allowed">
                        <div className="absolute inset-0 bg-stone-950/80 z-20 rounded-2xl flex items-center justify-center border-2 border-stone-800">
                          <span className="font-mono text-[9px] text-stone-500 font-extrabold uppercase tracking-widest">DISCARDED</span>
                        </div>
                        <BirdCardComponent
                          bird={bird}
                          isFlipped={false}
                          obscuredStats={["migratoryStatus", "wingspanAvg", "weightAvg", "lengthAvg", "clutchAvg", "rarity"]}
                          disabled={true}
                        />
                      </div>
                    ) : (
                      <BirdCardComponent
                        bird={bird}
                        isFlipped={false}
                        obscuredStats={["migratoryStatus", "wingspanAvg", "weightAvg", "lengthAvg", "clutchAvg", "rarity"]}
                        onClick={() => {
                          const isCorrect = bird.migratoryStatus === targetBird.migratoryStatus;
                          if (isCorrect) {
                            setFeedbackMsg({ text: `Matched! ${bird.name} is indeed a ${bird.migratoryStatus}. (+15 pts)`, type: "success" });
                            registerPoints(activePlayer.id, 15);
                            activePlayer.stats.correctAnswers++;
                            unlockBird(bird.id, activePlayer.name);
                          } else {
                            setFeedbackMsg({
                              text: `Incorrect field observation! The correct species is the '${targetBird.name}' which is a ${targetBird.migratoryStatus}. Your choice, ${bird.name}, is actually a ${bird.migratoryStatus}.`,
                              type: "error"
                            });
                          }
                          activePlayer.stats.totalAnswers++;

                          setReviewData({
                            bird: isCorrect ? bird : targetBird,
                            title: isCorrect ? "Migration Route Identified!" : "Migration Track Lost",
                            text: isCorrect
                              ? `Brilliant! You matched the ${bird.name} which travels as a ${bird.migratoryStatus}.`
                              : `The correct target with migratory status '${targetBird.migratoryStatus}' was the ${targetBird.name}. Your choice ${bird.name} is a ${bird.migratoryStatus}.`,
                            isCorrect,
                            onContinue: () => rotateOrComplete(0)
                          });
                        }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "LATIN_MATCH": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in max-w-3xl w-full">
            {selectedLatinBird ? (
              <div className="flex flex-col items-center gap-3 bg-stone-900 border border-stone-850 p-6 rounded-3xl max-w-xl w-full mb-2 shadow-xl animate-fade-in">
                <span className="text-[10px] bg-amber-500/20 text-amber-300 py-1 px-3 rounded-full uppercase tracking-wider font-bold block">
                  ✦ LATIN MATCH TARGET
                </span>
                
                <div className="flex flex-col sm:flex-row items-center gap-6 mt-2 w-full">
                  <BirdCardComponent
                    bird={selectedLatinBird}
                    isFlipped={false}
                    disabled={true}
                    obscuredStats={["scientificName", "conservationStatus", "weightAvg", "wingspanAvg", "lengthAvg", "clutchAvg", "rarity"]}
                  />
                  <div className="text-center sm:text-left leading-snug flex-1">
                    <span className="block text-[8px] font-mono text-stone-400 uppercase tracking-widest">Selected Species</span>
                    <h4 className="text-xl font-serif font-black text-amber-400 uppercase tracking-tight mt-0.5">{selectedLatinBird.name}</h4>
                    <span className="block text-[11px] text-stone-300 font-mono italic uppercase mt-1">Scientific Name: Hidden 🛈</span>
                    <p className="font-serif italic text-sm text-stone-300 mt-4 leading-relaxed bg-stone-950/40 p-3 rounded-xl border border-stone-800">
                      "{getSanitizedQuestionPrompt(selectedLatinBird)}"
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-stone-900/60 border border-stone-850 p-4 rounded-2xl max-w-sm mb-2 text-stone-400 text-xs tracking-wide">
                Please <span className="text-amber-400 font-bold">Select a bird name</span> in the column below to reveal its visual card and unlock Latin matching!
              </div>
            )}

            <span className="text-xs text-stone-400 uppercase tracking-wider mb-2">
              Select a bird on the left, then click its corresponding scientific Latin name on the right.
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full mt-2">
              {/* Left Column: English Birds */}
              <div className="flex flex-col gap-2 bg-stone-950/50 p-4 rounded-2xl border border-stone-850">
                <span className="text-xs font-mono text-amber-500 font-bold uppercase mb-2">English Names</span>
                {latinMatches.map((birdObj) => {
                  const bCard = deck.find(b => b.id === birdObj.id);
                  if (!bCard) return null;
                  const isMatched = matchedLatinIds.includes(bCard.id);
                  const isSelected = selectedLatinBird?.id === bCard.id;

                  return (
                    <button
                      key={bCard.id}
                      disabled={isMatched}
                      onClick={() => handleLatinBirdSelect(bCard)}
                      type="button"
                      className={`py-3 px-4 rounded-xl text-left font-serif font-black text-sm uppercase transition-all duration-300 flex justify-between items-center ${
                        isMatched
                          ? "bg-zinc-800/40 text-stone-600 border border-zinc-900 line-through cursor-not-allowed"
                          : isSelected
                          ? "bg-amber-500 text-stone-950 font-bold"
                          : "bg-stone-900 hover:bg-stone-800 text-stone-100 border border-stone-800"
                      }`}
                    >
                      <span>{bCard.name}</span>
                      {isMatched && <span className="text-[9px] text-emerald-500">✓ Matched</span>}
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Latin Names */}
              <div className="flex flex-col gap-2 bg-stone-950/50 p-4 rounded-2xl border border-stone-850">
                <span className="text-xs font-mono text-amber-500 font-bold uppercase mb-2">Linnaean Classification</span>
                {shuffledScientificNames.map((birdObj) => {
                  const bCard = deck.find(b => b.id === birdObj.id);
                  if (!bCard) return null;
                  const isMatched = matchedLatinIds.includes(bCard.id);

                  return (
                    <button
                      key={bCard.id}
                      disabled={isMatched || !selectedLatinBird}
                      onClick={() => handleLatinScientificSelect(birdObj.scientificName)}
                      type="button"
                      className={`py-3 px-4 rounded-xl text-left font-mono italic text-sm transition-all duration-300 flex justify-between items-center ${
                        isMatched
                          ? "bg-zinc-800/40 text-stone-600 border border-zinc-900 line-through cursor-not-allowed"
                          : selectedLatinBird
                          ? "bg-stone-900 hover:bg-amber-600/30 text-stone-100 border border-amber-800/50 cursor-pointer"
                          : "bg-stone-900/40 text-stone-500 border border-stone-950 cursor-not-allowed"
                      }`}
                    >
                      <span>{birdObj.scientificName}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        );
      }

      case "GRID_SEARCH": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full max-w-4xl">
            <span className="text-xs text-stone-400 uppercase tracking-wider mb-2">
              Flip tiles sequentially! Find two species belonging to the same AVIAN GROUP (e.g. Songbirds matched to Songbirds)
            </span>

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3.5 w-full mt-2">
              {gridCards.map((tile, idx) => {
                const showFace = tile.flipped || tile.matched;
                return (
                  <div
                    key={tile.id}
                    onClick={() => handleGridCardClick(idx)}
                    className={`relative aspect-[3/4] rounded-xl cursor-pointer shadow transition-all duration-350 select-none ${
                      tile.matched ? "ring-2 ring-emerald-500/60 opacity-60 pointer-events-none" : "hover:scale-103"
                    }`}
                  >
                    {/* Inner styling */}
                    <div className="w-full h-full relative" style={{ transformStyle: "preserve-3d" }}>
                      {showFace ? (
                        <div className="absolute inset-0 bg-stone-900 border border-stone-800 rounded-xl p-2 flex flex-col justify-between items-center text-stone-100">
                          <GroupIconSelector group={tile.bird.group} size={30} />
                          <span className="text-[9px] font-bold text-center leading-tight">
                            {tile.bird.name}
                          </span>
                          <span className="text-[7px] font-mono text-zinc-500 uppercase">
                            {tile.bird.group}
                          </span>
                        </div>
                      ) : (
                        <div className="absolute inset-0 bg-amber-900/80 border-2 border-stone-950 rounded-xl flex items-center justify-center text-amber-500">
                          <span className="font-serif text-[10px] uppercase tracking-widest font-black rotate-45">FIELD GUIDE</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case "RAPTOR_TRUMP": {
        const myCard = trumpCards[activePlayer.id];
        if (!myCard) return null;
        
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full">
            <span className="text-xs text-stone-400 uppercase tracking-wider mb-4">
              Select one specification value of your predator designed to outrank the opponents' hidden bird cards!
            </span>

            <div className="flex flex-col md:flex-row items-center justify-center gap-8 bg-zinc-950/30 p-6 rounded-3xl border border-stone-850">
              {/* Active Player Card */}
              <div className="flex flex-col items-center gap-2">
                <span className="text-xs bg-amber-500 text-stone-950 py-1 px-3 rounded-md font-bold uppercase tracking-widest">
                  YOUR RANDOMLY DEALT CARD
                </span>
                <BirdCardComponent bird={myCard} isFlipped={false} disabled={true} />
              </div>

              {/* Trump choosing stats panel */}
              <div className="flex flex-col justify-center items-center gap-2.5 w-64">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-bold mb-2">SELECT STUMP CATEGORY</span>
                
                <button
                  onClick={() => handleChooseTrumpStat("wingspanAvg")}
                  className="w-full py-2.5 px-4 bg-stone-900 hover:bg-amber-500 hover:text-stone-950 text-stone-200 border border-stone-800 text-xs font-mono uppercase tracking-widest text-left flex justify-between rounded-xl"
                >
                  <span>Wingspan:</span>
                  <span className="font-bold">{myCard.wingspanAvg} cm</span>
                </button>

                <button
                  onClick={() => handleChooseTrumpStat("weightAvg")}
                  className="w-full py-2.5 px-4 bg-stone-900 hover:bg-amber-500 hover:text-stone-950 text-stone-200 border border-stone-800 text-xs font-mono uppercase tracking-widest text-left flex justify-between rounded-xl"
                >
                  <span>Weight:</span>
                  <span className="font-bold">{myCard.weightAvg >= 1000 ? `${(myCard.weightAvg/1000).toFixed(1)}kg` : `${myCard.weightAvg}g`}</span>
                </button>

                <button
                  onClick={() => handleChooseTrumpStat("lengthAvg")}
                  className="w-full py-2.5 px-4 bg-stone-900 hover:bg-amber-500 hover:text-stone-950 text-stone-200 border border-stone-800 text-xs font-mono uppercase tracking-widest text-left flex justify-between rounded-xl"
                >
                  <span>Length:</span>
                  <span className="font-bold">{myCard.lengthAvg} cm</span>
                </button>

                <button
                  onClick={() => handleChooseTrumpStat("clutchAvg")}
                  className="w-full py-2.5 px-4 bg-stone-900 hover:bg-amber-500 hover:text-stone-950 text-stone-200 border border-stone-800 text-xs font-mono uppercase tracking-widest text-left flex justify-between rounded-xl"
                >
                  <span>Clutch Size:</span>
                  <span className="font-bold">{myCard.clutchAvg} eggs</span>
                </button>
              </div>
            </div>
          </div>
        );
      }

      case "TRIVIA_MULTI": {
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full max-w-4xl">
            <div className="bg-stone-900 border border-rose-950/60 p-4 rounded-xl text-stone-200 max-w-lg mb-2">
              <span className="text-[10px] text-rose-500 tracking-wider font-bold uppercase block">ALERT: SPECIES DECLINE</span>
              <p className="font-serif text-base py-1">
                A serious conservation alarm. Look at the 6 bird cards and <span className="text-rose-400 font-bold">Select ALL species currently on the endangered UK RED list!</span>
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 w-full justify-items-center justify-center my-2">
              {decoyBirds.map((bird) => {
                const isSelected = selectedMultiIds.includes(bird.id);
                return (
                  <div
                    key={bird.id}
                    onClick={() => handleToggleMultiSelect(bird.id)}
                    className={`relative cursor-pointer transition-all ${
                      isSelected ? "ring-4 ring-rose-500 scale-[1.03]" : "hover:scale-101"
                    }`}
                  >
                    <BirdCardComponent bird={bird} isFlipped={false} disabled={true} obscuredStats={["conservationStatus"]} />
                    
                    {/* Status badge and selection display */}
                    <div className="absolute top-2.5 left-2.5 bg-stone-950/80 px-2.5 py-1 text-[11px] font-bold rounded shadow uppercase">
                      {isSelected ? "🔴 Selected RED" : "⚪ Target"}
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={submitMultiSelect}
              className="bg-rose-700 hover:bg-rose-500 transition-colors text-stone-100 font-serif font-black tracking-widest text-sm px-8 py-3.5 rounded-2xl mx-auto shadow mt-6 uppercase"
            >
              Verify Selected Red-Listed Birds
            </button>
          </div>
        );
      }

      case "GRAND_FINALE": {
        const hand = finalePlacements[activePlayer.id] || [];
        return (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in w-full max-w-4xl">
            <span className="text-xs text-stone-400 uppercase tracking-wider max-w-xl">
              Arrange your cards sequentially into the weighted multipliers. Double points awarded!
              <br />
              <span className="text-amber-400 font-bold">Slot 1 gets 10x points on Rarity | Slot 2 gets 0.5x points on Wingspan | Slot 3 gets 0.05x on Weight.</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-4xl mt-4 justify-items-center justify-center">
              {hand.map((bird, idx) => (
                <div key={bird.id} className="flex flex-col items-center gap-2 bg-stone-900 p-3 rounded-2xl border border-amber-900/30">
                  <span className="text-xs uppercase tracking-widest text-amber-500 font-bold py-1 bg-stone-950/40 w-full rounded">
                    SLOT {idx + 1}
                  </span>
                  
                  <BirdCardComponent bird={bird} isFlipped={false} disabled={true} />

                  {/* Multiplier control layout */}
                  <div className="flex justify-between items-center w-full px-2 mt-2">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => handleRearrangeFinale(activePlayer.id, idx, "up")}
                      className="p-1 px-2.5 bg-stone-800 hover:bg-amber-500 text-stone-100 rounded text-xs"
                    >
                      ◀
                    </button>
                    <span className="text-[10px] font-mono text-zinc-400">
                      {idx === 0
                        ? `Rarity: ${bird.rarity} (x10)`
                        : idx === 1
                        ? `Wingspan: ${bird.wingspanAvg} (x0.5)`
                        : `Weight: ${bird.weightAvg} (x0.05)`}
                    </span>
                    <button
                      type="button"
                      disabled={idx === hand.length - 1}
                      onClick={() => handleRearrangeFinale(activePlayer.id, idx, "down")}
                      className="p-1 px-2.5 bg-stone-800 hover:bg-amber-500 text-stone-100 rounded text-xs"
                    >
                      ▶
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={submitFinaleScore}
              className="bg-amber-500 text-stone-950 font-serif font-black tracking-widest text-sm px-10 py-3.5 rounded-2xl mx-auto shadow mt-6 uppercase"
              id="submit-finale-score"
            >
              Measure Aggregates & Submit Scale (DOUBLE VALUE!)
            </button>
          </div>
        );
      }

      default:
        return <p className="text-stone-300">Round mechanics under calibration.</p>;
    }
  };

  return (
    <div className="flex flex-col gap-5 w-full max-w-5xl mx-auto text-white">
      
      {/* PASS AND PLAY HANDOFF OVERLAY SCREEN */}
      {handoffPlayerName && (
        <div className="fixed inset-0 bg-[#06110a]/98 backdrop-blur-2xl z-[9999] flex flex-col justify-center items-center p-6 text-center animate-fade-in select-none">
          <div className="text-amber-400 bg-amber-400/10 p-5 rounded-full border border-amber-400/30 mb-4 animate-pulse">
            <span className="text-4xl">🫱📱🫲</span>
          </div>

          <span className="font-mono text-xs uppercase tracking-widest text-emerald-400 font-bold">
            ✦ AVIONIC DIRECTIVE STATUS ✦
          </span>
          <h2 className="font-serif text-3xl font-black text-white uppercase mt-2 mb-6">
            Hand over control of your screen
          </h2>

          <div className="bg-stone-900/90 border-2 border-stone-850 p-6 rounded-3xl max-w-md w-full shadow-2xl relative">
            <span className="text-[10px] font-mono text-stone-500 uppercase tracking-wider block mb-1">
              ACTIVE FIELD WATCHER:
            </span>
            <div className="text-3xl font-sans font-black text-amber-400 uppercase tracking-tight py-2.5 px-4 bg-amber-400/5 border border-amber-500/30 rounded-2xl mb-4">
              {handoffPlayerName}
            </div>

            <p className="text-stone-300 text-xs leading-relaxed mb-6">
              Please hand this device over to <span className="text-amber-300 font-bold">{handoffPlayerName}</span>. To preserve field-guide honesty, all other explorers must look away while they execute their biometric spotting observations!
            </p>

            <button
              onClick={() => {
                playUiClick();
                setHandoffPlayerName(null);
              }}
              className="w-full bg-amber-500 hover:bg-amber-400 text-stone-950 font-sans font-black text-sm tracking-widest py-4 rounded-xl uppercase active:scale-97 transition-all shadow-lg shadow-amber-500/15 cursor-pointer leading-none"
            >
              I am {handoffPlayerName} - Begin Sighting ➔
            </button>
          </div>
        </div>
      )}

      {/* --- PHASE 1: TUTORIAL SCREEN --- */}
      {roundPhase === "tutorial" && (
        <div
          className="bg-black/40 backdrop-blur-lg border-4 border-emerald-700/60 rounded-3xl p-6 shadow-2xl animate-fade-in flex flex-col items-center text-center gap-4"
          id={`round-tutorial-panel-${round.number}`}
        >
          <div className="text-amber-400 bg-amber-400/10 p-3 rounded-full border border-amber-400/35">
            <ForestLeafIcon size={40} />
          </div>
          <span className="font-mono text-xs uppercase tracking-widest text-emerald-300 font-bold leading-none">
            Round {round.number} of {ROUNDS_SET.length}
          </span>
          <h3 className="font-sans text-3xl font-black text-white uppercase tracking-tight">
            {round.title}
          </h3>
          <div className="bg-emerald-900/35 border-2 border-emerald-700/30 rounded-xl py-2 px-5 text-sm font-mono text-emerald-200 max-w-md">
            Theme: <span className="text-amber-400 font-black">{round.theme}</span>
          </div>

          <div className="flex flex-col p-5 bg-emerald-800/10 border-2 border-emerald-700/40 rounded-2xl max-w-xl text-emerald-200 text-sm gap-2 text-left shadow-inner">
            <p className="font-black text-amber-400 tracking-wider font-sans text-xs uppercase">
              REQUISITE OBJECTIVE:
            </p>
            <p className="font-sans leading-relaxed italic text-white opacity-95">
              "{round.description}"
            </p>
            <hr className="border-emerald-800/65 my-2" />
            <p className="font-sans leading-relaxed text-xs">
              <strong>Rules:</strong> {round.rules}
            </p>
          </div>

          <button
            onClick={handleStartRound}
            className="px-8 py-3.5 bg-amber-500 hover:bg-amber-400 text-black rounded-xl font-black uppercase tracking-widest border-b-4 border-amber-700 active:translate-y-1 transition-all cursor-pointer shadow-lg mt-4"
          >
            ENTER FIELD ARENA
          </button>

          {/* Quick Speedrun / Tutorial Toggle */}
          <div className="flex items-center gap-2 mt-2 bg-stone-900/40 px-3.5 py-1.5 border border-stone-850 rounded-xl select-none">
            <label className="flex items-center gap-2 cursor-pointer text-stone-300 hover:text-white transition-colors">
              <input
                type="checkbox"
                checked={speedrunEnabled}
                onChange={(e) => {
                  const val = e.target.checked;
                  setSpeedrunEnabled(val);
                  localStorage.setItem("speedrun_mode", val ? "true" : "false");
                }}
                className="w-4 h-4 accent-amber-500 rounded bg-stone-950 border-stone-800"
              />
              <span className="font-mono text-[10px] uppercase tracking-wider font-extrabold">
                ⏭️ Speedrun Mode (Auto-skip round rules)
              </span>
            </label>
          </div>
        </div>
      )}

      {/* --- PHASE 2: ACTIVE GAMEPLAY --- */}
      {roundPhase === "play" && (
        <div className="flex flex-col gap-4">
          
          {/* Active Round Info Header */}
          <div className="bg-black/30 backdrop-blur-md rounded-2xl p-4 border-2 border-emerald-700/40 flex flex-wrap justify-between items-center gap-4">
            <div>
              <span className="font-mono text-[9px] text-emerald-305 uppercase tracking-widest font-black block text-emerald-300">
                ✦ CURRENT ACTIVE BATTLEFIELD
              </span>
              <h4 className="font-sans text-lg font-black text-amber-400 uppercase">{round.title}</h4>
            </div>

            {/* Dynamic turn display banner */}
            <div className="flex items-center gap-3 bg-emerald-950/90 border-2 border-emerald-800 px-4 py-2 rounded-xl relative group cursor-help select-none">
              <div className="rounded-full overflow-hidden bg-stone-950 border border-amber-500/30">
                <ExplorerAvatar gender={activePlayer.gender} seed={activePlayer.avatarSeed} size={24} avatarUrl={activePlayer.avatarUrl} />
              </div>
              <div className="flex flex-col">
                <span className="text-[8px] uppercase font-mono tracking-wider text-emerald-300 leading-none">Active Watcher:</span>
                <span className="text-xs font-sans font-black text-amber-400 uppercase leading-normal">{activePlayer.name}</span>
              </div>
              
              {/* Suspended Hover Dossier on mouse over / hover */}
              {(activePlayer.realName || activePlayer.cgiProfile) && (
                <div className="absolute right-0 top-12 w-72 bg-stone-950/95 backdrop-blur-md border border-amber-500/30 rounded-2xl p-4 shadow-2xl opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all duration-300 pointer-events-none z-50 flex flex-col gap-2 text-left bg-gradient-to-b from-stone-950 to-stone-900 border-b-4 border-b-amber-500/50">
                  <div className="flex items-center gap-2 border-b border-stone-800 pb-2">
                    <div className="rounded-full overflow-hidden bg-stone-950 border border-amber-500/20 flex-shrink-0">
                      <ExplorerAvatar gender={activePlayer.gender} seed={activePlayer.avatarSeed} size={36} avatarUrl={activePlayer.avatarUrl} />
                    </div>
                    <div>
                      <div className="text-[7px] font-mono text-emerald-400 font-bold uppercase tracking-widest leading-none mb-0.5">Registered Agent</div>
                      <div className="text-[11px] font-sans font-bold text-stone-200 leading-tight">Name: {activePlayer.realName}</div>
                      <div className="text-[8px] font-sans text-stone-400 leading-none">Alias: {activePlayer.name}</div>
                    </div>
                  </div>
                  {activePlayer.cgiProfile && (
                    <div className="font-serif italic text-[11px] text-stone-300 leading-relaxed">
                      "{activePlayer.cgiProfile}"
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Active Bio-modifier Expedition Banner */}
          {activeDestinationName && activeModifierRule && (
            <div className="w-full bg-stone-900 border-2 border-indigo-900/40 rounded-2xl p-3 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-xl relative overflow-hidden animate-fade-in text-left">
              <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-indigo-500/20 via-indigo-500/60 to-indigo-500/20" />
              <div className="flex items-center gap-3">
                <span className="text-xl">🌍</span>
                <div>
                  <span className="font-mono text-[8px] uppercase tracking-widest text-indigo-400 font-extrabold block">
                    CURRENT EXPEDITION SITE
                  </span>
                  <span className="text-xs font-sans font-black text-amber-400 uppercase block leading-tight">{activeDestinationName}</span>
                </div>
              </div>
              <div className="bg-stone-950 border border-indigo-950 px-3 py-1.5 rounded-xl text-[9px] font-mono font-bold text-emerald-400 leading-normal max-w-lg">
                {activeModifierRule}
              </div>
            </div>
          )}

          {/* Portable Gear Belt */}
          {!feedbackMsg && !reviewData && (
            round.style === "SINGLE_CHOICE" ||
            round.style === "ODD_ONE_OUT" ||
            round.style === "MIGRATION_QUEST"
          ) && (
            <div className="w-full bg-stone-900 border-2 border-emerald-850 rounded-2xl p-3 flex flex-col items-center gap-2 shadow-xl relative overflow-hidden animate-fade-in">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500/10 via-amber-500/40 to-amber-500/10" />
              <span className="font-mono text-[9px] uppercase tracking-widest text-emerald-400 font-bold block leading-none">
                ✦ EXPLORER PORTABLE FIELD GEAR BELT ✦
              </span>
              
              <div className="flex flex-wrap items-center justify-center gap-3 mt-1 w-full justify-items-center">
                {/* Field Binoculars */}
                <button
                  onClick={handleUseBinoculars}
                  disabled={playerGear[activePlayer.id]?.binocularsUsed || (playerGearCharges[activePlayer.id]?.binoculars ?? 0) <= 0}
                  className={`flex items-center gap-2 px-3 py-1.5 border rounded-xl text-xs font-mono font-bold transition-all relative shrink-0 ${
                    playerGear[activePlayer.id]?.binocularsUsed || (playerGearCharges[activePlayer.id]?.binoculars ?? 0) <= 0
                      ? "border-stone-800 bg-stone-950 text-stone-600 cursor-not-allowed opacity-50"
                      : "border-amber-500/30 bg-amber-500/5 hover:bg-amber-400 hover:text-stone-950 text-amber-400 cursor-pointer active:scale-95 shadow-md"
                  }`}
                  title={playerGear[activePlayer.id]?.binocularsUsed ? "Binoculars already used this turn" : "Discard 1 incorrect option card from pool"}
                >
                  <span className="text-sm">🔍</span>
                  <div className="text-left font-mono">
                    <span className="block text-[10px] leading-none text-left font-black">BINOCULARS</span>
                    <span className="text-[7px] text-stone-500 block leading-none mt-0.5 uppercase">
                      {playerGear[activePlayer.id]?.binocularsUsed 
                        ? "USED THIS TURN" 
                        : `${playerGearCharges[activePlayer.id]?.binoculars ?? 0} Chg Left`}
                    </span>
                  </div>
                </button>

                {/* Sonic Parabola */}
                <button
                  onClick={handleUseSonicParabola}
                  disabled={playerGear[activePlayer.id]?.sonicUsed || (playerGearCharges[activePlayer.id]?.sonic ?? 0) <= 0}
                  className={`flex items-center gap-2 px-3 py-1.5 border rounded-xl text-xs font-mono font-bold transition-all relative shrink-0 ${
                    playerGear[activePlayer.id]?.sonicUsed || (playerGearCharges[activePlayer.id]?.sonic ?? 0) <= 0
                      ? "border-stone-800 bg-stone-950 text-stone-600 cursor-not-allowed opacity-50"
                      : "border-emerald-600/30 bg-emerald-500/5 hover:bg-emerald-400 hover:text-stone-950 text-emerald-400 cursor-pointer active:scale-95 shadow-md"
                  }`}
                  title={playerGear[activePlayer.id]?.sonicUsed ? "Sonic Parabola already used this turn" : "Sweep acoustically to play song & identify species group"}
                >
                  <span className="text-sm">📡</span>
                  <div className="text-left font-mono">
                    <span className="block text-[10px] leading-none text-left font-black">SONIC DISK</span>
                    <span className="text-[7px] text-stone-500 block leading-none mt-0.5 uppercase">
                      {playerGear[activePlayer.id]?.sonicUsed 
                        ? "USED THIS TURN" 
                        : `${playerGearCharges[activePlayer.id]?.sonic ?? 0} Chg Left`}
                    </span>
                  </div>
                </button>

                {/* Thermal Scope */}
                <button
                  onClick={handleUseThermalScope}
                  disabled={playerGear[activePlayer.id]?.thermalUsed || (playerGearCharges[activePlayer.id]?.thermal ?? 0) <= 0}
                  className={`flex items-center gap-2 px-3 py-1.5 border rounded-xl text-xs font-mono font-bold transition-all relative shrink-0 ${
                    playerGear[activePlayer.id]?.thermalUsed || (playerGearCharges[activePlayer.id]?.thermal ?? 0) <= 0
                      ? "border-stone-800 bg-stone-950 text-stone-600 cursor-not-allowed opacity-50"
                      : "border-rose-500/30 bg-rose-500/5 hover:bg-rose-500 hover:text-stone-950 text-rose-400 cursor-pointer active:scale-95 shadow-md"
                  }`}
                  title={playerGear[activePlayer.id]?.thermalUsed ? "Thermal Scope already used this turn" : "Locks onto the bird's thermal mass weight & nesting habitat"}
                >
                  <span className="text-sm">🔥</span>
                  <div className="text-left font-mono">
                    <span className="block text-[10px] leading-none text-left font-bold">THERMAL SCAN</span>
                    <span className="text-[7px] text-stone-500 block leading-none mt-0.5 uppercase">
                      {playerGear[activePlayer.id]?.thermalUsed 
                        ? "USED THIS TURN" 
                        : `${playerGearCharges[activePlayer.id]?.thermal ?? 0} Chg Left`}
                    </span>
                  </div>
                </button>
              </div>

              {sonicHint && (
                <div className="w-full mt-1.5 p-2 bg-emerald-950/40 border border-emerald-900/40 text-[9px] text-emerald-300 font-mono rounded-lg text-center animate-pulse leading-snug">
                  {sonicHint}
                </div>
              )}

              {thermalClue && (
                <div className="w-full mt-1 p-2 bg-rose-950/40 border border-rose-900/40 text-[9px] text-rose-300 font-mono rounded-lg text-center animate-pulse leading-snug">
                  {thermalClue}
                </div>
              )}
            </div>
          )}

          {/* Action Cards Hand */}
          {!feedbackMsg && !reviewData && roundPhase === "play" && (
            <div className="w-full bg-stone-900 border-2 border-indigo-950/80 rounded-2xl p-3 flex flex-col items-center gap-2 shadow-xl relative overflow-hidden animate-fade-in mt-2 mb-2">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500/10 via-indigo-500/40 to-indigo-500/10" />
              <div className="flex items-center justify-between w-full px-2">
                <span className="font-mono text-[9px] uppercase tracking-widest text-indigo-400 font-bold block leading-none">
                  🃏 PLAYABLE ACTION CARDS HAND (DEALT 4)
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {activeDoublePoints[activePlayer.id] && (
                    <span className="text-[9px] font-mono text-cyan-400 animate-pulse font-bold bg-cyan-950/80 border border-cyan-800/60 px-2 py-0.5 rounded-md">
                      ✨ DOUBLE POINTS ACTIVE
                    </span>
                  )}
                  {activeStreakProtected[activePlayer.id] && (
                    <span className="text-[9px] font-mono text-emerald-400 animate-pulse font-bold bg-emerald-950/80 border border-emerald-800/60 px-2 py-0.5 rounded-md">
                      🛡️ STREAK PROTECT ACTIVE
                    </span>
                  )}
                  {activeRevealedFamily && (
                    <span className="text-[9px] font-mono text-indigo-400 animate-pulse font-bold bg-indigo-950/80 border border-indigo-800/60 px-2 py-0.5 rounded-md">
                      🔍 FAMILY: {activeRevealedFamily.toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 mt-1 w-full">
                {(playerCards[activePlayer.id] || []).length === 0 ? (
                  <div className="col-span-full py-3 text-center text-[10px] font-mono text-stone-500 italic">
                    Your hand is empty. Correct field observations will automatically draw new Action Cards into your hand!
                  </div>
                ) : (
                  (playerCards[activePlayer.id] || []).map((card) => (
                    <button
                      key={card.id}
                      onClick={() => handlePlayActionCard(card)}
                      className={`flex flex-col text-left p-2.5 bg-gradient-to-b border rounded-xl transition-all cursor-pointer hover:shadow-lg active:scale-98 ${card.colorClass}`}
                      title={card.description}
                    >
                      <div className="flex items-center gap-1.5 justify-between w-full">
                        <span className="text-xs font-sans font-black tracking-tight leading-none uppercase truncate">{card.name}</span>
                        <span className="text-sm shrink-0">{card.icon}</span>
                      </div>
                      <p className="text-[8px] font-mono leading-tight mt-1.5 opacity-75 line-clamp-2">
                        {card.description}
                      </p>
                      <span className="text-[7px] font-mono uppercase tracking-widest text-[#94a3b8] font-extrabold mt-2 inline-block leading-none border border-slate-700/40 px-1.5 py-0.5 rounded bg-slate-900/40">
                        PLAY CARD ➔
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Feedback messages / Notifications panel */}
          {feedbackMsg && (
            <div
              className={`p-4 rounded-xl border-2 font-black text-sm tracking-wide shadow-md flex items-center justify-center text-center animate-pulse ${
                feedbackMsg.type === "success"
                  ? "bg-emerald-500 hover:bg-emerald-400 text-black border-emerald-400"
                  : feedbackMsg.type === "error"
                  ? "bg-rose-500 text-white border-rose-400"
                  : "bg-amber-500 text-black border-amber-405"
              }`}
            >
              {feedbackMsg.text}
            </div>
          )}

          {/* Core Interactive Screen */}
          <div className="bg-emerald-800/10 border-2 border-emerald-700/40 p-6 rounded-3xl shadow-2xl flex flex-col justify-center items-center min-h-[380px] backdrop-blur-sm">
            {renderInteractiveGameplay()}
          </div>
        </div>
      )}

      {/* --- COMPARATIVE TOURNAMENT DRAFT STATUS --- */}
      {roundPhase === "compare" && (
        <div className="bg-black/40 backdrop-blur-lg border-4 border-emerald-700/60 rounded-3xl p-6 shadow-2xl">
          {round.style === "RAPTOR_TRUMP" ? renderTrumpShowdown() : resolveDraftTournament()}
        </div>
      )}

      {/* --- PHASE 4: SCORE SUMMARY BOARD --- */}
      {roundPhase === "scoreReport" && (
        <div
          className="bg-black/40 backdrop-blur-lg border-4 border-emerald-700/60 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center gap-5"
          id={`round-summary-panel-${round.number}`}
        >
          <div className="text-amber-400 p-2.5 bg-amber-400/10 border border-amber-400/35 rounded-full">
            ✦
          </div>
          <h3 className="font-sans text-2xl font-black text-amber-400 uppercase tracking-widest">
            {round.title} Consolidated
          </h3>
          <p className="text-emerald-300 text-xs">
            A comprehensive overview of scores gained by field guides during this round:
          </p>

          <div className="flex flex-col gap-2 w-full max-w-md my-2">
            {players.map((p) => {
              const gained = roundScores[p.id] || 0;
              return (
                <div
                  key={p.id}
                  className="bg-emerald-900/40 border-2 border-emerald-700/40 flex justify-between items-center py-2.5 px-4 rounded-xl shadow"
                >
                  <span className="font-sans font-black text-white uppercase">{p.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-emerald-300">Gained:</span>
                    <span className="text-base font-mono font-black text-amber-400">+{gained} pts</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Small Recharts 'Round Performance' Distribution Chart */}
          {(() => {
            const chartData = players.map((p) => ({
              name: p.name,
              points: roundScores[p.id] || 0,
            }));

            const CustomTooltip = ({ active, payload }: any) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-stone-950/95 border border-amber-500/30 p-2 text-left rounded-xl shadow-xl">
                    <p className="text-[10px] font-mono text-emerald-400 font-extrabold uppercase tracking-wider">{payload[0].payload.name}</p>
                    <p className="text-xs text-amber-400 font-sans font-bold mt-0.5">+{payload[0].value} pts</p>
                  </div>
                );
              }
              return null;
            };

            return (
              <div className="w-full max-w-md bg-stone-950/80 border border-emerald-500/20 rounded-2xl p-4 shadow-inner mt-2">
                <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-400 font-bold block mb-3">
                  Round Performance Distribution
                </span>
                <div className="w-full h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={chartData}
                      layout="vertical"
                      margin={{ top: 5, right: 25, left: -10, bottom: 5 }}
                    >
                      <defs>
                        <linearGradient id="scoreGrad" x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="#047857" stopOpacity={0.1} />
                          <stop offset="50%" stopColor="#10b981" stopOpacity={0.6} />
                          <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.9} />
                        </linearGradient>
                      </defs>
                      <XAxis type="number" hide />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={90}
                        tick={{ fill: "#cbd5e1", fontSize: 10, fontWeight: "bold" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(16,185,129,0.05)" }} />
                      <Bar dataKey="points" radius={[0, 4, 4, 0]} barSize={14}>
                        {chartData.map((entry, index) => {
                          const colors = ["#f59e0b", "#10b981", "#06b6d4", "#a855f7"];
                          const clr = colors[index % colors.length];
                          return <Cell key={`cell-${index}`} fill="url(#scoreGrad)" stroke={clr} strokeWidth={1} />;
                        })}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            );
          })()}

          <button
            onClick={() => {
              // Commit temporary round scores to players' persistent scoreboard along with modern gear charges, cards, and birds collected
              onRoundComplete(roundScores, playerGearCharges, playerCards, roundBirdsCollected, activeStreakProtected);
            }}
            className="px-8 py-3 bg-amber-500 hover:bg-amber-400 text-black rounded-xl font-black uppercase tracking-widest border-b-4 border-amber-700 active:translate-y-1 transition-all cursor-pointer shadow-lg mt-4"
          >
            Advance Expedition Map ➔
          </button>
        </div>
      )}
    </div>
  );
}
