import { useState, useEffect } from "react";
import { Player, PlayerGear } from "../types";
import { 
  Compass, 
  ShoppingBag, 
  Map, 
  Shield, 
  Eye, 
  Volume2, 
  Flame, 
  Feather, 
  Sparkles, 
  CloudRain, 
  Wind, 
  Sun,
  Coins,
  ArrowRight,
  TrendingUp,
  Award
} from "lucide-react";
import { playUiClick, playUiAward } from "../utils/audio";

interface ExpeditionHubProps {
  players: Player[];
  currentRound: number;
  totalRounds: number;
  onBuyGear: (playerId: string, itemKey: keyof PlayerGear, cost: number) => void;
  onResumeExpedition: (chosenDestination: { 
    name: string; 
    modifierKey: string; 
    modifierRule: string; 
    themeName: string;
    description: string;
  }) => void;
}

interface ShopItem {
  key: keyof PlayerGear;
  name: string;
  description: string;
  cost: number;
  maxCharges: number;
  icon: any;
  colorClass: string;
}

interface DestinationOption {
  name: string;
  themeName: string;
  description: string;
  modifierKey: string;
  modifierRule: string;
  weatherIcon: any;
  weatherName: string;
}

export default function ExpeditionHub({
  players,
  currentRound,
  totalRounds,
  onBuyGear,
  onResumeExpedition,
}: ExpeditionHubProps) {
  const [activeTab, setActiveTab] = useState<"shop" | "map">("shop");
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>(players[0]?.id || "");
  const [purchaseFeedback, setPurchaseFeedback] = useState<string | null>(null);

  const activePlayerObj = players.find((p) => p.id === selectedPlayerId) || players[0];

  // Define Outfitters Shop Items
  const SHOP_ITEMS: ShopItem[] = [
    {
      key: "binoculars",
      name: "Field Binoculars Refill",
      description: "Discards 1 incorrect option bird card in quiz rounds.",
      cost: 15,
      maxCharges: 3,
      icon: Eye,
      colorClass: "text-emerald-400 border-emerald-500/30 bg-emerald-950/20",
    },
    {
      key: "sonic",
      name: "Sonic Parabola Sweeper",
      description: "Speeps acoustically to play song & identify species taxonomic family.",
      cost: 20,
      maxCharges: 3,
      icon: Volume2,
      colorClass: "text-amber-400 border-amber-500/30 bg-amber-950/20",
    },
    {
      key: "thermal",
      name: "Thermal Scope Battery",
      description: "Locks onto the bird's thermal nesting habitat & dry weight ratio.",
      cost: 20,
      maxCharges: 3,
      icon: Flame,
      colorClass: "text-red-400 border-red-500/30 bg-red-950/20",
    },
    {
      key: "lures",
      name: "Golden Species Lure",
      description: "Guarantees a high-rarity bird (Level 4-5) appears in your draft pool.",
      cost: 30,
      maxCharges: 2,
      icon: Sparkles,
      colorClass: "text-yellow-400 border-yellow-500/30 bg-yellow-950/20",
    },
    {
      key: "shields",
      name: "Expedition Guard Shield",
      description: "Absorbs score & streak penalty on your next incorrect guess.",
      cost: 25,
      maxCharges: 2,
      icon: Shield,
      colorClass: "text-cyan-400 border-cyan-500/30 bg-cyan-950/20",
    },
  ];

  // Dynamically generate interesting, strategic locations for the next round
  const [destinations, setDestinations] = useState<DestinationOption[]>([]);

  useEffect(() => {
    const biomePool = [
      {
        name: "Ancient Oak Woodlands & Canopy",
        themeName: "Woodland Ecosystem",
        description: "Dense, primeval leaf shade protecting delicate songbirds and heavy woodpeckers.",
        modifierKey: "WOODLAND_BOOST",
        modifierRule: "🟢 WOODLAND SANCTUARY: Songbirds & Woodpeckers double their streak score gains this round!",
        weatherIcon: Sun,
        weatherName: "Dappled Sunshine",
      },
      {
        name: "Caledonian Moors & Heather Cliffs",
        themeName: "Highland Heaths",
        description: "Rugged high-altitude shrublands where robust raptors search the rocky thermal air.",
        modifierKey: "MIGRATION_FAVOR",
        modifierRule: "🟣 MIGRATORY WIND: Summer and Winter visitors score +10 extra points on draft weight or size comparing!",
        weatherIcon: Wind,
        weatherName: "Gale-Force Thermals",
      },
      {
        name: "Marshes & Shingle Wetland Spits",
        themeName: "Coasts & Estuaries",
        description: "Wetland reedbeds teeming with fish-eaters, long-legged waders, and majestic waterfowl.",
        modifierKey: "WETLAND_GRAINS",
        modifierRule: "🔵 FLOOD WATER BOOM: Birds with 'Fish' or 'Insects' diet traits earn an instant +12 merit points!",
        weatherIcon: CloudRain,
        weatherName: "Saturating Mist",
      },
      {
        name: "Botanical Reserves & Fenced Farmlands",
        themeName: "Farmlands & Meadows",
        description: "Rich botanical gardens and hedgerows with high insect populations and rich seed harvests.",
        modifierKey: "DIET_SEED",
        modifierRule: "🟡 HARVEST SURGE: Birds with a 'Seeds' or 'Omnivore' primary diet earn +10 extra points!",
        weatherIcon: Feather,
        weatherName: "Abundant Feed",
      },
    ];

    // Pick 3 random, distinct locations
    const shuffled = [...biomePool].sort(() => 0.5 - Math.random());
    setDestinations(shuffled.slice(0, 3));
  }, [currentRound]);

  // Determine Expedition Leader
  const expeditionLeader = [...players].sort((a, b) => b.score - a.score)[0] || players[0];

  const handleBuy = (item: ShopItem) => {
    if (!activePlayerObj) return;
    
    // Check if player can afford
    if (activePlayerObj.score < item.cost) {
      setPurchaseFeedback(`❌ ${activePlayerObj.name} cannot afford this! Need ${item.cost} points.`);
      return;
    }

    const currentCharges = activePlayerObj.gear?.[item.key] || 0;
    if (currentCharges >= item.maxCharges) {
      setPurchaseFeedback(`❌ Max capacity reached! ${activePlayerObj.name} already has ${currentCharges}/${item.maxCharges} ${item.name}.`);
      return;
    }

    // Process purchase
    playUiAward();
    onBuyGear(activePlayerObj.id, item.key, item.cost);
    setPurchaseFeedback(`✨ Successfully purchased ${item.name} for ${activePlayerObj.name}! (-${item.cost} pts)`);
    
    // Clear feedback shortly
    setTimeout(() => {
      setPurchaseFeedback(null);
    }, 3000);
  };

  return (
    <div 
      className="w-full max-w-4xl mx-auto bg-stone-900/90 backdrop-blur-2xl border-2 border-amber-500/30 rounded-3xl p-6 md:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.8),inset_0_0_40px_rgba(245,158,11,0.03)] text-white relative overflow-hidden animate-fade-in"
      id="expedition-hub-panel"
    >
      {/* Visual Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-stone-800 pb-5 mb-6 gap-4">
        <div>
          <span className="text-[10px] bg-amber-500/10 text-amber-400 py-1 px-3 rounded-full uppercase tracking-widest font-mono font-bold inline-block mb-1.5 border border-amber-500/20">
            ✦ Expedition Base Camp Hub
          </span>
          <h2 className="text-2xl md:text-3xl font-serif font-black text-white tracking-wide uppercase">
            Headquarters & Outfitters
          </h2>
          <p className="text-xs text-stone-400 font-sans mt-0.5">
            Prepare gear supply loads and plot the biological route for Round {currentRound} of {totalRounds}.
          </p>
        </div>

        {/* Dynamic Navigation Toggles */}
        <div className="flex gap-2 bg-stone-950 p-1.5 rounded-2xl border border-stone-800">
          <button
            onClick={() => {
              playUiClick();
              setActiveTab("shop");
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs uppercase font-mono font-bold tracking-wider cursor-pointer transition-all ${
              activeTab === "shop"
                ? "bg-amber-500 text-stone-950 shadow-md font-black"
                : "text-stone-400 hover:text-white"
            }`}
          >
            <ShoppingBag size={14} />
            Outfitters Shop
          </button>
          <button
            onClick={() => {
              playUiClick();
              setActiveTab("map");
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs uppercase font-mono font-bold tracking-wider cursor-pointer transition-all ${
              activeTab === "map"
                ? "bg-amber-500 text-stone-950 shadow-md font-black"
                : "text-stone-400 hover:text-white"
            }`}
          >
            <Map size={14} />
            Expedition Map
          </button>
        </div>
      </div>

      {/* SHOP TAB PANEL */}
      {activeTab === "shop" && (
        <div className="space-y-6">
          {/* Player Selector Bar */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-mono font-black text-amber-500/80 tracking-widest block">
                Active Buyer Profile
              </label>
              <div className="flex flex-wrap gap-2">
                {players.map((p) => {
                  const isActive = p.id === selectedPlayerId;
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        playUiClick();
                        setSelectedPlayerId(p.id);
                        setPurchaseFeedback(null);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs uppercase font-sans font-extrabold flex items-center gap-2 border transition-all cursor-pointer ${
                        isActive
                          ? "bg-emerald-950 border-emerald-500/70 text-emerald-300 shadow"
                          : "bg-stone-900 border-stone-800 text-stone-400 hover:text-stone-200"
                      }`}
                    >
                      <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
                      {p.name}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Player Purse Stats */}
            <div className="flex items-center gap-4 bg-stone-900 px-4 py-2 rounded-xl border border-stone-800">
              <div className="text-right">
                <span className="text-[9px] uppercase font-mono text-stone-500 block leading-none">Available Funds</span>
                <span className="text-lg font-mono font-black text-amber-400 block mt-1">
                  {activePlayerObj?.score || 0} pts
                </span>
              </div>
              <div className="bg-amber-500/10 p-2 rounded-lg text-amber-500">
                <Coins size={18} />
              </div>
            </div>
          </div>

          {/* Feedback Msg */}
          {purchaseFeedback && (
            <div className="p-3 bg-stone-950 border border-stone-800 rounded-xl text-center text-xs font-mono font-bold animate-pulse text-amber-300">
              {purchaseFeedback}
            </div>
          )}

          {/* Interactive Shop items Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {SHOP_ITEMS.map((item) => {
              const currentCharges = activePlayerObj?.gear?.[item.key] ?? 0;
              const isMax = currentCharges >= item.maxCharges;
              const canAfford = (activePlayerObj?.score ?? 0) >= item.cost;
              const ItemIcon = item.icon;

              return (
                <div 
                  key={item.key} 
                  className={`border rounded-2xl p-4 flex flex-col justify-between gap-4 transition-all hover:border-amber-500/30 ${
                    isMax ? "opacity-60 bg-stone-950/20" : "bg-stone-900/40"
                  }`}
                >
                  <div className="space-y-2">
                    {/* Item title & icon */}
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <span className="text-xs font-mono font-extrabold text-stone-400 block leading-none">Gear Slot</span>
                        <h4 className="font-serif font-black text-sm uppercase text-white tracking-wide leading-none pt-0.5">
                          {item.name}
                        </h4>
                      </div>
                      <div className={`p-2 rounded-xl border ${item.colorClass}`}>
                        <ItemIcon size={16} />
                      </div>
                    </div>

                    <p className="text-[11px] leading-relaxed text-stone-400 font-sans">
                      {item.description}
                    </p>
                  </div>

                  {/* Quantity and Action Button */}
                  <div className="border-t border-stone-800/60 pt-3 flex justify-between items-center bg-stone-950/20 -mx-4 -mb-4 p-4 rounded-b-2xl">
                    <div className="space-y-0.5">
                      <span className="text-[8px] font-mono text-stone-500 uppercase block">Charges Held</span>
                      <span className={`text-xs font-mono font-black block ${isMax ? 'text-amber-500' : 'text-emerald-400'}`}>
                        {currentCharges} / {item.maxCharges} Max
                      </span>
                    </div>

                    <button
                      onClick={() => handleBuy(item)}
                      disabled={isMax || !canAfford}
                      className={`py-1.5 px-3 rounded-xl text-[10px] uppercase font-mono font-black tracking-widest cursor-pointer transition-all flex items-center gap-1.5 ${
                        isMax 
                          ? "bg-stone-900 text-stone-500 border border-stone-800 cursor-not-allowed"
                          : !canAfford
                            ? "bg-red-950/20 text-red-400 border border-red-900/30 font-bold hover:bg-red-950/40"
                            : "bg-amber-500 hover:bg-amber-400 text-black font-extrabold hover:scale-103 active:scale-95 shadow-md"
                      }`}
                    >
                      <span>Buy: {item.cost} Pts</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Done shopping prompt */}
          <div className="text-center pt-2">
            <span className="text-[10px] text-stone-500 font-mono tracking-widest block uppercase">Ready to launch?</span>
            <button
              onClick={() => {
                playUiClick();
                setActiveTab("map");
              }}
              className="mt-2 px-6 py-2 bg-emerald-700 hover:bg-emerald-600 border border-emerald-500 rounded-xl text-xs uppercase font-mono font-black tracking-widest hover:scale-102 transition-all cursor-pointer inline-flex items-center gap-2 shadow"
            >
              Plot Sighting Route <ArrowRight size={13} />
            </button>
          </div>
        </div>
      )}

      {/* EXPEDITION MAP TAB PANEL */}
      {activeTab === "map" && (
        <div className="space-y-6">
          {/* Dispatch Info Banner */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-mono font-black text-amber-500/80 tracking-widest block leading-none">
                📍 Expedition Lead Scout Selection
              </span>
              <p className="text-xs text-stone-300">
                To preserve game equity, the active party lead <span className="text-amber-300 font-bold font-serif">{expeditionLeader.name}</span> must inspect local forecasts and finalize the birding destination.
              </p>
            </div>
            
            <div className="flex items-center gap-3 bg-stone-900 px-4 py-2.5 rounded-xl border border-stone-800/60 flex-shrink-0">
              <div className="p-1.5 rounded-full bg-amber-500/10 text-amber-500">
                <Compass className="animate-spin duration-[15s]" size={18} />
              </div>
              <div>
                <span className="text-[8px] font-mono uppercase text-stone-500 block leading-none">Selected Scout</span>
                <span className="text-xs font-serif font-black text-amber-400 block mt-0.5 truncate max-w-[130px]">
                  {expeditionLeader.name}
                </span>
              </div>
            </div>
          </div>

          <span className="text-xs text-stone-400 font-sans block text-center mb-2">
            Select one of the following UK habitats to conduct your field observations. Choosing a habitat activates its specific Sighting Rule for the next round:
          </span>

          {/* Destinations Choices Layout */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {destinations.map((dest, idx) => {
              const WeatherIcon = dest.weatherIcon;

              return (
                <div
                  key={idx}
                  className="bg-stone-900/60 border border-stone-800 hover:border-amber-500/40 rounded-2xl p-5 flex flex-col justify-between gap-5 transition-all outline outline-2 outline-transparent hover:outline-amber-500/10 hover:shadow-lg relative group overflow-hidden"
                >
                  {/* Decorative faint background habitat icon */}
                  <div className="absolute -bottom-8 -right-8 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity pointer-events-none">
                    <Compass size={120} />
                  </div>

                  <div className="space-y-3">
                    {/* Destination Title & Theme */}
                    <div className="space-y-1 pb-2.5 border-b border-stone-800/60">
                      <span className="text-[9px] font-mono uppercase font-black tracking-widest text-amber-500 leading-none">
                        Option {idx + 1} • {dest.themeName}
                      </span>
                      <h4 className="font-serif font-black text-base text-white uppercase tracking-wide leading-tight pt-0.5">
                        {dest.name}
                      </h4>
                    </div>

                    <p className="text-[11px] leading-relaxed text-stone-400 font-sans">
                      {dest.description}
                    </p>

                    {/* Meteorological weather box */}
                    <div className="flex items-center gap-2 bg-stone-950/40 p-2 rounded-xl border border-stone-800/40">
                      <div className="text-amber-500">
                        <WeatherIcon size={14} />
                      </div>
                      <div className="leading-none">
                        <span className="text-[7px] font-mono uppercase text-stone-500 block leading-none">Condition</span>
                        <span className="text-[9px] font-mono text-stone-300 font-bold uppercase leading-none mt-0.5 block">{dest.weatherName}</span>
                      </div>
                    </div>

                    {/* Ecological Active Sighting Modifier rule */}
                    <div className="bg-emerald-950/30 border border-emerald-500/20 px-3 py-2 rounded-xl text-emerald-300">
                      <span className="text-[8px] uppercase font-mono tracking-widest font-black block leading-none pb-1 text-emerald-400">
                        Active Sighting Rule
                      </span>
                      <p className="text-[10px] leading-tight font-sans font-bold italic">
                        {dest.modifierRule}
                      </p>
                    </div>
                  </div>

                  {/* Dispatch Route Trigger Button */}
                  <button
                    onClick={() => {
                      playUiAward();
                      onResumeExpedition({
                        name: dest.name,
                        modifierKey: dest.modifierKey,
                        modifierRule: dest.modifierRule,
                        themeName: dest.themeName,
                        description: dest.description,
                      });
                    }}
                    className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black uppercase text-xs tracking-widest rounded-xl hover:scale-102 transition-all cursor-pointer shadow-md inline-flex items-center justify-center gap-1.5"
                  >
                    <span>Travel to Site</span> <ArrowRight size={13} />
                  </button>
                </div>
              );
            })}
          </div>

          <div className="text-center pt-2 text-stone-500 text-[10px] font-mono uppercase tracking-widest">
            ✦ Plot carefully. Habitat selection heavily influences your drafted species' stats ✦
          </div>
        </div>
      )}
    </div>
  );
}
