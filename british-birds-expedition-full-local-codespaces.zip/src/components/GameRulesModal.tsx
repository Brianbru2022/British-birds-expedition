import { X, Award, HelpCircle, Flame, Target, BookOpen } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { ROUNDS_SET } from "../data/rounds";

interface GameRulesModalProps {
  onClose: () => void;
}

export default function GameRulesModal({ onClose }: GameRulesModalProps) {
  const formats = [
    {
      title: "Weight Drafts & Scales",
      desc: "Players draft or pick cards matching specific weight categories — either drafting the heaviest, the absolute lightest, or matching strict clutch thresholds.",
      icon: "⚖️"
    },
    {
      title: "Taxonomic Linnaean Link",
      desc: "Connect common English bird names with their formal Latin scientific genus classifications. Precision and knowledge are highly rewarded!",
      icon: "🧪"
    },
    {
      title: "Diet & Habitat Claims",
      desc: "Match and claim cards that align with specific ecosystem constraints — such as 'Only Insectivores' or species exclusively found in 'Saltwater Coasts'.",
      icon: "🌾"
    },
    {
      title: "Wingspan sorting",
      desc: "Arrange high-speed scrambled bird cards in order of actual wingspan sizes (from smallest garden robin to enormous raptor eagles) under a strict timer.",
      icon: "📏"
    },
    {
      title: "Raptor Trump (Stump Match)",
      desc: "Face off in a classic trump-card challenge against fearsome apex birds of prey using stats like weight, wingspan, and rarity coefficients.",
      icon: "🦅"
    },
    {
      title: "Memory Grid Inspection",
      desc: "Examine a mysterious grid of hidden cards. Uncover matching species and log visual markings under a strict cognitive memory test.",
      icon: "🧠"
    }
  ];

  const ranks = [
    { title: "🌲 Sylvan Master", threshold: "100+ Points", bg: "bg-amber-500/10 text-amber-300 border-amber-400" },
    { title: "🦅 Royal Warden", threshold: "70-99 Points", bg: "bg-emerald-500/10 text-emerald-300 border-emerald-500/40" },
    { title: "🧭 Senior Scout", threshold: "40-69 Points", bg: "bg-cyan-500/10 text-cyan-300 border-cyan-500/40" },
    { title: "🔍 Aviary Scout", threshold: "20-39 Points", bg: "bg-purple-950/40 text-purple-300 border-purple-500/30" },
    { title: "🌱 Novice Tracker", threshold: "0-19 Points", bg: "bg-stone-900 text-stone-400 border-stone-800" }
  ];

  return (
    <div className="fixed inset-0 bg-stone-950/95 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 overflow-hidden animate-fade-in text-white">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-stone-900 border-2 border-amber-500/30 rounded-3xl w-full max-w-4xl h-[88vh] flex flex-col overflow-hidden shadow-[0_0_80px_rgba(245,158,11,0.15)] relative"
      >
        {/* Immersive Guild Gilded Corner Accents */}
        <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-amber-500/40 rounded-tl-2xl pointer-events-none" />
        <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-amber-500/40 rounded-tr-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-amber-500/40 rounded-bl-2xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-amber-500/40 rounded-br-2xl pointer-events-none" />

        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-amber-500/20 bg-stone-950/70 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <HelpCircle className="text-amber-400 animate-pulse w-6 h-6 sm:w-7 sm:h-7" />
            <div className="text-left">
              <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-emerald-400 block font-bold leading-none">
                Guild Briefing Handbook
              </span>
              <h2 className="font-serif text-lg sm:text-2xl font-black text-white leading-tight uppercase tracking-wide mt-1">
                Expedition Rules & Formats
              </h2>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 hover:bg-stone-800 rounded-full text-slate-400 hover:text-white transition-all border border-stone-850 cursor-pointer"
            title="Close Rules"
          >
            <X size={20} />
          </button>
        </div>

        {/* Scrollable Rules Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-8 bg-stone-950/15">
          
          {/* Quick Overview Section */}
          <div className="bg-stone-900 border border-emerald-990 rounded-2xl p-5 flex flex-col md:flex-row gap-5 items-center">
            <div className="p-3 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20">
              <Flame size={44} className="animate-pulse" />
            </div>
            <div className="text-left space-y-1.5 flex-1 select-text">
              <h3 className="font-serif font-black text-amber-400 text-lg uppercase tracking-tight">The Active Quest Cycle</h3>
              <p className="text-xs text-stone-300 leading-relaxed font-serif italic">
                "You play local pass-and-play matches spanning exactly {ROUNDS_SET.length} sequential rounds. During each round, a specific mini-game format is selected. Review the instructions and hand off control of your screen to the active explorer before revealing answers. Points are calculated on response speeds, matching accuracy, and cognitive memory."
              </p>
            </div>
          </div>

          {/* Formats Grid */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-800 pb-2">
              <Target size={16} className="text-emerald-400" />
              <h4 className="font-mono text-xs uppercase font-extrabold tracking-widest text-emerald-400">{ROUNDS_SET.length} Quest Rounds</h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {formats.map((format, idx) => (
                <div 
                  key={idx} 
                  className="bg-stone-900/60 p-4 rounded-xl border border-stone-800/80 hover:border-emerald-500/20 hover:bg-stone-900/85 transition-all text-left flex gap-3.5"
                >
                  <span className="text-2xl mt-0.5 shrink-0 bg-stone-950 w-10 h-10 rounded-lg flex items-center justify-center select-none shadow">
                    {format.icon}
                  </span>
                  <div>
                    <h5 className="font-sans font-black text-stone-100 text-sm uppercase tracking-tight">{format.title}</h5>
                    <p className="text-xs text-stone-400 mt-1 leading-relaxed">{format.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Player Ranks Summary */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-800 pb-2">
              <Award size={16} className="text-amber-400" />
              <h4 className="font-mono text-xs uppercase font-extrabold tracking-widest text-amber-400">Honorable Guild Explorer Ranks</h4>
            </div>

            <p className="text-xs text-stone-400 text-left">
              Accumulate points across raw species identification to raise your standard rank on the live scoreboard:
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {ranks.map((rank, idx) => (
                <div 
                  key={idx} 
                  className={`p-3.5 rounded-xl border font-mono text-center flex flex-col justify-between shadow-sm select-none ${rank.bg}`}
                >
                  <span className="text-[11px] font-black uppercase tracking-tighter leading-snug break-words">
                    {rank.title}
                  </span>
                  <span className="text-[9px] text-stone-400 mt-2 block font-medium uppercase font-extrabold shrink-0">
                    {rank.threshold}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Action Bottom Callout */}
        <div className="p-4 bg-stone-950 border-t border-amber-500/20 text-center flex justify-center shrink-0">
          <button
            onClick={onClose}
            className="px-8 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-black uppercase tracking-widest rounded-xl transition-all hover:scale-103 cursor-pointer shadow-md"
          >
            Undertand Expedition Briefing
          </button>
        </div>

      </motion.div>
    </div>
  );
}
