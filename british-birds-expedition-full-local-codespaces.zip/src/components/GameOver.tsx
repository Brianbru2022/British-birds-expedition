import { Player } from "../types";
import { ExplorerAvatar } from "./BirdIcons";
import { getHighScores } from "../utils/journal";
import { BIRD_DATASET } from "../data/birds";

interface GameOverProps {
  players: Player[];
  onRestart: () => void;
}

// Set Collection matching logic
export function calculateSetCollectionBonus(birdsCollectedIds: string[] = []) {
  const uniqIds = Array.from(new Set(birdsCollectedIds));
  const playerBirds = uniqIds
    .map(id => BIRD_DATASET.find(b => b.id === id))
    .filter((b): b is typeof BIRD_DATASET[number] => b !== undefined);

  const breakdown: { label: string; count: number; bonus: number; icon: string }[] = [];
  let totalBonus = 0;

  // 1. Group by taxonomic group (bird type)
  const groupCounts: Record<string, number> = {};
  playerBirds.forEach(b => {
    groupCounts[b.group] = (groupCounts[b.group] || 0) + 1;
  });
  Object.entries(groupCounts).forEach(([groupName, count]) => {
    const triosCount = Math.floor(count / 3);
    if (triosCount > 0) {
      const bonus = triosCount * 15;
      totalBonus += bonus;
      breakdown.push({
        label: `${groupName} Trio Set`,
        count,
        bonus,
        icon: "🦅"
      });
    }
  });

  // 2. Group by habitat
  const habitatCounts: Record<string, number> = {};
  playerBirds.forEach(b => {
    habitatCounts[b.habitat] = (habitatCounts[b.habitat] || 0) + 1;
  });
  Object.entries(habitatCounts).forEach(([habitatName, count]) => {
    const triosCount = Math.floor(count / 3);
    if (triosCount > 0) {
      const bonus = triosCount * 15;
      totalBonus += bonus;
      breakdown.push({
        label: `${habitatName} Habitat Trio`,
        count,
        bonus,
        icon: "🌲"
      });
    }
  });

  // 3. Group by migratoryStatus
  const migrationCounts: Record<string, number> = {};
  playerBirds.forEach(b => {
    migrationCounts[b.migratoryStatus] = (migrationCounts[b.migratoryStatus] || 0) + 1;
  });
  Object.entries(migrationCounts).forEach(([migratoryName, count]) => {
    const triosCount = Math.floor(count / 3);
    if (triosCount > 0) {
      const bonus = triosCount * 12;
      totalBonus += bonus;
      breakdown.push({
        label: `${migratoryName} Migrant Trio`,
        count,
        bonus,
        icon: "🌍"
      });
    }
  });

  // 4. Group by primaryDiet
  const dietCounts: Record<string, number> = {};
  playerBirds.forEach(b => {
    dietCounts[b.primaryDiet] = (dietCounts[b.primaryDiet] || 0) + 1;
  });
  Object.entries(dietCounts).forEach(([dietName, count]) => {
    const triosCount = Math.floor(count / 3);
    if (triosCount > 0) {
      const bonus = triosCount * 10;
      totalBonus += bonus;
      breakdown.push({
        label: `${dietName} Diet Trio`,
        count,
        bonus,
        icon: "🐛"
      });
    }
  });

  return { totalBonus, breakdown, playerBirds };
}

export default function GameOver({ players, onRestart }: GameOverProps) {
  // Map players to include dynamic Set Collection bonuses
  const playersWithBonus = players.map((p) => {
    const { totalBonus, breakdown, playerBirds } = calculateSetCollectionBonus(p.stats.birdsCollected);
    return {
      ...p,
      baseScore: p.score,
      bonusPoints: totalBonus,
      bonusBreakdown: breakdown,
      birds: playerBirds,
      finalScore: p.score + totalBonus
    };
  });

  const sorted = [...playersWithBonus].sort((a, b) => b.finalScore - a.finalScore);
  const winner = sorted[0];

  const mostCorrect = [...players].sort(
    (a, b) => b.stats.correctAnswers - a.stats.correctAnswers
  )[0];

  return (
    <div
      className="max-w-4xl mx-auto bg-black/40 backdrop-blur-lg border-4 border-emerald-700/60 rounded-3xl p-8 shadow-2xl text-center text-white flex flex-col items-center gap-6"
      style={{
        boxShadow: "0 0 50px rgba(0,0,0,0.6), inset 0 0 30px rgba(16, 185, 129, 0.1)",
      }}
      id="game-over-summary"
    >
      <div className="flex flex-col items-center">
        <span className="text-4xl animate-bounce mb-2">🏆</span>
        <span className="font-mono text-xs uppercase text-emerald-300 tracking-wider font-bold">EXPEDITION COMPLETE</span>
        <h2 className="font-sans text-3xl md:text-4xl font-black text-amber-400 mt-1 uppercase">
          Final Standings
        </h2>
        <p className="text-emerald-200 text-sm max-w-lg mt-1 opacity-95">
          Great Britain's wilderness avian watch is complete! Base scores has been paired with **Set Collection Trio Bonuses** for groups of 3 (Bird Type, Habitat, Diet, and Migrant trios)!
        </p>
      </div>

      {/* Podium View representers */}
      <div className="flex flex-col sm:flex-row items-end justify-center gap-6 w-full max-w-xl my-6">
        {/* Silver Second Place */}
        {sorted[1] && (
          <div className="flex flex-col items-center w-36 order-2 sm:order-1">
            <div className="p-0.5 rounded-full bg-emerald-950 border border-emerald-600 mb-1">
              <ExplorerAvatar gender={sorted[1].gender} seed={sorted[1].avatarSeed} size={54} avatarUrl={sorted[1].avatarUrl} />
            </div>
            <span className="font-sans font-black text-xs text-stone-200 mt-1 uppercase block truncate max-w-[120px]">
              {sorted[1].name}
            </span>
            <div className="flex flex-col text-center text-[10px] gap-0.5 leading-none mb-2">
              <span className="text-emerald-400 font-bold">{sorted[1].finalScore} Final Pts</span>
              <span className="text-[8px] text-stone-400 font-mono">(Base: {sorted[1].baseScore} + Set Bonus: {sorted[1].bonusPoints})</span>
            </div>
            <div className="w-full bg-gradient-to-b from-stone-400 to-stone-600 h-20 rounded-t-xl border border-stone-300 flex items-center justify-center shadow font-sans font-black text-xl text-stone-950">
              2nd
            </div>
          </div>
        )}

        {/* Gold First Place Winner */}
        {winner && (
          <div className="flex flex-col items-center w-40 order-1 sm:order-2 scale-110">
            <span className="text-xl animate-pulse">👑</span>
            <div className="p-1 rounded-full bg-emerald-950 border-2 border-amber-400 mb-1 shadow-lg">
              <ExplorerAvatar gender={winner.gender} seed={winner.avatarSeed} size={72} avatarUrl={winner.avatarUrl} />
            </div>
            <span className="font-sans font-black text-sm text-yellow-300 mt-1 uppercase block truncate max-w-[140px]">
              {winner.name}
            </span>
            <div className="flex flex-col text-center text-xs gap-0.5 leading-none mb-2">
              <span className="text-amber-400 font-bold font-mono">{winner.finalScore} Final Pts</span>
              <span className="text-[9px] text-stone-400 font-mono">(Base: {winner.baseScore} + Set Bonus: {winner.bonusPoints})</span>
            </div>
            <div className="w-full bg-gradient-to-b from-amber-400 to-yellow-600 h-28 rounded-t-xl border border-amber-300 flex flex-col items-center justify-center shadow-lg font-sans font-black text-2xl text-stone-950">
              1st
              <span className="text-[9px] font-mono uppercase tracking-widest text-amber-950 mt-0.5 font-bold">CHAMPION</span>
            </div>
          </div>
        )}

        {/* Bronze Third Place */}
        {sorted[2] && (
          <div className="flex flex-col items-center w-32 order-3">
            <div className="p-0.5 rounded-full bg-emerald-950 border border-emerald-800 mb-1">
              <ExplorerAvatar gender={sorted[2].gender} seed={sorted[2].avatarSeed} size={48} avatarUrl={sorted[2].avatarUrl} />
            </div>
            <span className="font-sans font-black text-xs text-amber-600 mt-1 uppercase block truncate max-w-[110px]">
              {sorted[2].name}
            </span>
            <div className="flex flex-col text-center text-[10px] gap-0.5 leading-none mb-2">
              <span className="text-emerald-400 font-bold">{sorted[2].finalScore} Final Pts</span>
              <span className="text-[8px] text-stone-400 font-mono">(Base: {sorted[2].baseScore} + Set Bonus: {sorted[2].bonusPoints})</span>
            </div>
            <div className="w-full bg-gradient-to-b from-[#b45309] to-[#7c2d12] h-14 rounded-t-xl border border-[#9a3412] flex items-center justify-center shadow font-sans font-black text-lg text-amber-100">
              3rd
            </div>
          </div>
        )}
      </div>

      {/* Standard Leaderboard Rows list if 4 players */}
      {sorted.length > 3 && (
        <div className="w-full max-w-md bg-emerald-950/40 border-2 border-emerald-800/80 p-4 rounded-xl flex flex-col gap-2">
          <span className="text-[9px] font-mono uppercase tracking-wider text-amber-400 font-bold block mb-1">REMAINING STANDINGS</span>
          {sorted.slice(3).map((p, idx) => (
            <div key={p.id} className="flex justify-between items-center bg-emerald-900/30 border border-emerald-800 py-1.5 px-3 rounded-md text-xs font-mono">
              <span className="text-emerald-200">Position {idx + 4}: {p.name} (Base: {p.baseScore} + Bonus: {p.bonusPoints})</span>
              <span className="text-amber-400 font-bold">{p.finalScore} pts</span>
            </div>
          ))}
        </div>
      )}

      {/* Dynamic Set Collection Breakdown Drawer for All Players */}
      <div className="w-full max-w-2xl bg-stone-900/60 border-2 border-indigo-900/40 rounded-2xl p-4 text-left">
        <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider block mb-3">
          🃏 ECOSet COLLECTION BONUSES TALLY (TRIOS BREAKDOWN)
        </span>
        <div className="flex flex-col gap-3">
          {sorted.map((p) => (
            <div key={p.id} className="bg-stone-950/80 border border-slate-800 p-3 rounded-xl">
              <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-1.5">
                <span className="font-sans font-black text-amber-400 text-xs uppercase">{p.name}</span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold">Total Bonus: +{p.bonusPoints} Pts</span>
              </div>
              
              <div className="text-[10px] text-stone-400 mb-2 font-sans truncate">
                🌲 Collected Birds ({p.birds.length}): {p.birds.length > 0 ? p.birds.map(b => b.name).join(", ") : "None was gathered"}
              </div>

              {p.bonusBreakdown.length === 0 ? (
                <div className="text-[9px] font-mono text-stone-500 italic">
                  No matching sets of 3 found. Try focusing on draft patterns or buying wild lures matching habitats next game!
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {p.bonusBreakdown.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between text-[9px] font-mono bg-stone-900 p-1.5 border border-slate-850 rounded-lg">
                      <div className="flex items-center gap-1.5">
                        <span>{item.icon}</span>
                        <span className="text-slate-300 font-bold">{item.label}</span>
                        <span className="text-stone-500">({item.count} collected)</span>
                      </div>
                      <span className="text-amber-400 font-bold">+{item.bonus} pts</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Field Trophy achievements list in Vibrant Palette styling */}
      <div className="w-full max-w-2xl bg-emerald-800/10 border-2 border-emerald-700/40 rounded-2xl p-4 text-left">
        <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider block mb-3">
          ✦ FIELD TROPHIES & ACHIEVEMENTS
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="bg-emerald-950/80 p-3 rounded-xl border border-emerald-850 flex items-center gap-3">
            <span className="text-xl">🧐</span>
            <div>
              <h5 className="font-sans text-[11px] font-black text-amber-400 uppercase leading-none mb-1">
                Field Scholar Badge
              </h5>
              <p className="text-[10px] text-emerald-200 font-sans leading-tight">
                Awarded to <strong>{mostCorrect?.name || "N/A"}</strong> for nailing {mostCorrect?.stats.correctAnswers || 0} active quiz rounds correctly!
              </p>
            </div>
          </div>

          <div className="bg-emerald-950/80 p-3 rounded-xl border border-emerald-850 flex items-center gap-3">
            <span className="text-xl">🌿</span>
            <div>
              <h5 className="font-sans text-[11px] font-black text-amber-400 uppercase leading-none mb-1">
                Conservation Advocate
              </h5>
              <p className="text-[10px] text-emerald-200 font-sans leading-tight">
                Honors our elite watcher for displaying keen environmental alignment on Britain's Red Lists.
              </p>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={onRestart}
        className="px-8 py-3 bg-amber-500 hover:bg-amber-400 text-black rounded-xl font-black uppercase tracking-widest border-b-4 border-amber-700 active:translate-y-1 transition-all cursor-pointer shadow-lg mt-2"
      >
        PLAY AGAIN (RE-RECONSTITUTE DECK)
      </button>
    </div>
  );
}
