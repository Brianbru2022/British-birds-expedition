import React from "react";

interface IconProps extends React.SVGProps<SVGSVGElement> {
  size?: number | string;
  className?: string;
}

export const ForestLeafIcon = ({ size = 24, className = "", ...props }: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 3.5 1 8a7 7 0 0 1-9 10Z" />
    <path d="M9 22v-4" />
    <path d="M14 11.5 9 15" />
  </svg>
);

export const SongbirdsIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="songbirdGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#22c55e" />
        <stop offset="100%" stopColor="#15803d" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#songbirdGrad)" strokeWidth="3" />
    {/* Stylized small singing bird profile */}
    <path
      d="M35,65 C35,65 42,45 55,45 C65,45 75,53 80,52 C78,48 70,38 52,38 C32,38 25,52 25,60 C25,68 35,65 35,65 Z"
      fill="url(#songbirdGrad)"
    />
    {/* Beak */}
    <path d="M80,52 L88,48 L80,45 Z" fill="#eab308" />
    {/* Music notes */}
    <path d="M60,25 L60,18 L70,21 L70,28" stroke="#10b981" strokeWidth="2" fill="none" />
    <circle cx="57" cy="25" r="3" fill="#10b981" />
    <circle cx="67" cy="28" r="3" fill="#10b981" />
  </svg>
);

export const RaptorsIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="raptorGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f43f5e" />
        <stop offset="100%" stopColor="#991b1b" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#raptorGrad)" strokeWidth="3" />
    {/* Hooked powerful beak and sharp predator eye */}
    <path
      d="M25,50 C25,35 40,25 60,30 C75,34 82,45 82,55 L74,53 C74,40 55,36 45,45 C38,52 35,65 25,50 Z"
      fill="url(#raptorGrad)"
    />
    <path d="M82,55 L88,68 L74,53 Z" fill="#ca8a04" /> {/* Hooked sharp beak tip */}
    <circle cx="58" cy="40" r="4" fill="#fef08a" />
    <circle cx="58" cy="40" r="2" fill="#020617" />
  </svg>
);

export const WaterfowlIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="waterGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#06b6d4" />
        <stop offset="100%" stopColor="#0891b2" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#waterGrad)" strokeWidth="3" />
    {/* Duck silhouette swimming on waves */}
    <path
      d="M20,62 C25,62 30,58 35,58 C45,58 43,45 52,40 C62,35 70,40 75,46 L78,41 C70,32 58,30 46,36 C35,42 34,50 25,50 L20,62 Z"
      fill="url(#waterGrad)"
    />
    {/* Bill */}
    <path d="M78,41 L85,44 L78,47 Z" fill="#eab308" />
    {/* Water wave lines */}
    <path d="M15,70 Q32,65 50,70 Q68,75 85,70" stroke="#22d3ee" strokeWidth="2.5" fill="none" strokeLinecap="round" />
    <path d="M22,78 Q42,74 62,78 Q78,81 80,78" stroke="#0891b2" strokeWidth="1.5" fill="none" strokeLinecap="round" />
  </svg>
);

export const WadersIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="waderGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f97316" />
        <stop offset="100%" stopColor="#c2410c" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#waderGrad)" strokeWidth="3" />
    {/* Curlew long-bill or avocet and skinny legs */}
    <path d="M48,65 L48,88 M56,62 L56,86" stroke="#ea580c" strokeWidth="3" strokeLinecap="round" />
    <path d="M30,55 C42,42 62,48 68,54 C72,58 70,68 50,68 C35,68 28,62 30,55 Z" fill="url(#waderGrad)" />
    {/* Super long downward curved thin beak */}
    <path d="M68,54 Q82,57 90,48" stroke="#ca8a04" strokeWidth="3.5" fill="none" strokeLinecap="round" />
  </svg>
);

export const SeabirdsIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="seaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#3b82f6" />
        <stop offset="100%" stopColor="#1e40af" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#seaGrad)" strokeWidth="3" />
    {/* Flying soaring gull over coastal winds */}
    <path
      d="M15,42 Q35,30 50,48 Q65,30 85,42 Q60,40 50,55 Q40,40 15,42 Z"
      fill="url(#seaGrad)"
      stroke="#60a5fa"
      strokeWidth="1"
    />
    {/* Little sunset ray or clouds */}
    <path d="M30,72 L70,72 M40,78 L60,78" stroke="#93c5fd" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const WoodpeckersIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="peckerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#a855f7" />
        <stop offset="100%" stopColor="#6b21a8" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#peckerGrad)" strokeWidth="3" />
    {/* Visual Woodpecker drilling vertical trunk layout */}
    <rect x="25" y="15" width="10" height="70" rx="3" fill="#71717a" />
    <path
      d="M35,62 L48,58 C55,54 58,44 52,38 C48,34 35,36 35,45 Z"
      fill="url(#peckerGrad)"
    />
    <path d="M52,38 L68,34 L52,43 Z" fill="#9333ea" /> {/* Sharp beak */}
    {/* Red head cap of woodpecker */}
    <path d="M48,34 C44,30 38,32 35,36 L35,42 Z" fill="#ef4444" />
  </svg>
);

export const PigeonsGameIcon = ({ size = 48, className = "" }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="gameGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#b45309" />
        <stop offset="100%" stopColor="#7c2d12" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="none" stroke="url(#gameGrad)" strokeWidth="3" />
    {/* Feather / game bird body and field oats */}
    <path
      d="M22,58 C22,42 40,32 58,35 C74,38 82,50 82,60 C80,68 62,65 52,62 C40,58 25,65 22,58 Z"
      fill="url(#gameGrad)"
    />
    {/* Oats wheat */}
    <path d="M15,82 L35,65 M25,82 L42,68" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

export const GroupIconSelector = ({ group, size = 48, className = "" }: { group: string; size?: number; className?: string }) => {
  switch (group) {
    case "Songbirds":
      return <SongbirdsIcon size={size} className={className} />;
    case "Raptors":
      return <RaptorsIcon size={size} className={className} />;
    case "Waterfowl":
      return <WaterfowlIcon size={size} className={className} />;
    case "Waders":
      return <WadersIcon size={size} className={className} />;
    case "Seabirds":
      return <SeabirdsIcon size={size} className={className} />;
    case "Woodpeckers":
      return <WoodpeckersIcon size={size} className={className} />;
    case "Pigeons & Game":
    default:
      return <PigeonsGameIcon size={size} className={className} />;
  }
};

// Animated Vector Player Avatar Generator Component
export const ExplorerAvatar = ({ gender, seed, size = 120, className = "", avatarUrl }: { gender: "Male" | "Female" | "Diverse"; seed: number; size?: number; className?: string; avatarUrl?: string }) => {
  if (avatarUrl) {
    return (
      <div 
        style={{ width: size, height: size }} 
        className={`rounded-full overflow-hidden border-2 border-amber-500/40 bg-stone-900 flex-shrink-0 relative inline-block ${className}`}
      >
        <img 
          src={avatarUrl} 
          alt="AI CGI Character" 
          className="w-full h-full object-cover rounded-full" 
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  // Use seed to customize color coordinates
  const skinTones = ["#ffdbac", "#f1c27d", "#e0ac69", "#c68642", "#8d5524"];
  const hairColors = ["#09090b", "#78350f", "#b45309", "#d97706", "#71717a", "#aa1111"];
  const gearColors = ["#15803d", "#1e3a8a", "#9a3412", "#0369a1", "#0f766e", "#6b21a8"];

  const skin = skinTones[seed % skinTones.length];
  const hair = hairColors[(seed * 3) % hairColors.length];
  const gear = gearColors[(seed * 7) % gearColors.length];

  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={`overflow-visible ${className}`}>
      <defs>
        <clipPath id="avatarClip">
          <circle cx="50" cy="50" r="46" />
        </clipPath>
        <filter id="avatarGlow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#000" floodOpacity="0.3" />
        </filter>
      </defs>
      
      {/* Background Circle with dynamic gradient */}
      <circle cx="50" cy="50" r="46" fill="#1e293b" stroke="#e2e8f0" strokeWidth="3" filter="url(#avatarGlow)" />
      
      <g clipPath="url(#avatarClip)">
        {/* Sky/Atmosphere inside background */}
        <path d="M4,75 Q50,45 96,75" fill={gear} opacity="0.15" />
        
        {/* Shoulders / Shirt */}
        <path d="M22,85 Q50,70 78,85 L85,100 L15,100 Z" fill={gear} />
        
        {/* Explorer neck collar */}
        <path d="M40,75 L50,82 L60,75 L50,88 Z" fill="#f8fafc" />
        
        {/* Neck */}
        <rect x="42" y="65" width="16" height="15" fill={skin} rx="4" />
        
        {/* Face */}
        <circle cx="50" cy="50" r="20" fill={skin} />
        
        {/* Eyes */}
        <circle cx="43" cy="48" r="2" fill="#09090b" />
        <circle cx="57" cy="48" r="2" fill="#09090b" />
        
        {/* Cheeks and Smiling Mouth */}
        <path d="M44,56 Q50,62 56,56" stroke="#991b1b" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        
        {/* Male Explorer (beards / mustache / hat) */}
        {gender === "Male" && (
          <g>
            {/* Beard */}
            <path d="M32,50 Q50,74 68,50 Q60,70 40,70 Z" fill={hair} />
            {/* Explorer Hat */}
            <path d="M20,38 Q50,26 80,38" stroke="#b45309" strokeWidth="6" strokeLinecap="round" />
            <path d="M28,38 C28,18 72,18 72,38 Z" fill="#a16207" />
            <rect x="36" y="32" width="28" height="4" fill="#0f172a" />
          </g>
        )}

        {/* Female Explorer (distinctive hair / cap / bandana) */}
        {gender === "Female" && (
          <g>
            {/* Long and gorgeous hair */}
            <path d="M28,35 C28,15 72,15 72,35 C76,45 74,65 74,65 C70,60 68,52 68,45 C65,30 35,30 32,45 C32,52 30,60 26,65 Z" fill={hair} />
            {/* Ponytail or bow */}
            <circle cx="30" cy="45" r="5" fill="#ef4444" />
            {/* Field Cap */}
            <path d="M26,35 C26,20 74,20 74,35" stroke="#15803d" strokeWidth="5" strokeLinecap="round" />
            <path d="M40,25 Q70,16 78,28" stroke="#16a34a" strokeWidth="4" strokeLinecap="round" />
          </g>
        )}

        {/* Diverse/Non-binary explorer (cute binoculars / dynamic glasses and cap) */}
        {gender === "Diverse" && (
          <g>
            {/* Fun Spiky and stylish hair */}
            <path d="M28,38 C28,24 35,16 50,16 C65,16 72,24 72,38 L76,42 L24,42 Z" fill={hair} />
            {/* Round stylish glasses */}
            <circle cx="42" cy="48" r="5.5" fill="none" stroke="#e2e8f0" strokeWidth="2.5" />
            <circle cx="58" cy="48" r="5.5" fill="none" stroke="#e2e8f0" strokeWidth="2.5" />
            <line x1="47.5" y1="48" x2="52.5" y2="48" stroke="#e2e8f0" strokeWidth="2.5" />
            {/* Binoculars around neck */}
            <path d="M35,82 L38,98 L44,98 L41,82" fill="#52525b" />
            <path d="M65,82 L62,98 L56,98 L59,82" fill="#52525b" />
            <rect x="38" y="93" width="24" height="2" fill="#ff7700" />
          </g>
        )}
      </g>
      
      {/* Tiny binoculars or crest ornament on top */}
      <circle cx="50" cy="4" r="2.5" fill="#facc15" />
    </svg>
  );
};
