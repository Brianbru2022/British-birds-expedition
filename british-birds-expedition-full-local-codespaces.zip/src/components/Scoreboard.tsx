import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Player } from "../types";
import { ExplorerAvatar } from "./BirdIcons";

interface ScoreboardProps {
  players: Player[];
  currentRound: number;
  totalRounds?: number;
}

// 1. Sleek, performance-optimized, RAF-based count-up counter to smoothly animate point increments
function AnimatedCounter({ startValue, endValue, duration = 1200 }: { startValue: number; endValue: number; duration?: number }) {
  const [displayValue, setDisplayValue] = useState(startValue);

  useEffect(() => {
    const start = startValue;
    const end = endValue;
    if (start === end) {
      setDisplayValue(end);
      return;
    }

    const startTime = performance.now();
    let animationFrameId: number;

    const update = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Beautiful easeOutQuad
      const ease = progress * (2 - progress);
      const current = Math.round(start + (end - start) * ease);
      setDisplayValue(current);

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(update);
      } else {
        setDisplayValue(end);
      }
    };

    animationFrameId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animationFrameId);
  }, [startValue, endValue, duration]);

  return <span>{displayValue}</span>;
}

// 2. Specialized Player Score Card with floating point indicator & responsive scale/glow bump physical dynamics
function PlayerScoreCard({
  player,
  idx,
  isLeader,
  progressPercent,
  startValue,
  endValue,
}: {
  player: Player;
  idx: number;
  isLeader: boolean;
  progressPercent: number;
  startValue: number;
  endValue: number;
  key?: any;
}) {
  const prevScoreRef = useRef(player.score);
  const [floater, setFloater] = useState<{ id: string; diff: number } | null>(null);
  const [pulseActive, setPulseActive] = useState(false);

  useEffect(() => {
    const prev = prevScoreRef.current;
    const current = player.score;
    
    if (current > prev) {
      const diff = current - prev;
      const newId = `${Date.now()}-${Math.random()}`;
      setFloater({ id: newId, diff });
      setPulseActive(true);
      
      const timer = setTimeout(() => {
        setPulseActive(false);
      }, 1200);
      
      prevScoreRef.current = current;
      return () => clearTimeout(timer);
    } else if (current !== prev) {
      prevScoreRef.current = current;
    }
  }, [player.score]);

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, x: -20, scale: 0.9 },
        visible: { 
          opacity: 1, 
          x: 0, 
          scale: 1,
          transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] } // Custom swift easeOutExpo
        }
      }}
      animate={pulseActive ? { 
        scale: [1, 1.08, 0.96, 1.02, 1],
        boxShadow: [
          "0px 0px 0px rgba(16, 185, 129, 0)",
          "0px 0px 22px rgba(16, 185, 129, 0.45)",
          "0px 0px 25px rgba(16, 185, 129, 0.18)",
          "0px 0px 0px rgba(16, 185, 129, 0)"
        ]
      } : {}}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className={`flex items-center gap-4 p-2 pr-6 rounded-full border relative transition-all duration-350 ${
        isLeader 
          ? "border-amber-400 bg-stone-900 shadow-[0_0_18px_rgba(245,158,11,0.25)]" 
          : "border-stone-800/80 bg-stone-900/40 opacity-80"
      }`}
    >
      {/*... Keep rest identical ...*/}
      <AnimatePresence>
        {floater && (
          <motion.div
            key={floater.id}
            initial={{ opacity: 0, y: 12, scale: 0.7 }}
            animate={{ opacity: 1, y: -28, scale: 1.15 }}
            exit={{ opacity: 0, y: -52, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 120, damping: 10 }}
            className="absolute -right-3 top-0 bg-emerald-500 text-stone-950 font-black font-mono text-xs px-2 py-0.5 rounded-full z-30 shadow-[0_4px_12px_rgba(16,185,129,0.5)] border border-emerald-400/30 flex items-center justify-center gap-0.5"
          >
            +{floater.diff}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative">
        <div className="rounded-full overflow-hidden bg-stone-950 p-0.5 border-2 border-amber-500/40">
          <ExplorerAvatar gender={player.gender} seed={player.avatarSeed} size={40} avatarUrl={player.avatarUrl} />
        </div>
        {isLeader && (
          <span className="absolute -top-1.5 -right-1.5 text-xs animate-bounce" title="Current Expedition Leader">
            👑
          </span>
        )}
        {player.streak && player.streak >= 2 ? (
          <span className="absolute -bottom-1.5 -right-1.5 text-[9px] bg-red-650 text-white font-mono font-black px-1 py-0.5 rounded-full flex items-center border border-red-500 shadow animate-[pulse_1.5s_infinite]" title={`${player.streak}-round correct answer streak active!`}>
            🔥 {player.streak}
          </span>
        ) : null}
      </div>
      
      <div className="flex flex-col">
        <span className="text-[10px] font-mono tracking-widest text-emerald-400 font-bold uppercase leading-none">
          Player {idx + 1}
        </span>
        <span className="text-sm font-black text-stone-100 leading-tight mt-0.5 max-w-[90px] truncate uppercase">
          {player.name}
        </span>
        <span className="text-[8px] font-mono tracking-wider text-amber-400 uppercase font-black leading-none mt-0.5 block">
          {player.score >= 100 
            ? "🌲 Sylvan Master" 
            : player.score >= 70 
              ? "🦅 Royal Warden" 
              : player.score >= 40 
                ? "🧭 Senior Scout" 
                : player.score >= 20 
                  ? "🔍 Aviary Scout" 
                  : "🌱 Novice Tracker"}
        </span>
        <div className="h-1.5 w-20 bg-stone-950 rounded-full mt-1 overflow-hidden">
          <motion.div 
            className="h-full bg-amber-400 rounded-full" 
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          />
        </div>
      </div>

      {/* Numerical counter that slides/steps gracefully */}
      <div className="ml-2 text-xl font-black text-amber-400 flex items-center font-mono tracking-tighter">
        <AnimatedCounter startValue={startValue} endValue={endValue} />
      </div>
    </motion.div>
  );
}

export default function Scoreboard({
  players,
  currentRound,
  totalRounds = 15,
}: ScoreboardProps) {
  // Store previous scores in a Ref that is preserved across staggered card-list remounts
  const previousScoresRef = useRef<Record<string, number>>({});

  // Sort players to identify current leader
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
  const leadingScore = sortedPlayers[0]?.score || 0;

  // Sync scores after we render so on the next staggered iteration, baseline starts at previous values
  useEffect(() => {
    players.forEach((p) => {
      previousScoresRef.current[p.id] = p.score;
    });
  }, [players]);

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0, y: -25 },
        visible: {
          opacity: 1,
          y: 0,
          transition: {
            duration: 0.5,
            ease: "easeOut",
            staggerChildren: 0.15,
          },
        },
      }}
      className="w-full max-w-5xl mx-auto bg-stone-950/80 backdrop-blur-xl border border-amber-500/20 rounded-3xl p-5 shadow-[0_10px_40px_rgba(0,0,0,0.6)] flex flex-col md:flex-row justify-between items-center gap-6 text-white relative overflow-hidden"
      id="global-scoreboard-header"
    >
      {/* Mini Guild Gilded Corner Accents */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t border-l border-amber-500/35 rounded-tl-xl pointer-events-none" />
      <div className="absolute top-0 right-0 w-4 h-4 border-t border-r border-amber-500/35 rounded-tr-xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b border-l border-amber-500/35 rounded-bl-xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b border-r border-amber-500/35 rounded-br-xl pointer-events-none" />

      {/* Left section: Players rows with staggered entrance animation and smooth score count up */}
      <motion.div 
        key={currentRound} // Recovers staggered entrance animation sequence on each new round!
        className="flex flex-wrap items-center justify-center gap-4 relative z-10"
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.15
            }
          }
        }}
      >
        {players.map((p, idx) => {
          const isLeader = p.score > 0 && p.score === leadingScore;
          // Calculate score progress relative to leading score
          const progressPercent = leadingScore > 0 ? Math.min(100, Math.round((p.score / leadingScore) * 100)) : 0;
          
          // Look up previous baseline score
          const prevScore = previousScoresRef.current[p.id] !== undefined ? previousScoresRef.current[p.id] : p.score;
          
          return (
            <PlayerScoreCard
              key={p.id}
              player={p}
              idx={idx}
              isLeader={isLeader}
              progressPercent={progressPercent}
              startValue={prevScore}
              endValue={p.score}
            />
          );
        })}
      </motion.div>

      {/* Center Section: Beautiful round block and header */}
      <div className="flex flex-col items-center relative z-10">
        <div className="bg-amber-500 text-stone-950 px-4 py-1 rounded-t-lg font-black text-xs uppercase tracking-tighter italic font-mono leading-none">
          Round {String(currentRound).padStart(2, "0")} / {String(totalRounds).padStart(2, "0")}
        </div>
        <div className="bg-stone-900 border-2 border-amber-500/50 text-amber-400 px-6 py-2 rounded-b-lg rounded-r-lg font-serif font-black text-lg shadow-xl tracking-wide uppercase leading-none">
          THE AVIARY EXPEDITION
        </div>
        <span className="text-[10px] text-emerald-400 font-mono mt-1 opacity-80 tracking-widest uppercase">
          ✦ 100 Species Quest ✦
        </span>
      </div>

      {/* Right Section: Standings state or stats tracker */}
      <div className="hidden md:flex flex-col items-end relative z-10">
        <div className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 mb-1 font-mono">
          Current Standings
        </div>
        <div className="flex items-center gap-2 bg-amber-500/5 border border-amber-500/30 text-amber-400 px-4 py-1.5 rounded-full font-mono text-xs shadow-inner">
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
          <span>FIELD EXPEDITION ACTIVE</span>
        </div>
      </div>
    </motion.div>
  );
}
