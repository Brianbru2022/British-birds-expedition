import { useState } from "react";
import { ForestLeafIcon } from "./BirdIcons";
import { BookOpen, HelpCircle } from "lucide-react";
import FieldGuideModal from "./FieldGuideModal";
import GameRulesModal from "./GameRulesModal";
import BirdCardComponent from "./BirdCardComponent";
import { BIRD_DATASET } from "../data/birds";
import { ROUNDS_SET } from "../data/rounds";
import { motion } from "motion/react";
import AudioSpectrogram from "./AudioSpectrogram";
// @ts-ignore
import guildCrest from "../assets/images/guild_crest_1780291316431.png";
import { playUiClick, playBirdSong } from "../utils/audio";

interface GameIntroProps {
  onStart: () => void;
}

// Drifting, rotating fluffy feathers that float smoothly down the landscape
const FallingFeather = ({ delay = 0, xOffset = "10vw", duration = 8, scale = 1 }) => {
  return (
    <motion.div
      initial={{ y: "-10vh", x: xOffset, opacity: 0, rotate: 0 }}
      animate={{
        y: "110vh",
        x: [xOffset, `calc(${xOffset} + 60px)`, `calc(${xOffset} - 40px)`, `calc(${xOffset} + 15px)`],
        opacity: [0, 0.45, 0.45, 0.15, 0],
        rotate: [0, 150, 310, 480],
      }}
      transition={{
        duration: duration,
        repeat: Infinity,
        delay: delay,
        ease: "easeInOut",
      }}
      className="absolute pointer-events-none z-[1] text-amber-500/15 leading-none select-none filter blur-[0.6px]"
      style={{ scale }}
    >
      <svg width="18" height="36" viewBox="0 0 24 48" fill="currentColor">
        <path d="M12 2C12 2 9 14 5 24C3 30 3 36 7 42C9 46 13 46 15 42C19 36 19 30 17 24C13 14 12 2 12 2Z" />
        <path d="M12 2L12 44" stroke="currentColor" strokeWidth="1" opacity="0.4" />
      </svg>
    </motion.div>
  );
};

// A flapping bird component using clean SVG and motion animations
const AnimatedBird = ({ delay = 0, initialY = 100, duration = 15, scale = 1, color = "text-amber-500/40" }) => {
  return (
    <motion.div
      initial={{ x: "-150px", y: initialY, scale: scale * 0.75, opacity: 0 }}
      animate={{
        x: "100vw",
        y: [initialY, initialY - 50, initialY + 60, initialY - 30, initialY],
        opacity: [0, 0.75, 0.8, 0.75, 0],
      }}
      transition={{
        duration: duration,
        repeat: Infinity,
        delay: delay,
        ease: "linear",
      }}
      className="absolute pointer-events-none z-[5] overflow-hidden leading-none select-none filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.65)]"
    >
      <svg className={`w-14 h-14 ${color}`} viewBox="0 0 24 24" fill="currentColor">
        <motion.path
          d="M12,2 C10,5 5,7 1,8 C5,10 9,11 12,9 C15,11 19,10 23,8 C19,7 14,5 12,2 Z"
          animate={{
            d: [
              "M12,2 C10,5 5,7 1,8 C5,10 9,11 12,9 C15,11 19,10 23,8 C19,7 14,5 12,2 Z", 
              "M12,6 C10,9 4,13 1,15 C5,14 9,12 12,9 C15,12 19,14 23,15 C20,13 14,9 12,6 Z", 
              "M12,1 C10,3 5,4 1,5 C5,7 9,8 12,9 C15,8 19,7 23,5 C19,4 14,3 12,1 Z" 
            ]
          }}
          transition={{
            duration: 0.65,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </svg>
    </motion.div>
  );
};

export default function GameIntro({ onStart }: GameIntroProps) {
  const [showFieldGuide, setShowFieldGuide] = useState(false);
  const [showRules, setShowRules] = useState(false);

  // Grab three distinctive specimen birds from the dataset to display as the featured highlight reel
  const featuredRobin = BIRD_DATASET.find((b) => b.id === "b1");
  const featuredOwl = BIRD_DATASET.find((b) => b.id === "b39");
  const featuredKingfisher = BIRD_DATASET.find((b) => b.id === "b60");

  return (
    <div
      className="max-w-5xl mx-auto bg-stone-950/85 backdrop-blur-xl border-2 border-amber-500/30 rounded-3xl p-6 md:p-8 shadow-[0_0_80px_rgba(0,0,0,0.85)] text-center text-white flex flex-col items-center gap-6 relative overflow-hidden"
      id="game-intro-splash"
    >
      {/* Drifting organic feathers floating smoothly down behind cards */}
      <FallingFeather delay={0} xOffset="12vw" duration={14} scale={1.2} />
      <FallingFeather delay={2} xOffset="35vw" duration={18} scale={0.8} />
      <FallingFeather delay={4} xOffset="62vw" duration={15} scale={1.0} />
      <FallingFeather delay={6} xOffset="85vw" duration={22} scale={1.3} />
      <FallingFeather delay={1} xOffset="22vw" duration={20} scale={0.9} />
      <FallingFeather delay={5} xOffset="73vw" duration={16} scale={1.1} />

      {/* Dynamic flying flocks of heavily visible animated birds soaring across the skyline background */}
      <AnimatedBird delay={0} initialY={60} duration={12} scale={1.2} color="text-amber-500/40" />
      <AnimatedBird delay={3} initialY={150} duration={16} scale={0.9} color="text-emerald-500/45" />
      <AnimatedBird delay={6} initialY={240} duration={11} scale={1.1} color="text-amber-500/40" />
      <AnimatedBird delay={9} initialY={330} duration={14} scale={0.8} color="text-emerald-500/45" />
      <AnimatedBird delay={1.5} initialY={90} duration={10} scale={0.7} color="text-amber-400/30" />
      <AnimatedBird delay={5.5} initialY={280} duration={15} scale={1.3} color="text-emerald-400/30" />

      {/* Immersive Guild Gilded Corner Accents */}
      <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-amber-500/40 rounded-tl-2xl pointer-events-none" />
      <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-amber-500/40 rounded-tr-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-amber-500/40 rounded-bl-2xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-amber-500/40 rounded-br-2xl pointer-events-none" />

      {/* Top Brand Block */}
      <div className="flex flex-col items-center relative z-10 w-full">
        <div className="flex items-center gap-3 mb-2 animate-fade-in justify-center">
          <img
            src={guildCrest}
            alt="British Field Ornithology Guild Crest"
            className="w-14 h-14 rounded-full border-2 border-amber-500/40 shadow-xl relative z-10 transition-all duration-300 hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="text-left">
            <span className="font-mono text-emerald-400 text-[10px] tracking-[0.25em] font-black block leading-none">
              BRITISH FIELD ORNITHOLOGY GUILD
            </span>
            <small className="text-[8px] font-mono tracking-widest text-stone-400 block mt-1 uppercase">
              Established 1845 ✦ Apperture Commission
            </small>
          </div>
        </div>
        
        <h1 className="font-serif text-3xl md:text-5xl font-black text-stone-100 drop-shadow-2xl tracking-tight leading-none uppercase mt-2 select-none">
          British Birds
          <br />
          <span className="text-amber-400 text-2xl md:text-3xl font-bold tracking-wide italic font-serif">
            The {ROUNDS_SET.length}-Round Aviary Expedition
          </span>
        </h1>

        {/* Live Audio Spectrogram active immediately on load to show off the visualizer! */}
        <div className="mt-4 flex flex-col items-center gap-1">
          <span className="text-[7px] font-mono text-emerald-400 tracking-widest uppercase block opacity-70">
            📡 Procedural Soundscape Engine Connected
          </span>
          <AudioSpectrogram className="w-48 h-[16px] border-0" type="bars" color="emerald" />
        </div>

        <div className="w-24 h-1 bg-gradient-to-r from-transparent via-amber-500/30 to-transparent mt-3 rounded-full" />
      </div>

      <p className="text-stone-350 font-serif italic text-sm md:text-base leading-relaxed max-w-2xl opacity-95 relative z-10">
        "Embark on a competitive pass-and-play local quest with {BIRD_DATASET.length} authentic wild species cards. Test your instincts across {ROUNDS_SET.length} randomized mini-game quiz formats – from weight drafting to taxonomic scientific naming."
      </p>

      {/* --- INCREDIBLE FEATURED BIRD SHOWCASE GALLERY --- */}
      <div className="w-full flex flex-col items-center gap-3 relative z-10 select-none my-1">
        <div className="flex items-center gap-2 justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
          <h3 className="font-mono text-amber-400 text-[9px] sm:text-[10px] uppercase tracking-[0.25em] font-black">
            ✦ EXPLORE THE BRITISH AVIARY ✦
          </h3>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
        </div>
        <p className="text-stone-400 font-sans text-[11px] leading-relaxed mb-2 max-w-lg">
          Hover or tap any specimen below to hear and play their authentic biological calls!
        </p>

        {/* Interactive soundboard block */}
        <div className="flex flex-wrap items-center justify-center gap-2 max-w-xl mx-auto my-1.5 bg-stone-900/40 p-2 border border-emerald-900/30 rounded-2xl relative z-20">
          <span className="text-[9px] font-mono font-bold tracking-wider text-emerald-400 uppercase select-none mr-1">
            🔊 Soundboard:
          </span>
          {[
            { label: "🌲 Songbird", group: "Songbirds", bird: "European Robin" },
            { label: "🦅 Raptor", group: "Raptors", bird: "Golden Eagle" },
            { label: "🦆 Waterfowl", group: "Waterfowl", bird: "Mallard" },
            { label: "🌊 Seabird", group: "Seabirds", bird: "Herring Gull" },
            { label: "🏖️ Wader", group: "Waders", bird: "Eurasian Oystercatcher" },
          ].map((sb) => (
            <button
              key={sb.label}
              onClick={() => playBirdSong(sb.group, sb.bird)}
              className="px-2.5 py-1 bg-stone-950 border border-stone-850 hover:border-amber-400/50 text-amber-400 hover:text-white rounded-xl text-[10px] font-mono cursor-pointer transition-all active:scale-95 flex items-center gap-1 shrink-0"
            >
              <span>♫</span> {sb.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-6 py-4">
          {featuredRobin && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: [0, -4, 0] }}
              transition={{
                y: { repeat: Infinity, duration: 4, ease: "easeInOut", delay: 0.1 },
                opacity: { duration: 0.5 }
              }}
              className="scale-90 md:scale-95 hover:scale-100 duration-300 transition-all relative group w-[240px] h-[340px] shrink-0"
            >
              <div className="absolute -inset-1 bg-gradient-to-b from-amber-500/10 to-transparent rounded-2xl blur opacity-30 group-hover:opacity-60 transition-opacity" />
              <BirdCardComponent 
                bird={featuredRobin} 
                onClick={() => playBirdSong(featuredRobin.group, featuredRobin.name)}
              />
            </motion.div>
          )}

          {featuredOwl && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: [0, -5, 0] }}
              transition={{
                y: { repeat: Infinity, duration: 4.5, ease: "easeInOut", delay: 0.6 },
                opacity: { duration: 0.5 }
              }}
              className="scale-90 md:scale-95 hover:scale-100 duration-300 transition-all relative group w-[240px] h-[340px] shrink-0"
            >
              <div className="absolute -inset-1 bg-gradient-to-b from-amber-500/10 to-transparent rounded-2xl blur opacity-30 group-hover:opacity-60 transition-opacity" />
              <BirdCardComponent 
                bird={featuredOwl} 
                onClick={() => playBirdSong(featuredOwl.group, featuredOwl.name)}
              />
            </motion.div>
          )}

          {featuredKingfisher && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: [0, -4.2, 0] }}
              transition={{
                y: { repeat: Infinity, duration: 4.2, ease: "easeInOut", delay: 1.1 },
                opacity: { duration: 0.5 }
              }}
              className="scale-90 md:scale-95 hover:scale-100 duration-300 transition-all relative group w-[240px] h-[340px] shrink-0"
            >
              <div className="absolute -inset-1 bg-gradient-to-b from-amber-500/10 to-transparent rounded-2xl blur opacity-30 group-hover:opacity-60 transition-opacity" />
              <BirdCardComponent 
                bird={featuredKingfisher} 
                onClick={() => playBirdSong(featuredKingfisher.group, featuredKingfisher.name)}
              />
            </motion.div>
          )}
        </div>
      </div>

      {/* Three Primary Controls Row for streamlined layout */}
      <div className="flex flex-col md:flex-row gap-5 w-full justify-center items-center mt-2 relative z-10 px-4">
        <button
          onClick={() => {
            playUiClick();
            onStart();
          }}
          className="px-10 py-4.5 w-full md:w-auto bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-2xl font-black uppercase tracking-widest border-b-4 border-amber-700 active:translate-y-1 hover:scale-102 transition-all cursor-pointer shadow-[0_20px_40px_rgba(245,158,11,0.25)] text-xs lg:text-sm flex items-center justify-center gap-2"
          id="btn-register-expedition"
        >
          <span>🎯</span>
          <span>REGISTER EXPLORERS</span>
        </button>

        <button
          onClick={() => {
            playUiClick();
            setShowFieldGuide(true);
          }}
          className="px-10 py-4.5 w-full md:w-auto bg-stone-900/85 border-2 border-amber-500/30 hover:bg-amber-500/10 text-amber-400 hover:text-amber-300 hover:border-amber-400 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2.5 active:translate-y-1 hover:scale-102 transition-all cursor-pointer shadow-2xl text-xs lg:text-sm"
          id="btn-open-guidebook"
        >
          <BookOpen size={18} className="animate-pulse text-amber-500/70" />
          <span>Royal Field Guide</span>
        </button>

        <button
          onClick={() => {
            playUiClick();
            setShowRules(true);
          }}
          className="px-10 py-4.5 w-full md:w-auto bg-stone-900/85 border-2 border-emerald-500/30 hover:bg-emerald-500/10 text-emerald-400 hover:text-emerald-250 hover:border-emerald-400 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2.5 active:translate-y-1 hover:scale-102 transition-all cursor-pointer shadow-2xl text-xs lg:text-sm"
          id="btn-open-rules"
        >
          <span className="text-emerald-500/80 animate-bounce">📜</span>
          <span>EXPEDITION HANDBOOK</span>
        </button>
      </div>

      <div className="text-[10px] text-emerald-400/80 font-mono uppercase tracking-widest mt-2 relative z-10">
        ESTABLISHED BRITISH FIELD ORNITHOLOGY GUILD ✦ COGNITIVE APERTURE CORP
      </div>

      {showFieldGuide && (
        <FieldGuideModal onClose={() => setShowFieldGuide(false)} />
      )}

      {showRules && (
        <GameRulesModal onClose={() => setShowRules(false)} />
      )}
    </div>
  );
}
