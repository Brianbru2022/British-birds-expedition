import { BirdCard } from "../types";
import { GroupIconSelector } from "./BirdIcons";
import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { Volume2 } from "lucide-react";
import { playBirdSong } from "../utils/audio";
import { getBirdImageFromDB, saveBirdImageToDB } from "../utils/db";

interface BirdCardComponentProps {
  bird: BirdCard;
  isFlipped?: boolean;
  onClick?: () => void;
  selected?: boolean;
  disabled?: boolean;
  highlightStat?: "wingspanAvg" | "weightAvg" | "lengthAvg" | "clutchAvg" | null;
  obscuredStats?: string[];
  className?: string;
}

export default function BirdCardComponent({
  bird,
  isFlipped = false,
  onClick,
  selected = false,
  disabled = false,
  highlightStat = null,
  obscuredStats = [],
  className = "",
}: BirdCardComponentProps) {
  const [imageUrl, setImageUrl] = useState<string>(`/images/birds/${bird.id}.png`);
  const [loading, setLoading] = useState<boolean>(false);
  const [hasError, setHasError] = useState<boolean>(false);
  const [useVectorFallback, setUseVectorFallback] = useState<boolean>(false);

  useEffect(() => {
    let active = true;
    setHasError(false);
    setUseVectorFallback(false);

    getBirdImageFromDB(bird.id)
      .then((dbUrl) => {
        if (!active) return;
        if (dbUrl) {
          setImageUrl(dbUrl);
        } else {
          const cached = localStorage.getItem(`bird_img_${bird.id}`);
          setImageUrl(cached || `/images/birds/${bird.id}.png`);
        }
      })
      .catch(() => {
        if (!active) return;
        const cached = localStorage.getItem(`bird_img_${bird.id}`);
        setImageUrl(cached || `/images/birds/${bird.id}.png`);
      });

    return () => {
      active = false;
    };
  }, [bird.id]);

  const handleImageError = () => {
    if (hasError) {
      // Second consecutive failure: dynamic generation failed or can't be resolved, trigger local vector silhouette
      setUseVectorFallback(true);
      setLoading(false);
      return;
    }

    setHasError(true);
    setLoading(true);
    // Render vector fallback immediately so the card NEVER looks broken or blank or stuck spinning
    setUseVectorFallback(true);

    // Call dynamic backend generator to construct the illustration in the fly and write it to disk
    fetch(`/api/birds/image?name=${encodeURIComponent(bird.name)}`)
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        return res.json();
      })
      .then((data) => {
        if (data && data.url) {
          // Add cache-busting parameter so the browser drops previous 404 cache states and re-fetches the dynamic file
          const freshUrl = `${data.url.split("?")[0]}?v=${Date.now()}`;
          
          // Preload the image in JavaScript to guarantee it is fully cached by the browser before rendering
          const img = new Image();
          img.src = freshUrl;
          img.onload = () => {
            setImageUrl(freshUrl);
            setUseVectorFallback(false);
            setLoading(false);
            setHasError(false); // Successfully resolved!

            // Store in high-capacity IndexedDB and fallback localStorage
            saveBirdImageToDB(bird.id, freshUrl);
            try {
              localStorage.setItem(`bird_img_${bird.id}`, freshUrl);
            } catch (e) {
              console.warn("Storage capacity exceeded, local storage cache skipped", e);
            }
          };
          img.onerror = () => {
            setUseVectorFallback(true);
            setLoading(false);
          };
        } else {
          setUseVectorFallback(true);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.warn("Soft handling of fallback dynamic generation error, using beautiful vector silhouette:", err);
        setUseVectorFallback(true);
        setLoading(false);
      });
  };

  // Translate rarity into stars or diamonds
  const renderRarityDots = (rarity: number) => {
    const isObscured = obscuredStats.includes("rarity");
    return (
      <div className="flex items-center gap-0.5" title={isObscured ? "Rarity: Hidden" : `Rarity: ${rarity}/5`}>
        {Array.from({ length: 5 }).map((_, i) => (
          <span
            key={i}
            className={`text-lg font-bold leading-none ${
              !isObscured && i < rarity ? "text-amber-400" : "text-stone-300"
            }`}
          >
            ✦
          </span>
        ))}
      </div>
    );
  };

  // Convert status into custom label styling
  const getConservationBadge = (status: "Green" | "Amber" | "Red") => {
    switch (status) {
      case "Red":
        return "bg-rose-50 border-rose-300 text-rose-700 font-bold";
      case "Amber":
        return "bg-amber-50 border-amber-300 text-amber-700 font-medium";
      case "Green":
      default:
        return "bg-emerald-50 border-emerald-300 text-emerald-700 font-medium";
    }
  };

  const getGroupBadgeColor = (group: string) => {
    switch (group) {
      case "Songbirds":
        return "bg-emerald-600 text-white";
      case "Raptors":
        return "bg-rose-700 text-white";
      case "Waterfowl":
        return "bg-cyan-600 text-white";
      case "Waders":
        return "bg-orange-600 text-white";
      case "Seabirds":
        return "bg-blue-700 text-white";
      case "Woodpeckers":
        return "bg-purple-700 text-white";
      default:
        return "bg-amber-800 text-white";
    }
  };

  // Display size formatted smartly
  const formatWeight = (grams: number) => {
    if (grams >= 1000) {
      return `${(grams / 1000).toFixed(1)}kg`;
    }
    return `${grams}g`;
  };

  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const handlePlay = (e: any) => {
      if (e.detail?.name === bird.name) {
        setIsPlaying(true);
      } else {
        setIsPlaying(false);
      }
    };
    const handleStop = () => {
      setIsPlaying(false);
    };

    window.addEventListener("bird-song-play", handlePlay as EventListener);
    window.addEventListener("bird-song-stop", handleStop);
    return () => {
      window.removeEventListener("bird-song-play", handlePlay as EventListener);
      window.removeEventListener("bird-song-stop", handleStop);
    };
  }, [bird.name]);

  return (
    <div
      onClick={disabled ? undefined : onClick}
      className={`relative w-[240px] min-w-[240px] h-[340px] rounded-2xl shadow-xl transition-all select-none duration-500 cursor-pointer shrink-0 ${
        selected ? "ring-4 ring-amber-400 scale-[1.03] z-[5]" : "hover:-translate-y-1 hover:shadow-2xl"
      } ${disabled ? "pointer-events-none opacity-[0.98]" : ""} ${className}`}
      id={`bird-card-${bird.id}`}
      style={{ perspective: "1000px" }}
    >
      {/* 3D Filp container (force absolute dimensions to prevent height/width collapse in Safari/iframes) */}
      <div
        className="absolute inset-0 w-full h-full block"
        style={{
          transformStyle: "preserve-3d",
          transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
          transition: "transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)",
        }}
      >
        {/* --- FRONT SIDE --- */}
        <div
          className={`absolute inset-0 bg-white rounded-2xl flex flex-col justify-between p-3.5 border-4 transition-colors ${
            selected ? "border-amber-500 shadow-2xl" : "border-emerald-700/25"
          }`}
          style={{
            transform: "rotateY(0deg) translateZ(1px)",
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden",
            boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
          }}
        >
          {/* Header row with fixed height of 48px to keep the image containers underneath perfectly identical in size */}
          <div className="flex justify-between items-start gap-1 text-black h-12">
            <div className="flex flex-col justify-start h-full flex-1 min-w-0">
              <span className="text-[9px] font-mono tracking-wider text-emerald-800 uppercase leading-none font-bold truncate block">
                {bird.scientificName}
              </span>
              <h3 className={`font-sans ${
                bird.name.length > 22 ? "text-[12px]" : bird.name.length > 15 ? "text-sm" : "text-base"
              } font-black text-emerald-950 tracking-tight leading-tight mt-0.5 line-clamp-2`}>
                {bird.name}
              </h3>
            </div>
            
            <div className="text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-wider bg-amber-500 text-black leading-none shrink-0 mt-0.5">
              {bird.group}
            </div>
          </div>

          {/* Central field sketch & aesthetic vector background */}
          <div className="relative flex-1 my-2 bg-[#FAF8F5] rounded-xl overflow-hidden flex items-center justify-center border border-emerald-700/10 shadow-inner">
            {/* Soft decorative background leaf */}
            <div className="absolute inset-0 opacity-5 flex items-center justify-center p-4">
              <GroupIconSelector group={bird.group} size={150} />
            </div>

            {/* Glowing spot background */}
            <div
              className="absolute w-24 h-24 rounded-full blur-2xl opacity-20"
              style={{ backgroundColor: bird.color }}
            />

            {/* Play Bird Call Synthesizer Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                playBirdSong(bird.group, bird.name);
              }}
              title="Synthesize species bird call"
              className={`absolute top-2 right-2 border w-7 h-7 rounded-full flex items-center justify-center shadow-lg transition-all z-25 cursor-pointer ${
                isPlaying 
                  ? "bg-amber-400 text-emerald-950 border-amber-500 scale-110 shadow-amber-400/50" 
                  : "bg-emerald-900/90 text-amber-400 hover:bg-amber-400 hover:text-emerald-950 border-amber-400/50"
              }`}
            >
              <Volume2 size={11} className={isPlaying ? "animate-bounce" : "animate-pulse"} />
            </button>

            {/* Live Equalizer Overlap when sound is playing */}
            {isPlaying && (
              <div className="absolute inset-0 bg-emerald-950/20 backdrop-blur-[1px] pointer-events-none flex flex-col items-center justify-end p-2 z-10 animate-fade-in">
                <div className="flex gap-0.5 items-end h-5 mb-1.5 justify-center">
                  <span className="w-0.75 bg-amber-400 rounded-full animate-pulse h-2.5" />
                  <span className="w-0.75 bg-amber-500 rounded-full animate-bounce h-4" />
                  <span className="w-0.75 bg-amber-400 rounded-full animate-pulse h-3" />
                  <span className="w-0.75 bg-amber-500 rounded-full animate-bounce h-5" />
                </div>
                <span className="text-[7px] font-mono font-bold tracking-widest text-amber-400 uppercase select-none leading-none shadow-sm animate-pulse">
                  🎵 Vocalizing...
                </span>
              </div>
            )}

            {/* Unique Visual Representative for each bird species */}
            {loading ? (
              <div className="flex flex-col items-center justify-center gap-2">
                <div className="animate-spin text-emerald-800">
                  <GroupIconSelector group={bird.group} size={48} />
                </div>
                <span className="text-[9px] font-mono font-bold tracking-wider text-emerald-800 uppercase animate-pulse">
                  AI Generating...
                </span>
              </div>
            ) : useVectorFallback ? (
              <div className="flex flex-col items-center justify-center p-4 text-center h-full w-full bg-stone-100/5 select-none relative">
                <div className="text-emerald-800/85 mb-2 filter drop-shadow hover:scale-105 transition-transform duration-300">
                  <GroupIconSelector group={bird.group} size={80} />
                </div>
                <span className="text-[10px] font-sans font-black uppercase tracking-widest text-emerald-900">
                  {bird.group} Group
                </span>
                <span className="text-[8px] font-mono text-stone-500 uppercase tracking-[0.15em] mt-1 block">
                  Guild Specimen Sketch
                </span>
              </div>
            ) : (
              <motion.img
                key={imageUrl}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                src={imageUrl}
                alt={bird.name}
                referrerPolicy="no-referrer"
                onError={handleImageError}
                className="w-full h-full object-contain transition-transform duration-300 hover:scale-105"
              />
            )}

            {/* Fun Fact hover banner bottom */}
            <div className="absolute bottom-0 inset-x-0 bg-emerald-950/95 text-emerald-100 text-[10px] p-2 leading-tight translate-y-full hover:translate-y-0 active:translate-y-0 focus:translate-y-0 focus-within:translate-y-0 transition-transform duration-300 pointer-events-auto flex flex-col justify-center z-10">
              <span className="font-bold text-[7px] text-amber-400 uppercase tracking-widest block mb-0.5">
                ✦ FIELD STUDY BRIEF
              </span>
              {bird.funFact}
            </div>
            
            <span className="absolute bottom-1 right-1 font-mono text-[7px] text-emerald-700 font-bold px-1 hover:opacity-0 transition-opacity z-10 bg-white/60 rounded">
              Hover for Fact 🛈
            </span>
          </div>

          {/* Stats Sheet comparisons */}
          <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] font-mono border-y border-emerald-100 py-1.5 my-1 text-emerald-900">
            <div
              className={`flex justify-between border-b border-dashed border-emerald-100 py-0.5 ${
                highlightStat === "wingspanAvg" ? "bg-amber-250 font-black px-1 rounded text-stone-900" : ""
              }`}
            >
              <span className="text-emerald-800 font-bold">Wingspan:</span>
              <span className="text-emerald-950 font-black">
                {obscuredStats.includes("wingspanAvg") ? "???" : `${bird.wingspanAvg}cm`}
              </span>
            </div>
            <div
              className={`flex justify-between border-b border-dashed border-emerald-100 py-0.5 ${
                highlightStat === "weightAvg" ? "bg-amber-250 font-black px-1 rounded text-stone-900" : ""
              }`}
            >
              <span className="text-emerald-800 font-bold">Weight:</span>
              <span className="text-emerald-950 font-black">
                {obscuredStats.includes("weightAvg") ? "???" : formatWeight(bird.weightAvg)}
              </span>
            </div>
            <div
              className={`flex justify-between py-0.5 ${
                highlightStat === "lengthAvg" ? "bg-amber-250 font-black px-1 rounded text-stone-900" : ""
              }`}
            >
              <span className="text-emerald-800 font-bold">Length:</span>
              <span className="text-emerald-950 font-black">
                {obscuredStats.includes("lengthAvg") ? "???" : `${bird.lengthAvg}cm`}
              </span>
            </div>
            <div
              className={`flex justify-between py-0.5 ${
                highlightStat === "clutchAvg" ? "bg-amber-250 font-black px-1 rounded text-stone-900" : ""
              }`}
            >
              <span className="text-emerald-800 font-bold">Clutch:</span>
              <span className="text-emerald-950 font-black">
                {obscuredStats.includes("clutchAvg") ? "???" : `${bird.clutchAvg} eggs`}
              </span>
            </div>
          </div>

          {/* Footer details */}
          <div className="flex justify-between items-center mt-1">
            <div className="flex gap-1.5 items-center">
              <span className="text-[8px] text-emerald-800 uppercase font-black tracking-wider">
                Conservation:
              </span>
              <span className={`text-[8px] font-black px-1.5 py-0.5 rounded border ${
                obscuredStats.includes("conservationStatus")
                  ? "bg-slate-100 border-stone-300 text-stone-500 font-medium"
                  : getConservationBadge(bird.conservationStatus)
              }`}>
                {obscuredStats.includes("conservationStatus") ? "Hidden" : bird.conservationStatus}
              </span>
            </div>

            {renderRarityDots(bird.rarity)}
          </div>
        </div>

        {/* --- BACK SIDE (GORGEOUS PATTERNED MYSTICAL CARD BACKING IN VIBRANT THEME) --- */}
        <div
          className="absolute inset-0 bg-emerald-900 border-4 border-emerald-500 rounded-2xl flex flex-col justify-between p-4"
          style={{
            transform: "rotateY(180deg) translateZ(1px)",
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden",
            backgroundImage: "radial-gradient(circle at center, #064e3b 0%, #022c22 100%)",
            boxShadow: "inset 0 0 20px rgba(245, 158, 11, 0.25)",
          }}
        >
          {/* Radial grid overlay matching the app theme on card backs too */}
          <div 
            className="absolute inset-0 opacity-10 pointer-events-none" 
            style={{ 
              backgroundImage: "radial-gradient(#ffffff 1px, transparent 1px)", 
              backgroundSize: "10px 10px" 
            }}
          />

          {/* Ornate Gold Border lines inside card back */}
          <div className="absolute inset-2 border border-emerald-600/60 rounded-xl pointer-events-none flex flex-col justify-between p-4">
            <div className="flex justify-between">
              <div className="w-2.5 h-2.5 border-t border-l border-amber-400" />
              <div className="w-2.5 h-2.5 border-t border-r border-amber-400" />
            </div>
            <div className="flex justify-between">
              <div className="w-2.5 h-2.5 border-b border-l border-amber-400" />
              <div className="w-2.5 h-2.5 border-b border-r border-amber-400" />
            </div>
          </div>

          {/* Centered Golden field compass emblem with feather shapes */}
          <div className="flex-1 flex flex-col items-center justify-center gap-2">
            <div className="relative w-24 h-24 rounded-full border-2 border-amber-400/40 flex items-center justify-center bg-emerald-950/70">
              {/* Outer compass ticking rings */}
              <div className="absolute inset-1.5 rounded-full border border-dashed border-amber-400/35 animate-spin-slow pointer-events-none" />
              {/* Inner feathers shape vector emblem */}
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" className="text-amber-400 font-black">
                <path d="M12 2L15 8L21 9L16.5 13.5L18 19.5L12 16.5L6 19.5L7.5 13.5L3 9L9 8L12 2Z" fill="currentColor" opacity="0.15" />
                <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 3.5 1 8a7 7 0 0 1-9 10Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
            
            <span className="font-sans tracking-[0.15em] text-[10px] text-amber-400 font-black uppercase mt-2">
              THE AVIARY DECK
            </span>
            <span className="font-mono text-[8px] text-emerald-300 uppercase tracking-widest mt-1">
              Active Game Card
            </span>
          </div>

          <div className="flex justify-between items-center px-1 text-[8px] font-mono text-emerald-400/80">
            <span>VOL 15: ORNITHOLOGY</span>
            <span>Est. 1926</span>
          </div>
        </div>
      </div>
    </div>
  );
}
