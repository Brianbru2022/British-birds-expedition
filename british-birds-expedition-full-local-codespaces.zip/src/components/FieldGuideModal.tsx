import { useState, useEffect } from "react";
import { BIRD_DATASET } from "../data/birds";
import { BirdCard, BirdGroup, HabitatType } from "../types";
import BirdCardComponent from "./BirdCardComponent";
import { playBirdSong, audioPlaybackSettings, audioDeviceMode } from "../utils/audio";
import { getSightedBirds } from "../utils/journal";
import { Search, X, Volume2, ShieldAlert, Navigation, Compass, Lock, Eye, RefreshCw, WifiOff, CheckCircle } from "lucide-react";
import AudioSpectrogram from "./AudioSpectrogram";
import { getAllCachedBirdIds, saveBirdImageToDB } from "../utils/db";

interface FieldGuideModalProps {
  onClose: () => void;
}

export default function FieldGuideModal({ onClose }: FieldGuideModalProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGroup, setSelectedGroup] = useState<BirdGroup | "All">("All");
  const [selectedHabitat, setSelectedHabitat] = useState<HabitatType | "All">("All");
  const [selectedBird, setSelectedBird] = useState<BirdCard | null>(BIRD_DATASET[0]);
  const [sightings] = useState(() => getSightedBirds());
  const [useRealAiAudio, setUseRealAiAudio] = useState(audioDeviceMode.useRealAiAudio);

  const handleToggleAiAudio = (val: boolean) => {
    audioDeviceMode.useRealAiAudio = val;
    setUseRealAiAudio(val);
  };

  // --- AUDIO SYNTHESIS PLAYGROUND STATES ---
  const [pitchWarp, setPitchWarp] = useState(audioPlaybackSettings.pitchWarpHz);
  const [speedMult, setSpeedMult] = useState(audioPlaybackSettings.speedMultiplier);
  const [waveform, setWaveform] = useState<OscillatorType | null>(audioPlaybackSettings.waveformOverride);

  const handlePitchChange = (hz: number) => {
    audioPlaybackSettings.pitchWarpHz = hz;
    setPitchWarp(hz);
  };
  const handleSpeedChange = (mult: number) => {
    audioPlaybackSettings.speedMultiplier = mult;
    setSpeedMult(mult);
  };
  const handleWaveformOverride = (type: OscillatorType | null) => {
    audioPlaybackSettings.waveformOverride = type;
    setWaveform(type);
  };
  const handleResetSynth = () => {
    audioPlaybackSettings.pitchWarpHz = 0;
    audioPlaybackSettings.speedMultiplier = 1.0;
    audioPlaybackSettings.waveformOverride = null;
    setPitchWarp(0);
    setSpeedMult(1.0);
    setWaveform(null);
  };

  // --- OFFLINE ARCHIVAL PRE-LOADER STATES ---
  const [syncing, setSyncing] = useState(false);
  const [syncStep, setSyncStep] = useState("");
  const [syncedCount, setSyncedCount] = useState(0);

  useEffect(() => {
    // Fetch count of uniquely cached birds
    getAllCachedBirdIds().then((dbIds) => {
      const dbCachedSet = new Set(dbIds);
      let count = 0;
      BIRD_DATASET.forEach((b) => {
        if (dbCachedSet.has(b.id) || localStorage.getItem(`bird_img_${b.id}`)) {
          count++;
        }
      });
      setSyncedCount(count);
    });
  }, []);

  const handlemassOfflinePreload = async () => {
    if (syncing) return;
    setSyncing(true);
    setSyncStep("Transmitting telemetry...");

    const dbIds = await getAllCachedBirdIds();
    const dbCachedSet = new Set(dbIds);
    let count = 0;
    
    // Calculate already synced from scratch
    const currentSyncedMap = new Map<string, boolean>();
    BIRD_DATASET.forEach(b => {
      if (dbCachedSet.has(b.id) || localStorage.getItem(`bird_img_${b.id}`)) {
        currentSyncedMap.set(b.id, true);
        count++;
      }
    });
    setSyncedCount(count);

    for (const bird of BIRD_DATASET) {
      if (currentSyncedMap.has(bird.id)) {
        continue;
      }
      setSyncStep(`Archiving dynamic portrait for ${bird.name}...`);
      try {
        const response = await fetch(`/api/birds/image?name=${encodeURIComponent(bird.name)}`);
        const data = await response.json();
        if (data && data.url) {
          await saveBirdImageToDB(bird.id, data.url);
          try {
            localStorage.setItem(`bird_img_${bird.id}`, data.url);
          } catch(e) {}
        }
      } catch (err) {
        console.warn(`Preloading failed for ${bird.name}, using fail-safe seed`, err);
        const seed = bird.name.replace(/\s+/g, "").toLowerCase();
        const fallbackUrl = `https://picsum.photos/seed/${seed}/400/400`;
        await saveBirdImageToDB(bird.id, fallbackUrl);
        try {
          localStorage.setItem(`bird_img_${bird.id}`, fallbackUrl);
        } catch (e) {}
      }
      count++;
      setSyncedCount(count);
      // Wait slightly
      await new Promise(r => setTimeout(r, 60));
    }
    setSyncStep("Archival preloading complete! 100% synced for offline use.");
    setSyncing(false);
  };

  // Unique groups list
  const groups: (BirdGroup | "All")[] = [
    "All",
    "Songbirds",
    "Raptors",
    "Waterfowl",
    "Waders",
    "Seabirds"
  ];

  const habitats: (HabitatType | "All")[] = [
    "All",
    "Gardens",
    "Woodlands",
    "Coasts",
    "Wetlands",
    "Moorlands",
    "Farmland"
  ];

  const filteredBirds = BIRD_DATASET.filter((bird) => {
    const matchesSearch = bird.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          bird.scientificName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGroup = selectedGroup === "All" || bird.group === selectedGroup;
    const matchesHabitat = selectedHabitat === "All" || bird.habitat === selectedHabitat;
    return matchesSearch && matchesGroup && matchesHabitat;
  });

  const handleSelectBird = (bird: BirdCard) => {
    setSelectedBird(bird);
    playBirdSong(bird.group, bird.name);
  };

  return (
    <div className="fixed inset-0 bg-stone-950/95 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 overflow-hidden animate-fade-in text-white">
      <div className="bg-stone-900 border-2 border-emerald-800 rounded-3xl w-full max-w-6xl h-[92vh] flex flex-col overflow-hidden shadow-2xl relative">
        
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-emerald-800 bg-stone-950/70 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <Compass className="text-amber-400 animate-spin-slow w-6 h-6 sm:w-7 sm:h-7" />
            <div className="text-left">
              <span className="font-mono text-[9px] uppercase tracking-widest text-emerald-400 block font-bold leading-none">
                Official British Avian Registry
              </span>
              <h2 className="font-serif text-xl sm:text-2xl font-black text-white leading-tight uppercase tracking-tight mt-1">
                The Royal Imperial Field Guide
              </h2>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 hover:bg-stone-850 rounded-full text-slate-400 hover:text-white transition-all border border-stone-800 cursor-pointer"
            title="Close Guidebook"
          >
            <X size={20} />
          </button>
        </div>

        {/* Filter Toolbar */}
        <div className="p-4 bg-stone-950/40 border-b border-emerald-950 flex flex-col gap-3 shrink-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            
            {/* Search Bar */}
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-emerald-600">
                <Search size={16} />
              </span>
              <input
                type="text"
                placeholder="Search common name or taxonomy..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full text-sm py-2.5 pl-10 pr-4 bg-stone-950 border border-stone-800 rounded-xl focus:outline-none focus:border-amber-400 text-stone-100 placeholder-stone-600 transition-all font-mono"
              />
            </div>

            {/* Filter by Wildlife Group */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-stone-500 uppercase shrink-0">GROUP:</span>
              <select
                value={selectedGroup}
                onChange={(e) => setSelectedGroup(e.target.value as any)}
                className="w-full text-xs py-2 px-3 bg-stone-950 border border-stone-800 rounded-xl focus:outline-none focus:border-amber-400 text-stone-200 font-mono"
              >
                {groups.map(grp => (
                  <option key={grp} value={grp}>{grp}</option>
                ))}
              </select>
            </div>

            {/* Filter by Habitat */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-stone-500 uppercase shrink-0">HABITAT:</span>
              <select
                value={selectedHabitat}
                onChange={(e) => setSelectedHabitat(e.target.value as any)}
                className="w-full text-xs py-2 px-3 bg-stone-950 border border-stone-800 rounded-xl focus:outline-none focus:border-amber-400 text-slate-200 font-mono"
              >
                {habitats.map(hab => (
                  <option key={hab} value={hab}>{hab}</option>
                ))}
              </select>
            </div>

          </div>
        </div>

        {/* Major Content Area */}
        <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden bg-stone-950/20">
          
          {/* Left panel - Interactive Scrollable Species Grid */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 border-b lg:border-b-0 lg:border-r border-emerald-950">
            
            {/* OFFLINE EXPEDITION PACK SYNC PANEL */}
            <div className="mb-5 bg-gradient-to-r from-emerald-950/40 to-stone-900 border border-emerald-500/25 p-4 rounded-2xl shadow-lg text-left relative overflow-hidden">
              <div className="absolute right-3 top-3 opacity-10 pointer-events-none">
                <WifiOff size={48} className="text-amber-400" />
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-15">
                <div>
                  <h3 className="font-sans font-black text-sm text-stone-100 uppercase tracking-tight flex items-center gap-1.5 leading-none">
                    <span>📦</span>
                    <span>Royal Expedition Offline Pack Sync</span>
                  </h3>
                  <p className="text-stone-400 text-[10px] leading-snug mt-1 max-w-xl">
                    Pre-download and store AI scientific field illustration files locally in your browser. This enables full-speed image rendering and gameplay when completely disconnected from active networks.
                  </p>
                  {syncStep && (
                    <div className="text-[9px] font-mono text-emerald-400 bg-black/45 hover:bg-black/60 px-2.5 py-1 rounded border border-emerald-900/45 inline-block mt-2 font-black leading-none animate-pulse">
                      STATUS ✦ {syncStep}
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-end shrink-0 gap-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] text-stone-400">SYNCED DISK STATUS:</span>
                    <strong className="font-mono text-xs text-amber-400 bg-stone-950 px-2 py-0.5 rounded border border-stone-850">
                      {syncedCount} / {BIRD_DATASET.length} PORTRAITS
                    </strong>
                  </div>

                  <button
                    onClick={handlemassOfflinePreload}
                    disabled={syncing || syncedCount === BIRD_DATASET.length}
                    className={`flex items-center gap-1.5 px-3 py-2 text-[10px] font-sans font-black uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer select-none leading-none w-full sm:w-auto justify-center ${
                      syncedCount === BIRD_DATASET.length
                        ? "bg-stone-950 text-emerald-400 border border-emerald-900/60"
                        : syncing
                          ? "bg-amber-500/10 text-amber-450 border border-amber-500/30 font-bold active:scale-100 cursor-not-allowed"
                          : "bg-amber-500 text-stone-950 hover:bg-amber-400 active:scale-95"
                    }`}
                  >
                    {syncedCount === BIRD_DATASET.length ? (
                      <>
                        <CheckCircle size={10} className="text-emerald-400" />
                        <span>All Assets Fully Synced</span>
                      </>
                    ) : syncing ? (
                      <>
                        <RefreshCw size={10} className="animate-spin text-amber-500" />
                        <span>Caching Assets...</span>
                      </>
                    ) : (
                      <>
                        <span>💾</span>
                        <span>Pre-download All Portraits</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Progress bar line */}
              <div className="w-full h-1 bg-stone-950/60 rounded-full mt-3 overflow-hidden border border-stone-850">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 to-amber-500 transition-all duration-300"
                  style={{ width: `${(syncedCount / BIRD_DATASET.length) * 100}%` }}
                />
              </div>
            </div>

            <div className="flex items-center justify-between mb-3 shrink-0">
              <span className="font-mono text-xs text-stone-400">
                All-Time Sighted & Logged: <span className="text-emerald-400 font-black text-sm">{Object.keys(sightings).length}</span> / {BIRD_DATASET.length}
              </span>
              <span className="font-mono text-[10px] text-stone-500">
                Listed in Active Workspace Filters: {filteredBirds.length}
              </span>
            </div>
            
            {filteredBirds.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 sm:h-64 text-stone-500 gap-2 border border-dashed border-stone-800 rounded-2xl">
                <ShieldAlert size={36} className="text-stone-600 animate-pulse" />
                <span className="font-mono text-xs">No matching species reported in these fields.</span>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
                {filteredBirds.map((bird) => {
                  const isSelected = selectedBird?.id === bird.id;
                  const isSighted = !!sightings[bird.id];
                  const sightingRecord = sightings[bird.id];

                  return (
                    <div
                      key={bird.id}
                      onClick={() => handleSelectBird(bird)}
                      className={`p-3 rounded-2xl border-2 cursor-pointer transition-all text-left flex flex-col justify-between h-[110px] relative overflow-hidden group ${
                        isSelected 
                          ? "bg-emerald-950/40 border-amber-400 shadow-lg scale-[0.98]" 
                          : isSighted
                            ? "bg-stone-900/40 border-stone-800/80 hover:bg-stone-850/50 hover:border-emerald-700/60"
                            : "bg-stone-950/80 border-stone-900/60 opacity-60 hover:opacity-85 hover:border-stone-800"
                      }`}
                    >
                      {/* Subtle accent color bar */}
                      <div 
                        className="absolute bottom-0 right-0 top-0 w-1.5 opacity-40 group-hover:opacity-100 transition-opacity" 
                        style={{ backgroundColor: bird.color }}
                      />

                      <div className="relative pr-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-mono text-[8px] uppercase text-emerald-400/80 font-bold leading-none block truncate max-w-[80%]">
                            {bird.scientificName}
                          </span>
                          {!isSighted && (
                            <Lock size={10} className="text-stone-600 shrink-0" title="Undiscovered in active gameplay" />
                          )}
                          {isSighted && (
                            <Eye size={10} className="text-emerald-400 shrink-0" title={`Logged by ${sightingRecord?.spottedBy}`} />
                          )}
                        </div>
                        <h4 className={`font-sans font-black text-xs uppercase tracking-tight mt-1 line-clamp-2 pr-4 ${isSighted ? 'text-stone-100' : 'text-stone-400 font-medium'}`}>
                          {bird.name}
                        </h4>
                      </div>

                      <div className="flex items-center justify-between mt-auto">
                        <span className="text-[8px] bg-stone-950 text-stone-400 px-1.5 py-0.5 rounded uppercase font-mono tracking-wider font-bold">
                          {bird.group}
                        </span>
                        
                        <div className="flex items-center gap-1">
                          <span className="text-[7.5px] text-stone-500 font-mono">
                            {isSighted ? `${bird.wingspanAvg}cm` : "??? cm"}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right panel - Highlight Species Detailed Bio Card */}
          <div className="w-full lg:w-[380px] shrink-0 p-4 sm:p-5 flex flex-col items-center justify-center bg-stone-950/55 overflow-y-auto border-t lg:border-t-0 border-emerald-950 gap-4 min-w-0">
            {selectedBird ? (
              <div className="w-full flex flex-col items-center gap-4 py-2 animate-fade-in">
                
                {/* Embedded Bird Card */}
                <div className="scale-[0.95] sm:scale-100 relative">
                  <BirdCardComponent 
                    bird={selectedBird} 
                    isFlipped={false} 
                    disabled={true} 
                  />
                </div>

                 {/* Additional Dossier Content */}
                <div className="w-full bg-stone-900/60 border border-stone-800 p-4 rounded-2xl text-left">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[9px] bg-yellow-400/10 text-yellow-400 font-mono font-black uppercase tracking-widest px-2.5 py-1 rounded-full border border-yellow-400/25">
                      ENCYCLOPEDIC STATS
                    </span>
                    <button
                      onClick={() => playBirdSong(selectedBird.group, selectedBird.name)}
                      className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 active:scale-95 text-stone-950 font-sans font-black text-[9px] uppercase rounded-xl tracking-wider transition-all cursor-pointer shadow-md"
                    >
                      <Volume2 size={10} className="animate-bounce" />
                      Listen Call
                    </button>
                  </div>

                  {/* Sighting status */}
                  {sightings[selectedBird.id] ? (
                    <div className="p-2.5 mb-3 bg-emerald-950/40 border border-emerald-900/40 rounded-xl text-[10px] font-mono text-emerald-300 flex items-center gap-2">
                      <Eye size={12} className="text-emerald-400 animate-pulse shrink-0" />
                      <span>Logged by <strong className="text-white uppercase">{sightings[selectedBird.id]?.spottedBy}</strong> on {sightings[selectedBird.id]?.date}!</span>
                    </div>
                  ) : (
                    <div className="p-2.5 mb-3 bg-stone-950/80 border border-stone-850 rounded-xl text-[10px] font-mono text-stone-500 flex items-center gap-2">
                      <Lock size={12} className="text-stone-600 shrink-0" />
                      <span>Undiscovered in play-match. Identify correctly to lock-log!</span>
                    </div>
                  )}

                  <h3 className="text-lg font-serif font-black text-amber-400 tracking-tight leading-snug">
                    {selectedBird.name}
                  </h3>
                  <div className="text-[10px] font-mono text-stone-400 italic mb-3">
                    {selectedBird.scientificName}
                  </div>

                  {/* Field Fact Bio Box */}
                  <div className="p-3 bg-stone-950/70 border border-stone-850 rounded-xl mb-3 text-xs font-serif leading-relaxed italic text-stone-300">
                    "{selectedBird.funFact}"
                  </div>

                  {/* ACTIVE LIVE AUDIO WAVE ANALYSER GRAPH */}
                  <div className="mb-3 bg-stone-950 border border-stone-850 p-2.5 rounded-xl text-left">
                    <span className="text-[7.5px] font-mono text-amber-400 uppercase tracking-widest block mb-1">
                      📡 Live Bio-Acoustic Spectrogram:
                    </span>
                    <AudioSpectrogram className="h-[40px] w-full border-0" type="wave" color="mixed" />
                  </div>

                  {/* ⚡ REAL CO-ACOUSTIC BIOLOGICAL VOICES BY GOOGLE GEMINI */}
                  <div className="mb-3 bg-stone-950/90 border border-amber-500/20 p-2.5 rounded-xl text-left">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[8px] font-mono text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1">
                        <span>🔊</span> AUDIO ENGINE SELECTION
                      </span>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input 
                        type="checkbox"
                        checked={useRealAiAudio}
                        onChange={(e) => handleToggleAiAudio(e.target.checked)}
                        className="w-3.5 h-3.5 text-amber-500 bg-stone-950 border-stone-800 accent-amber-500 cursor-pointer"
                      />
                      <span className="text-[9px] font-mono text-stone-200 uppercase font-bold tracking-tight">
                        Use Authentic Biological Calls
                      </span>
                    </label>
                    <p className="text-[7.5px] font-mono text-stone-500 mt-1 uppercase leading-snug">
                      {useRealAiAudio 
                        ? "⚡ ACTIVE: Downloads real biological recordings from the server or generates them via Gemini Lyria! Fallback to synth if unavailable."
                        : "🎹 BASIC: Uses offline Web Audio API oscillators to model vocal sweeps natively in the browser."}
                    </p>
                  </div>

                  {/* 🎹 BIOPHONIC MODULATION SYNTHESIZER BOARD */}
                  <div className="mb-4 bg-stone-950/80 border border-amber-500/20 p-3 rounded-xl text-left flex flex-col gap-2.5">
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-mono text-amber-400 font-bold uppercase tracking-wider flex items-center gap-1">
                        <span>🎹</span> BIO-ACOUSTIC VOCAL MODULATOR
                      </span>
                      <button 
                        onClick={handleResetSynth}
                        className="text-[7px] font-mono uppercase bg-stone-900 border border-stone-800 text-stone-400 hover:text-white px-1.5 py-0.5 rounded leading-none cursor-pointer"
                      >
                        Reset Defaults
                      </button>
                    </div>

                    {/* Pitch offset slider */}
                    <div className="flex flex-col gap-0.5">
                      <div className="flex justify-between items-center text-[7.5px] font-mono text-stone-400">
                        <span>Frequency Warp: {pitchWarp > 0 ? `+${pitchWarp}` : pitchWarp} Hz</span>
                        <span className="text-amber-500 text-[7px] font-bold uppercase">
                          {pitchWarp === 0 ? "Natural" : pitchWarp > 0 ? "High Chirper" : "Low Growler"}
                        </span>
                      </div>
                      <input 
                        type="range" 
                        min="-1200" 
                        max="1200" 
                        step="100" 
                        value={pitchWarp} 
                        onChange={(e) => handlePitchChange(Number(e.target.value))} 
                        className="w-full h-1 accent-amber-500 bg-stone-900 rounded-lg cursor-pointer" 
                      />
                    </div>

                    {/* Speed multiplier slider */}
                    <div className="flex flex-col gap-0.5">
                      <div className="flex justify-between items-center text-[7.5px] font-mono text-stone-400">
                        <span>Vocal Rate / Tempo: {speedMult.toFixed(1)}x</span>
                        <span className="text-emerald-400 text-[7px] font-bold uppercase">
                          {speedMult === 1.0 ? "Standard" : speedMult > 1.0 ? "Fast Warbler" : "Slow Drone"}
                        </span>
                      </div>
                      <input 
                        type="range" 
                        min="0.4" 
                        max="2.2" 
                        step="0.2" 
                        value={speedMult} 
                        onChange={(e) => handleSpeedChange(Number(e.target.value))} 
                        className="w-full h-1 accent-emerald-500 bg-stone-900 rounded-lg cursor-pointer" 
                      />
                    </div>

                    {/* Waveform Override buttons */}
                    <div className="flex flex-col gap-1">
                      <span className="text-[7px] font-mono text-stone-400 uppercase tracking-wider block">Vocal Chord Waveform:</span>
                      <div className="grid grid-cols-5 gap-1">
                        {(['sine', 'triangle', 'sawtooth', 'square', 'original'] as const).map((wt) => (
                          <button
                            key={wt}
                            onClick={() => handleWaveformOverride(wt === 'original' ? null : wt)}
                            className={`py-1 text-[7px] font-mono uppercase tracking-tighter leading-none rounded border text-center transition-all cursor-pointer ${
                              (wt === 'original' ? !waveform : waveform === wt)
                                ? "bg-amber-500 text-stone-950 border-amber-500 font-bold shadow-sm"
                                : "bg-stone-900 text-stone-400 border-stone-850 hover:bg-stone-800"
                            }`}
                          >
                            {wt === 'original' ? 'Org' : wt.substring(0, 4)}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Stats Grid */}
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs font-mono">
                    <div className="flex flex-col border-b border-stone-800/60 pb-1.5">
                      <span className="text-[9px] text-stone-500 uppercase">MIGRATORY STATUS</span>
                      <span className="text-stone-300 font-bold flex items-center gap-1 mt-0.5">
                        <Navigation size={10} className="text-emerald-400 shrink-0" />
                        {selectedBird.migratoryStatus}
                      </span>
                    </div>

                    <div className="flex flex-col border-b border-stone-800/60 pb-1.5">
                      <span className="text-[9px] text-stone-500 uppercase">PRIMARY DIET</span>
                      <span className="text-stone-300 font-bold mt-0.5">{selectedBird.primaryDiet}</span>
                    </div>

                    <div className="flex flex-col border-b border-stone-800/60 pb-1.5">
                      <span className="text-[9px] text-stone-500 uppercase">TYPICAL HABITAT</span>
                      <span className="text-stone-300 font-bold mt-0.5">{selectedBird.habitat}</span>
                    </div>

                    <div className="flex flex-col border-b border-stone-800/60 pb-1.5">
                      <span className="text-[9px] text-stone-500 uppercase">UK CONSERVATION</span>
                      <span className={`font-black uppercase text-[10px] tracking-wide mt-1 inline-block text-center ${
                        selectedBird.conservationStatus === 'Red' ? 'text-rose-450' : selectedBird.conservationStatus === 'Amber' ? 'text-amber-400' : 'text-emerald-400'
                      }`}>
                        {selectedBird.conservationStatus} LISTED
                      </span>
                    </div>
                  </div>
                </div>

              </div>
            ) : (
              <div className="text-stone-500 font-mono text-xs text-center">
                Select a bird card to display its complete field studies profile & listen to its call.
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
