// Procedural audio generation using the Web Audio API.
// No external mp3 dependencies are required. This synthesizes elegant,
// custom-tailored vocalizations (trills, chirps, sweeps, and calls)
// based on the bird's group as well as soft ambient forest backgrounds.

let audioCtx: AudioContext | null = null;
let forestNode: AudioNode | null = null;
let forestTimer: any = null;
let analyserNode: AnalyserNode | null = null;

export const audioPlaybackSettings = {
  pitchWarpHz: 0,        // -1500 to +1500 hz offset
  speedMultiplier: 1.0,  // 0.4 to 2.2
  waveformOverride: null as OscillatorType | null, // override "sine", "sawtooth", etc.
  masterVolume: 0.85,     // 0 to 1.0
};

export function getAudioContext() {
  if (typeof window === "undefined") return null as any;
  if (audioCtx && audioCtx.state === "closed") {
    audioCtx = null;
  }
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (!analyserNode && audioCtx) {
    analyserNode = audioCtx.createAnalyser();
    analyserNode.fftSize = 256; // 256 samples
    analyserNode.smoothingTimeConstant = 0.75;
    // Standalone analyzer - do NOT connect analyserNode.connect(audioCtx.destination)
    // as it can lock up the audio rendering graph on iOS/Safari in suspended states.
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume().catch((err) => console.log("Failed to resume context on call:", err));
  }
  return audioCtx;
}

export function getAudioAnalyser() {
  return analyserNode;
}

export function withRunningContext(callback: (ctx: AudioContext) => void) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    if (ctx.state === "suspended") {
      ctx.resume().catch((err) => {
        console.warn("Failed to resume AudioContext inside withRunningContext:", err);
      });
    }

    try {
      callback(ctx);
    } catch (e) {
      console.error("Audio callback execution error:", e);
    }
  } catch (err) {
    console.error("Error securing running audio context:", err);
  }
}

// Add automated window touch/click unlockers so standard browsers resume suspended context on the very first tap/click!
if (typeof window !== "undefined") {
  const unlockEvents = ["click", "touchstart", "mousedown", "pointerdown", "keydown"];
  
  const unlock = () => {
    try {
      const ctx = getAudioContext();
      if (ctx) {
        if (ctx.state === "suspended") {
          ctx.resume().catch(() => {});
        }
        
        // Force-create and play a tiny fraction-of-a-second silent buffer to satisfy iOS gesture chain criteria
        const buffer = ctx.createBuffer(1, 1, 22050);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start(0);

        // Success, we can clean up event listeners immediately to avoid executing multiple times
        unlockEvents.forEach((evt) => {
          window.removeEventListener(evt, unlock, { capture: true });
        });
      }
    } catch (e) {
      console.warn("Failed to unlock AudioContext via gesture:", e);
    }
  };

  unlockEvents.forEach((evt) => {
    window.addEventListener(evt, unlock, { capture: true });
  });
}

export const audioDeviceMode = {
  // Toggle between Gemini Real Bio-acoustic calls and mathematical retro synthetics
  useRealAiAudio: false,
};

// Active track nodes so we can cancel active oscillators/gains if the user clicks rapidly!
let activeAudioSource: AudioBufferSourceNode | null = null;
let activeAudioNodes: Array<{ stop?: () => void; disconnect?: () => void }> = [];
let songStopTimeout: any = null;

export function stopActiveBirdSong() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("bird-song-stop"));
    if (songStopTimeout) {
      clearTimeout(songStopTimeout);
      songStopTimeout = null;
    }
  }
  if (activeAudioSource) {
    try {
      activeAudioSource.stop();
    } catch (_) {}
    activeAudioSource = null;
  }
  // Immediately stop and release all active procedural oscillators and generators to keep audio responsive
  activeAudioNodes.forEach(node => {
    try {
      if (node.stop) node.stop();
    } catch (_) {}
    try {
      if (node.disconnect) node.disconnect();
    } catch (_) {}
  });
  activeAudioNodes = [];
}

// Main playback dispatcher supporting online AI audio streaming or micro synth fallbacks
export function playBirdSong(group: string, name: string, isDistant = false) {
  if (!isDistant) {
    stopActiveBirdSong();
  }

  // Force synchronous wake of AudioContext on user physical gesture before any potential async fetches can block it
  try {
    const ctx = getAudioContext();
    if (ctx && ctx.state === "suspended") {
      ctx.resume().catch(() => {});
    }
  } catch (e) {
    console.warn("Synchronous click audio resume error:", e);
  }

  if (typeof window !== "undefined" && !isDistant) {
    window.dispatchEvent(new CustomEvent("bird-song-play", { detail: { name, group } }));
    if (songStopTimeout) {
      clearTimeout(songStopTimeout);
    }
    // Most birds vocalize for 3 to 4.5 seconds before fading
    songStopTimeout = setTimeout(() => {
      window.dispatchEvent(new CustomEvent("bird-song-stop"));
    }, 3800);
  }

  if (audioDeviceMode.useRealAiAudio && !isDistant) {
    playRealBirdSongWithFallback(group, name);
  } else {
    playProceduralBirdSong(group, name, isDistant);
  }
}

async function fetchWithTimeout(resource: string, options: any = {}) {
  const { timeout = 1500 } = options;
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(resource, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

async function playRealBirdSongWithFallback(group: string, name: string) {
  try {
    const ctx = getAudioContext();
    if (ctx && ctx.state === "suspended") {
      await ctx.resume().catch(() => {});
    }

    // Retrieve the generated audio URL from our Express background database with an aggressive timeout
    const res = await fetchWithTimeout(`/api/birds/sound?name=${encodeURIComponent(name)}`, { timeout: 1500 });
    if (!res.ok) throw new Error("Audio endpoint query error");
    
    const data = await res.json();
    if (!data.url) throw new Error("Real vocalizations not loaded/cached");

    // Fetch binary WAV output with an aggressive timeout
    const audioRes = await fetchWithTimeout(data.url, { timeout: 1500 });
    if (!audioRes.ok) throw new Error("Failed to reach file stream");
    
    const arrayBuffer = await audioRes.arrayBuffer();
    const audioBuffer = await ctx.decodeAudioData(arrayBuffer);

    // Stop to handle rapid-clicking/spamming
    stopActiveBirdSong();

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;

    const masterGain = ctx.createGain();
    
    // Fetch fresh non-stale currentTime *after* the network fetching is done!
    const playbackTime = ctx.currentTime;
    masterGain.gain.setValueAtTime(0, playbackTime);
    masterGain.gain.linearRampToValueAtTime(audioPlaybackSettings.masterVolume * 1.5, playbackTime + 0.05);

    // Pipe directly to the output destination (speakers), and in parallel to the visualizer if present.
    masterGain.connect(ctx.destination);
    if (analyserNode) {
      masterGain.connect(analyserNode);
    }
    source.connect(masterGain);
    
    source.start(playbackTime);
    activeAudioSource = source;

  } catch (err) {
    console.log(`[BioPhonic] Falling back to procedural synthesizer: ${err instanceof Error ? err.message : err}`);
    playProceduralBirdSong(group, name);
  }
}

/**
 * Synthesizes highly realistic bird calls on the fly using dual-syrinx math oscillators,
 * breath noise filters, formants, non-linear throat flutter (jitter), and deep forest reverb!
 */
export function playProceduralBirdSong(group: string, name: string, isDistant = false) {
  withRunningContext((ctx) => {
    try {
      const now = ctx.currentTime;

      const createOsc = (defaultType: OscillatorType) => {
        const o = ctx.createOscillator();
        o.type = audioPlaybackSettings.waveformOverride || defaultType;
        if (!isDistant) {
          activeAudioNodes.push(o);
        }
        return o;
      };

      const registerGain = (g: GainNode) => {
        if (!isDistant) {
          activeAudioNodes.push(g as any);
        }
        return g;
      };

      // Use a unique seed from the bird's name to vary pitch slightly so every bird sounds distinct
      let seedVal = 0;
      for (let i = 0; i < name.length; i++) {
           seedVal += name.charCodeAt(i);
      }
      const pitchOffset = ((seedVal % 150) - 75) + audioPlaybackSettings.pitchWarpHz; // hz offset
      const speedRatio = (0.9 + ((seedVal % 10) / 50)) * audioPlaybackSettings.speedMultiplier; // speed multiplier

      // Master Volume Limiter (softer for distant background calls)
      const masterGain = registerGain(ctx.createGain());
      masterGain.gain.setValueAtTime(0, now);
      const targetVolume = isDistant ? audioPlaybackSettings.masterVolume * 0.15 : audioPlaybackSettings.masterVolume;
      masterGain.gain.linearRampToValueAtTime(targetVolume, now + 0.05);
      
      // Parallel routing topology: directly to speakers, and to analyser node if it exists
      masterGain.connect(ctx.destination);
      if (analyserNode) {
        masterGain.connect(analyserNode);
      }

      // Dynamic bandpass filter matching typical bird vocal ranges (1.2kHz - 7.5kHz)
      const bandpass = ctx.createBiquadFilter();
      bandpass.type = "bandpass";
      bandpass.frequency.setValueAtTime(3400, now);
      bandpass.Q.setValueAtTime(1.2, now);
      bandpass.connect(masterGain);

      // ENVIRONMENTAL CO-ACOUSTIC FOREST REVERB AND ECHO UNIT
      const delayNode = ctx.createDelay(1.5);
      const feedbackGain = registerGain(ctx.createGain());
      const echoFilter = ctx.createBiquadFilter();

      delayNode.delayTime.setValueAtTime(0.22 * speedRatio, now);
      feedbackGain.gain.setValueAtTime(0.42, now); // Sweet 42% feedback
      echoFilter.type = "lowpass";
      echoFilter.frequency.setValueAtTime(1600, now); // Soft environmental decay

    // Connect feedback loop
    delayNode.connect(echoFilter);
    echoFilter.connect(feedbackGain);
    feedbackGain.connect(delayNode);
    // Feed delay wet into master output
    delayNode.connect(masterGain);

    const routeToOutput = (node: AudioNode) => {
      node.connect(bandpass);
      node.connect(delayNode); // Send space feed
    };

    // Noise Generator helper for adding biological breathiness, wood friction or wind raspiness
    const playBreathNoise = (startTime: number, duration: number, startVolume: number, frequencyCutoff: number) => {
      const bufferSize = ctx.sampleRate * duration;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noiseNode = ctx.createBufferSource();
      noiseNode.buffer = buffer;

      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = "bandpass";
      noiseFilter.frequency.setValueAtTime(frequencyCutoff, startTime);
      noiseFilter.Q.setValueAtTime(3.5, startTime);

      const noiseGain = registerGain(ctx.createGain());
      noiseGain.gain.setValueAtTime(0, startTime);
      noiseGain.gain.linearRampToValueAtTime(startVolume, startTime + 0.015);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      noiseNode.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(bandpass);

      noiseNode.start(startTime);
      noiseNode.stop(startTime + duration);
      if (!isDistant) {
        activeAudioNodes.push(noiseNode);
      }
    };

    const lowerName = name.toLowerCase();

    // =========================================================================
    // 🌸 HIGH-PRECISION SPECIES-SPECIFIC DUAL OSCILLATOR MODELING
    // =========================================================================
    if (lowerName.includes("cuckoo")) {
      // 1. Common Cuckoo: Warm double whistle "cuc-koo"
      // First Whistle
      const w1Start = now;
      const w1Dur = 0.18 * speedRatio;
      const oscA1 = createOsc("sine");
      const oscA2 = createOsc("triangle"); // Adds soft biomechanical timber
      const gainA = registerGain(ctx.createGain());

      oscA1.frequency.setValueAtTime(630 + pitchOffset * 0.5, w1Start);
      oscA2.frequency.setValueAtTime(630 + pitchOffset * 0.5 + 4, w1Start); // Beating effect

      gainA.gain.setValueAtTime(0, w1Start);
      gainA.gain.linearRampToValueAtTime(0.25, w1Start + 0.04);
      gainA.gain.exponentialRampToValueAtTime(0.001, w1Start + w1Dur);

      oscA1.connect(gainA);
      oscA2.connect(gainA);
      routeToOutput(gainA);

      oscA1.start(w1Start);
      oscA2.start(w1Start);
      oscA1.stop(w1Start + w1Dur);
      oscA2.stop(w1Start + w1Dur);

      // Breath puff
      playBreathNoise(w1Start, 0.07, 0.04, 600);

      // Second Whistle (Minor third interval lower)
      const w2Start = now + 0.30 * speedRatio;
      const w2Dur = 0.28 * speedRatio;
      const oscB1 = createOsc("sine");
      const oscB2 = createOsc("triangle");
      const gainB = registerGain(ctx.createGain());

      oscB1.frequency.setValueAtTime(490 + pitchOffset * 0.5, w2Start);
      oscB2.frequency.setValueAtTime(490 + pitchOffset * 0.5 + 3, w2Start);

      gainB.gain.setValueAtTime(0, w2Start);
      gainB.gain.linearRampToValueAtTime(0.20, w2Start + 0.05);
      gainB.gain.exponentialRampToValueAtTime(0.001, w2Start + w2Dur);

      oscB1.connect(gainB);
      oscB2.connect(gainB);
      routeToOutput(gainB);

      oscB1.start(w2Start);
      oscB2.start(w2Start);
      oscB1.stop(w2Start + w2Dur);
      oscB2.stop(w2Start + w2Dur);

      playBreathNoise(w2Start, 0.09, 0.03, 460);

    } else if (lowerName.includes("robin")) {
      // 2. European Robin: Melodious, ultra-energetic silvery stream of liquid tweets (Rapid pitch climbs & falls with vibrato)
      const parts = 14;
      let delay = 0.0;
      for (let i = 0; i < parts; i++) {
        const noteStart = now + delay;
        const noteDur = (0.05 + (Math.sin(i) * 0.03 + 0.04)) * speedRatio;
        delay += noteDur + 0.02 * speedRatio;

        const osc1 = createOsc("sine");
        const osc2 = createOsc("triangle");
        const gain = registerGain(ctx.createGain());

        // Dynamic Robin ranges (4000Hz to 6800Hz)
        const fStart = 4200 + ((i * 240) % 2200) + pitchOffset;
        const fEnd = fStart + (i % 2 === 0 ? 900 : -1100);

        osc1.frequency.setValueAtTime(fStart, noteStart);
        osc2.frequency.setValueAtTime(fStart * 1.01, noteStart);
        osc1.frequency.exponentialRampToValueAtTime(fEnd, noteStart + noteDur);
        osc2.frequency.exponentialRampToValueAtTime(fEnd * 1.01, noteStart + noteDur);

        // Intrinsic rapid voice vibration (LFO throat simulation)
        const throatLfo = ctx.createOscillator();
        const lfoGain = registerGain(ctx.createGain());
        throatLfo.frequency.setValueAtTime(28, noteStart); // Fast 28Hz organic throbbing
        lfoGain.gain.setValueAtTime(120, noteStart);

        throatLfo.connect(lfoGain);
        lfoGain.connect(osc1.frequency);
        lfoGain.connect(osc2.frequency);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc1.connect(gain);
        osc2.connect(gain);
        routeToOutput(gain);

        throatLfo.start(noteStart);
        osc1.start(noteStart);
        osc2.start(noteStart);
        throatLfo.stop(noteStart + noteDur);
        osc1.stop(noteStart + noteDur);
        osc2.stop(noteStart + noteDur);
      }

    } else if (lowerName.includes("great tit")) {
      // 3. Great Tit: Distinct rhythmic saw-sharpening "tee-cher, tee-cher"
      const repetitions = 4;
      for (let i = 0; i < repetitions; i++) {
        const cyl1Start = now + (i * 0.52) * speedRatio;
        const cyl1Dur = 0.14 * speedRatio;
        const cyl2Start = cyl1Start + 0.18 * speedRatio;
        const cyl2Dur = 0.18 * speedRatio;

        // "tee"
        const osc1a = createOsc("sine");
        const osc1b = createOsc("triangle");
        const gain1 = registerGain(ctx.createGain());
        osc1a.frequency.setValueAtTime(3200 + pitchOffset, cyl1Start);
        osc1b.frequency.setValueAtTime(3210 + pitchOffset, cyl1Start);
        gain1.gain.setValueAtTime(0, cyl1Start);
        gain1.gain.linearRampToValueAtTime(0.24, cyl1Start + 0.02);
        gain1.gain.exponentialRampToValueAtTime(0.001, cyl1Start + cyl1Dur);

        osc1a.connect(gain1);
        osc1b.connect(gain1);
        routeToOutput(gain1);
        osc1a.start(cyl1Start);
        osc1b.start(cyl1Start);
        osc1a.stop(cyl1Start + cyl1Dur);
        osc1b.stop(cyl1Start + cyl1Dur);

        // "cher"
        const osc2a = createOsc("sine");
        const osc2b = createOsc("triangle");
        const gain2 = registerGain(ctx.createGain());
        osc2a.frequency.setValueAtTime(2400 + pitchOffset, cyl2Start);
        osc2b.frequency.setValueAtTime(2405 + pitchOffset, cyl2Start);
        // Pitch drop in "cher"
        osc2a.frequency.exponentialRampToValueAtTime(2100 + pitchOffset, cyl2Start + cyl2Dur);
        osc2b.frequency.exponentialRampToValueAtTime(2103 + pitchOffset, cyl2Start + cyl2Dur);

        gain2.gain.setValueAtTime(0, cyl2Start);
        gain2.gain.linearRampToValueAtTime(0.20, cyl2Start + 0.03);
        gain2.gain.exponentialRampToValueAtTime(0.001, cyl2Start + cyl2Dur);

        osc2a.connect(gain2);
        osc2b.connect(gain2);
        routeToOutput(gain2);
        osc2a.start(cyl2Start);
        osc2b.start(cyl2Start);
        osc2a.stop(cyl2Start + cyl2Dur);
        osc2b.stop(cyl2Start + cyl2Dur);

        // Add soft breath resonance
        playBreathNoise(cyl2Start, cyl2Dur, 0.05, 2200);
      }

    } else if (lowerName.includes("blue tit")) {
      // 4. Eurasian Blue Tit: Trilling shivering sweep "tsee-tsee-tsip-tsirrrr"
      // Leading notes
      for (let i = 0; i < 3; i++) {
        const noteStart = now + (i * 0.12) * speedRatio;
        const noteDur = 0.07 * speedRatio;
        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());

        osc.frequency.setValueAtTime(5600 + (i * 200) + pitchOffset, noteStart);
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc.connect(gain);
        routeToOutput(gain);
        osc.start(noteStart);
        osc.stop(noteStart + noteDur);
      }

      // Fast shivering vibrational trill
      const trillStart = now + 0.40 * speedRatio;
      const trillDur = 0.60 * speedRatio;
      const trillSteps = 24;
      for (let i = 0; i < trillSteps; i++) {
        const clickStart = trillStart + (i * (trillDur / trillSteps));
        const clickDur = 0.022;

        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());

        // Step down pitch gradually during trill
        const clickFreq = (4800 - (i * 45)) + pitchOffset;
        osc.frequency.setValueAtTime(clickFreq, clickStart);

        gain.gain.setValueAtTime(0, clickStart);
        gain.gain.linearRampToValueAtTime(0.16, clickStart + 0.005);
        gain.gain.exponentialRampToValueAtTime(0.001, clickStart + clickDur);

        osc.connect(gain);
        routeToOutput(gain);
        osc.start(clickStart);
        osc.stop(clickStart + clickDur);
      }

    } else if (lowerName.includes("goldfinch")) {
      // 5. Goldfinch: Fast glistening, chaotic sweet songbook
      const notes = 16;
      let noteDelay = 0.0;
      for (let i = 0; i < notes; i++) {
        const noteStart = now + noteDelay;
        const noteDur = (0.06 + Math.random() * 0.06) * speedRatio;
        noteDelay += noteDur + 0.015 * speedRatio;

        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());
        
        // Glistening ascending jumps
        const noteFreq = 3800 + (Math.sin(i * 1.7) * 1600) + pitchOffset;
        osc.frequency.setValueAtTime(noteFreq, noteStart);
        osc.frequency.linearRampToValueAtTime(noteFreq + (i % 3 === 0 ? 500 : -400), noteStart + noteDur);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc.connect(gain);
        routeToOutput(gain);
        osc.start(noteStart);
        osc.stop(noteStart + noteDur);
      }

    } else if (lowerName.includes("bullfinch")) {
      // 6. Eurasian Bullfinch: Warm, melancholic, low piping whistles "deu-deu"
      const coos = 2;
      for (let i = 0; i < coos; i++) {
        const noteStart = now + (i * 0.65) * speedRatio;
        const noteDur = 0.32 * speedRatio;

        const osc1 = createOsc("sine");
        const osc2 = createOsc("triangle"); // soft warm overtones
        const gain = registerGain(ctx.createGain());

        const basePitch = 240 + pitchOffset * 0.2;
        osc1.frequency.setValueAtTime(basePitch, noteStart);
        osc2.frequency.setValueAtTime(basePitch, noteStart);
        // Tender falling bend at the end
        osc1.frequency.linearRampToValueAtTime(basePitch - 25, noteStart + noteDur);
        osc2.frequency.linearRampToValueAtTime(basePitch - 25, noteStart + noteDur);

        // Lowpass to make it perfectly soft and breathy
        const lp = ctx.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.setValueAtTime(380, noteStart);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.25, noteStart + 0.08); // Slow smooth attack
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc1.connect(lp);
        osc2.connect(lp);
        lp.connect(gain);
        routeToOutput(gain);

        osc1.start(noteStart);
        osc2.start(noteStart);
        osc1.stop(noteStart + noteDur);
        osc2.stop(noteStart + noteDur);

        playBreathNoise(noteStart, noteDur, 0.03, 300);
      }

    } else if (lowerName.includes("wren")) {
      // 7. Wren: Incredibly loud, long, machine-gunte trilling explosion ending in a sweeping rattle!
      const totalNotes = 32;
      let curDelay = 0.0;
      for (let i = 0; i < totalNotes; i++) {
        const noteStart = now + curDelay;
        // In the middle (i from 12 to 22), add the wren's signature hyper-rapid machine rattle!
        const isRattle = i >= 12 && i <= 22;
        const noteDur = (isRattle ? 0.024 : 0.055) * speedRatio;
        curDelay += noteDur + (isRattle ? 0.008 : 0.015) * speedRatio;

        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());

        const baseVal = isRattle ? 3900 : (4500 + Math.sin(i) * 1200);
        const pitch = baseVal + pitchOffset;
        osc.frequency.setValueAtTime(pitch, noteStart);
        if (!isRattle) {
          osc.frequency.linearRampToValueAtTime(pitch + 600, noteStart + noteDur);
        }

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.28, noteStart + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc.connect(gain);
        routeToOutput(gain);
        osc.start(noteStart);
        osc.stop(noteStart + noteDur);
      }

    } else if (lowerName.includes("owl")) {
      // 8. Owls: Complex vocal tract
      if (lowerName.includes("barn owl")) {
        // Barn Owl: Blood-curdling, long raspy ghostly screech of pure horror!
        const duration = 1.3 * speedRatio;
        playBreathNoise(now, duration, 0.42, 2200);

        // Add vibrating sawtooth carriers through peaking resonance to create the metallic scream
        const osc1 = createOsc("sawtooth");
        const osc2 = createOsc("sawtooth");
        const gain = registerGain(ctx.createGain());

        osc1.frequency.setValueAtTime(1400 + pitchOffset, now);
        osc2.frequency.setValueAtTime(1420 + pitchOffset, now);
        osc1.frequency.linearRampToValueAtTime(1700 + pitchOffset, now + duration * 0.7);
        osc2.frequency.linearRampToValueAtTime(1710 + pitchOffset, now + duration * 0.7);

        // Intense frequency flutter
        const screamLfo = ctx.createOscillator();
        const lfoGain = registerGain(ctx.createGain());
        screamLfo.frequency.setValueAtTime(55, now); // Raw metallic ring
        lfoGain.gain.setValueAtTime(400, now);
        screamLfo.connect(lfoGain);
        lfoGain.connect(osc1.frequency);
        lfoGain.connect(osc2.frequency);

        // Sweeping formant bandpass filter
        const formant = ctx.createBiquadFilter();
        formant.type = "bandpass";
        formant.frequency.setValueAtTime(2200, now);
        formant.frequency.linearRampToValueAtTime(3400, now + duration);
        formant.Q.setValueAtTime(2.2, now);

        osc1.connect(formant);
        osc2.connect(formant);
        formant.connect(gain);
        routeToOutput(gain);

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.18, now + 0.15);
        gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

        screamLfo.start(now);
        osc1.start(now);
        osc2.start(now);
        screamLfo.stop(now + duration);
        osc1.stop(now + duration);
        osc2.stop(now + duration);

      } else {
        // Tawny / Other Owls: Beautiful majestic "Twit Twoo"
        // 1. First fast "twit" sharp whistle
        const p1Start = now;
        const p1Dur = 0.16 * speedRatio;
        const oscP1 = createOsc("sine");
        const gainP1 = registerGain(ctx.createGain());
        oscP1.frequency.setValueAtTime(750 + pitchOffset * 0.3, p1Start);
        oscP1.frequency.exponentialRampToValueAtTime(1350 + pitchOffset * 0.3, p1Start + p1Dur);

        gainP1.gain.setValueAtTime(0, p1Start);
        gainP1.gain.linearRampToValueAtTime(0.20, p1Start + 0.03);
        gainP1.gain.exponentialRampToValueAtTime(0.001, p1Start + p1Dur);

        oscP1.connect(gainP1);
        routeToOutput(gainP1);
        oscP1.start(p1Start);
        oscP1.stop(p1Start + p1Dur);

        // 2. Main deep warbling Hooting sequence "Hooo... ho-ho-ho-hoooo"
        const hootStart = now + 1.2 * speedRatio;
        const hootCount = 5;
        const baseFreq = 310 + pitchOffset * 0.2;

        const lp = ctx.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.setValueAtTime(550, now);

        for (let i = 0; i < hootCount; i++) {
          const noteStart = hootStart + (i === 0 ? 0 : i === 1 ? 0.75 : 0.75 + i * 0.15) * speedRatio;
          const noteDur = (i === 0 ? 0.48 : i === 4 ? 0.52 : 0.08) * speedRatio;

          const oscA = createOsc("sine");
          const oscB = createOsc("triangle");
          const gainY = registerGain(ctx.createGain());

          oscA.frequency.setValueAtTime(baseFreq, noteStart);
          oscB.frequency.setValueAtTime(baseFreq + 2, noteStart);

          // Add a soft vocal warble/tremolo around 18Hz
          const vibrato = ctx.createOscillator();
          const vibGain = registerGain(ctx.createGain());
          vibrato.frequency.setValueAtTime(16, noteStart);
          vibGain.gain.setValueAtTime(14, noteStart);
          vibrato.connect(vibGain);
          vibGain.connect(oscA.frequency);
          vibGain.connect(oscB.frequency);

          gainY.gain.setValueAtTime(0, noteStart);
          gainY.gain.linearRampToValueAtTime(0.25, noteStart + noteDur * 0.25);
          gainY.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

          oscA.connect(lp);
          oscB.connect(lp);
          lp.connect(gainY);
          routeToOutput(gainY);

          vibrato.start(noteStart);
          oscA.start(noteStart);
          oscB.start(noteStart);
          vibrato.stop(noteStart + noteDur);
          oscA.stop(noteStart + noteDur);
          oscB.stop(noteStart + noteDur);
        }
      }

    } else if (lowerName.includes("woodpecker")) {
      // 9. Woodpecker Mechanical solid beak drum "R-r-r-r-taptaptap!"
      const taps = 16;
      const spacing = 0.038 * speedRatio;

      const drumFilter = ctx.createBiquadFilter();
      drumFilter.type = "bandpass";
      drumFilter.frequency.setValueAtTime(260, now); // Wooden hollow resonant cavity
      drumFilter.Q.setValueAtTime(4.5, now);
      drumFilter.connect(masterGain);

      for (let i = 0; i < taps; i++) {
        const tapStart = now + (i * spacing);
        const tapDur = 0.022;

        const osc = createOsc("triangle");
        const gain = registerGain(ctx.createGain());

        // Instant click frequency sweep representing bark impact
        osc.frequency.setValueAtTime(420 + pitchOffset * 0.3, tapStart);
        osc.frequency.linearRampToValueAtTime(80, tapStart + tapDur);

        // Sharp exponential decay mimicking mechanical impact
        gain.gain.setValueAtTime(0.45, tapStart);
        gain.gain.exponentialRampToValueAtTime(0.001, tapStart + tapDur);

        osc.connect(gain);
        gain.connect(drumFilter);
        
        osc.start(tapStart);
        osc.stop(tapStart + tapDur);

        // Soft physical wood noise burst
        playBreathNoise(tapStart, 0.015, 0.08, 300);
      }

    } else if (lowerName.includes("curlew")) {
      // 10. Curlew: Accelerating, rising bubbling whistles
      const notes = 16;
      let accDelay = 0.0;
      for (let i = 0; i < notes; i++) {
        const noteStart = now + accDelay;
        const noteDur = (0.22 - (i * 0.012)) * speedRatio;
        accDelay += noteDur * 0.82;

        const osc1 = createOsc("sine");
        const osc2 = createOsc("triangle");
        const gain = registerGain(ctx.createGain());

        const fStart = 1100 + (i * 150) + pitchOffset;
        const fEnd = fStart + 220;

        osc1.frequency.setValueAtTime(fStart, noteStart);
        osc2.frequency.setValueAtTime(fStart + 5, noteStart);
        osc1.frequency.exponentialRampToValueAtTime(fEnd, noteStart + noteDur);
        osc2.frequency.exponentialRampToValueAtTime(fEnd + 5, noteStart + noteDur);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.24, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc1.connect(gain);
        osc2.connect(gain);
        routeToOutput(gain);

        osc1.start(noteStart);
        osc2.start(noteStart);
        osc1.stop(noteStart + noteDur);
        osc2.stop(noteStart + noteDur);
      }

    } else if (lowerName.includes("nightjar")) {
      // 11. Nightjar: Wild mechanical dual-pitch spinning "churr" drone
      const churrs = 60;
      const interval = 0.022 * speedRatio;
      for (let i = 0; i < churrs; i++) {
        const tickStart = now + (i * interval);
        const tickDur = 0.016;

        const osc = createOsc("sawtooth");
        const gain = registerGain(ctx.createGain());

        // Alternate fundamental pitches representing the rapid mechanical gear shift of the nightjar
        const base = (i % 2 === 0 ? 560 : 610) + pitchOffset * 0.3;
        osc.frequency.setValueAtTime(base, tickStart);

        // Filter sweeps across ticks to mimic head turning/volume waving
        const sweepingLp = ctx.createBiquadFilter();
        sweepingLp.type = "lowpass";
        sweepingLp.frequency.setValueAtTime(800 + Math.sin(i / 6.0) * 300, tickStart);

        gain.gain.setValueAtTime(0.14, tickStart);
        gain.gain.exponentialRampToValueAtTime(0.001, tickStart + tickDur);

        osc.connect(sweepingLp);
        sweepingLp.connect(gain);
        routeToOutput(gain);

        osc.start(tickStart);
        osc.stop(tickStart + tickDur);
      }

    } else if (lowerName.includes("crow") || lowerName.includes("raven") || lowerName.includes("rook") || lowerName.includes("jackdaw")) {
      // 12. Corvids: Harsh, dry chesty dual-modulated biological "CAW, CAW"
      const cawsCount = 2;
      for (let i = 0; i < cawsCount; i++) {
        const cawStart = now + (i * 0.60) * speedRatio;
        const cawDur = 0.42 * speedRatio;

        const osc1 = createOsc("sawtooth");
        const osc2 = createOsc("square");
        const gain = registerGain(ctx.createGain());

        osc1.frequency.setValueAtTime(260 + pitchOffset * 0.3, cawStart);
        osc2.frequency.setValueAtTime(264 + pitchOffset * 0.3, cawStart);
        osc1.frequency.linearRampToValueAtTime(190 + pitchOffset * 0.1, cawStart + cawDur);
        osc2.frequency.linearRampToValueAtTime(192 + pitchOffset * 0.1, cawStart + cawDur);

        // Vocal chord physical flutter (rough beating vibrations)
        const rattle = ctx.createOscillator();
        const rattleGain = registerGain(ctx.createGain());
        rattle.frequency.setValueAtTime(50, cawStart); // 50Hz harshness
        rattleGain.gain.setValueAtTime(120, cawStart);
        rattle.connect(rattleGain);
        rattleGain.connect(osc1.frequency);
        rattleGain.connect(osc2.frequency);

        // Vocal formatting filters
        const bandFilter = ctx.createBiquadFilter();
        bandFilter.type = "bandpass";
        bandFilter.frequency.setValueAtTime(850, cawStart);
        bandFilter.Q.setValueAtTime(4.0, cawStart);

        osc1.connect(bandFilter);
        osc2.connect(bandFilter);
        bandFilter.connect(gain);
        routeToOutput(gain);

        gain.gain.setValueAtTime(0, cawStart);
        gain.gain.linearRampToValueAtTime(0.25, cawStart + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, cawStart + cawDur);

        rattle.start(cawStart);
        osc1.start(cawStart);
        osc2.start(cawStart);
        rattle.stop(cawStart + cawDur);
        osc1.stop(cawStart + cawDur);
        osc2.stop(cawStart + cawDur);

        // Heavy breath noise layer for chesty raw texture
        playBreathNoise(cawStart, cawDur, 0.12, 900);
      }

    } else if (lowerName.includes("mallard") || lowerName.includes("duck") || lowerName.includes("goose") || lowerName.includes("teal")) {
      // 13. Waterfowl: Nasal sliding hollow "Quack! quack!"
      const quacks = 2;
      for (let i = 0; i < quacks; i++) {
        const qStart = now + (i * 0.35) * speedRatio;
        const qDur = (i === 0 ? 0.22 : 0.16) * speedRatio;
        const qVolume = i === 0 ? 0.25 : 0.12;

        const osc1 = createOsc("sawtooth");
        const osc2 = createOsc("triangle");
        const gain = registerGain(ctx.createGain());

        osc1.frequency.setValueAtTime(290 + pitchOffset * 0.4, qStart);
        osc2.frequency.setValueAtTime(325 + pitchOffset * 0.4, qStart);
        osc1.frequency.exponentialRampToValueAtTime(160 + pitchOffset * 0.2, qStart + qDur);
        osc2.frequency.exponentialRampToValueAtTime(180 + pitchOffset * 0.2, qStart + qDur);

        // Bandpass to capture resonant nasal bill/beak formant cavity
        const billing = ctx.createBiquadFilter();
        billing.type = "bandpass";
        billing.frequency.setValueAtTime(950, qStart);
        billing.Q.setValueAtTime(3.8, qStart);

        osc1.connect(billing);
        osc2.connect(billing);
        billing.connect(gain);
        routeToOutput(gain);

        gain.gain.setValueAtTime(0, qStart);
        gain.gain.linearRampToValueAtTime(qVolume, qStart + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, qStart + qDur);

        osc1.start(qStart);
        osc2.start(qStart);
        osc1.stop(qStart + qDur);
        osc2.stop(qStart + qDur);

        playBreathNoise(qStart, qDur, 0.06, 950);
      }

    } else if (lowerName.includes("pigeon") || lowerName.includes("dove")) {
      // 14. Pigeons & Doves: Low rhythmic mechanical chest "Coo-cooo-coo, coo"
      const rhythm = [0.0, 0.32, 0.64, 1.05];
      const durations = [0.18, 0.28, 0.14, 0.24];
      const pitches = [190, 210, 185, 200];

      const lowFilter = ctx.createBiquadFilter();
      lowFilter.type = "lowpass";
      lowFilter.frequency.setValueAtTime(320, now);

      for (let i = 0; i < rhythm.length; i++) {
        const cooStart = now + rhythm[i] * speedRatio;
        const cooDur = durations[i] * speedRatio;

        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());

        const fBase = pitches[i] + pitchOffset * 0.2;
        osc.frequency.setValueAtTime(fBase, cooStart);
        osc.frequency.linearRampToValueAtTime(fBase + 12, cooStart + cooDur * 0.4);
        osc.frequency.linearRampToValueAtTime(fBase - 5, cooStart + cooDur);

        gain.gain.setValueAtTime(0, cooStart);
        gain.gain.linearRampToValueAtTime(0.24, cooStart + cooDur * 0.35); // Very soft romantic ramp
        gain.gain.exponentialRampToValueAtTime(0.001, cooStart + cooDur);

        osc.connect(lowFilter);
        lowFilter.connect(gain);
        routeToOutput(gain);

        osc.start(cooStart);
        osc.stop(cooStart + cooDur);

        playBreathNoise(cooStart, cooDur, 0.02, 220);
      }

    } else if (lowerName.includes("kingfisher")) {
      // 15. Kingfisher: Icy high piercing metallic whistle "Zitt, zitt!"
      const sparks = 3;
      for (let i = 0; i < sparks; i++) {
        const startT = now + (i * 0.15) * speedRatio;
        const dur = 0.08 * speedRatio;

        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());

        const baseSpk = 5400 + (i * 600) + pitchOffset;
        osc.frequency.setValueAtTime(baseSpk, startT);
        osc.frequency.exponentialRampToValueAtTime(baseSpk * 1.34, startT + dur);

        gain.gain.setValueAtTime(0, startT);
        gain.gain.linearRampToValueAtTime(0.12, startT + 0.012);
        gain.gain.exponentialRampToValueAtTime(0.001, startT + dur);

        osc.connect(gain);
        routeToOutput(gain);
        osc.start(startT);
        osc.stop(startT + dur);
      }

    } else if (lowerName.includes("grey heron") || lowerName.includes("bittern") || lowerName.includes("heron")) {
      // 16. Herons & Bitterns: Deep, terrifying, gravelly prehistoric swamp "FRAAANK!"
      const dur = 0.65 * speedRatio;
      const osc1 = createOsc("sawtooth");
      const osc2 = createOsc("square");
      const gain = registerGain(ctx.createGain());

      osc1.frequency.setValueAtTime(140 + pitchOffset * 0.2, now);
      osc2.frequency.setValueAtTime(144 + pitchOffset * 0.2, now);
      osc1.frequency.linearRampToValueAtTime(115, now + dur);

      const rattleLfo = ctx.createOscillator();
      const lfoGain = registerGain(ctx.createGain());
      rattleLfo.frequency.setValueAtTime(62, now);
      lfoGain.gain.setValueAtTime(90, now);
      rattleLfo.connect(lfoGain);
      lfoGain.connect(osc1.frequency);
      lfoGain.connect(osc2.frequency);

      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.setValueAtTime(750, now);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.32, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + dur);

      osc1.connect(lp);
      osc2.connect(lp);
      lp.connect(gain);
      routeToOutput(gain);

      rattleLfo.start(now);
      osc1.start(now);
      osc2.start(now);
      rattleLfo.stop(now + dur);
      osc1.stop(now + dur);
      osc2.stop(now + dur);

      playBreathNoise(now, dur, 0.22, 600);

    } else if (group === "Songbirds" || group === "Woodpeckers") {
      // 17. General Songbirds (Thrushes, Finches, Blackbirds): Fast high-pitched sweet cascades
      const duration = 1.6 * speedRatio;
      const notesCount = (seedVal % 5) + 6; // 6 to 10 notes
      const startFreq = 2900 + pitchOffset;

      for (let i = 0; i < notesCount; i++) {
        const noteStart = now + (i * 0.18 * speedRatio);
        const noteDur = (0.08 + (Math.sin(i) * 0.04)) * speedRatio;
        
        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());
        osc.connect(gain);
        routeToOutput(gain);

        // Sweeping frequency upwards/downwards
        const endFreq = startFreq + (i % 2 === 0 ? 1100 : -600) + (Math.sin(i) * 350);
        osc.frequency.setValueAtTime(startFreq, noteStart);
        osc.frequency.exponentialRampToValueAtTime(endFreq, noteStart + noteDur);

        // Apply fast vocal tract LFO
        const lfo = ctx.createOscillator();
        const lfoGain = registerGain(ctx.createGain());
        lfo.frequency.setValueAtTime(22 + (i * 1.5), noteStart);
        lfoGain.gain.setValueAtTime(90, noteStart);
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);

        // Sharp envelopes
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        lfo.start(noteStart);
        osc.start(noteStart);
        lfo.stop(noteStart + noteDur);
        osc.stop(noteStart + noteDur);
      }

      masterGain.gain.setValueAtTime(0.2, now + duration - 0.1);
      masterGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    } else if (group === "Raptors") {
      // 18. Raptors: Downward high screams with intense syrinx ring-vibration
      const duration = 0.85 * speedRatio;
      const osc = createOsc("sawtooth");
      const gain = registerGain(ctx.createGain());
      osc.connect(gain);
      routeToOutput(gain);

      const baseFreq = 1950 + pitchOffset * 15;
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.42, now + duration);

      // Amplitude Modulation
      const amOsc = ctx.createOscillator();
      const amGain = registerGain(ctx.createGain());
      amOsc.type = "sine";
      amOsc.frequency.setValueAtTime(36, now);
      amGain.gain.setValueAtTime(350, now);
      amOsc.connect(amGain);
      amGain.connect(osc.frequency);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.25, now + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      amOsc.start(now);
      osc.start(now);
      amOsc.stop(now + duration);
      osc.stop(now + duration);

      playBreathNoise(now, duration, 0.06, 1800);

    } else if (group === "Seabirds") {
      // 19. Seabirds: Rhythmic series of loud laughing "Kyow, kyow, kyow" cries
      const cries = 4;
      for (let i = 0; i < cries; i++) {
        const noteStart = now + (i * 0.32) * speedRatio;
        const noteDur = 0.22 * speedRatio;

        const osc = createOsc("sawtooth");
        const gain = registerGain(ctx.createGain());
        
        // Gull swooping curve
        osc.frequency.setValueAtTime(600 + pitchOffset, noteStart);
        osc.frequency.linearRampToValueAtTime(1200 + pitchOffset, noteStart + noteDur * 0.35);
        osc.frequency.exponentialRampToValueAtTime(500 + pitchOffset, noteStart + noteDur);

        // Soften digital harmonics
        const lp = ctx.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.setValueAtTime(2000, noteStart);
        
        osc.connect(lp);
        lp.connect(gain);
        routeToOutput(gain);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.20, noteStart + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc.start(noteStart);
        osc.stop(noteStart + noteDur);

        playBreathNoise(noteStart, noteDur, 0.05, 1200);
      }
    } else if (group === "Waterfowl") {
      // 19.5. General Waterfowl (Swans, Ducks, Geese fallback): Nasal resonant dual-modulated horn honks
      const honks = 2;
      for (let i = 0; i < honks; i++) {
        const noteStart = now + (i * 0.42) * speedRatio;
        const noteDur = 0.24 * speedRatio;

        const osc1 = createOsc("sawtooth");
        const osc2 = createOsc("triangle");
        const gain = registerGain(ctx.createGain());

        osc1.frequency.setValueAtTime(180 + pitchOffset, noteStart);
        osc2.frequency.setValueAtTime(210 + pitchOffset, noteStart);
        osc1.frequency.exponentialRampToValueAtTime(110 + pitchOffset, noteStart + noteDur);
        osc2.frequency.exponentialRampToValueAtTime(130 + pitchOffset, noteStart + noteDur);

        const bandpass = ctx.createBiquadFilter();
        bandpass.type = "bandpass";
        bandpass.frequency.setValueAtTime(950, noteStart);
        bandpass.Q.setValueAtTime(3.0, noteStart);

        osc1.connect(bandpass);
        osc2.connect(bandpass);
        bandpass.connect(gain);
        routeToOutput(gain);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc1.start(noteStart);
        osc2.start(noteStart);
        osc1.stop(noteStart + noteDur);
        osc2.stop(noteStart + noteDur);

        playBreathNoise(noteStart, noteDur, 0.08, 900);
      }
    } else if (group === "Pigeons & Game") {
      // 19.8. Pigeons & Game Birds (Pheasants, Doves, Grouse, Ptarmigan)
      const isGameBird = lowerName.includes("pheasant") || lowerName.includes("grouse") || lowerName.includes("ptarmigan") || lowerName.includes("capercaillie") || lowerName.includes("partridge") || lowerName.includes("quail");
      
      if (isGameBird) {
        // Raspy cackling game-bird croak / squawk (KOK-KOK!)
        const syllables = 2;
        for (let i = 0; i < syllables; i++) {
          const noteStart = now + (i * 0.35) * speedRatio;
          const noteDur = 0.22 * speedRatio;

          const osc1 = createOsc("sawtooth");
          const osc2 = createOsc("square");
          const gain = registerGain(ctx.createGain());

          osc1.frequency.setValueAtTime(320 + pitchOffset * 0.4, noteStart);
          osc2.frequency.setValueAtTime(325 + pitchOffset * 0.4, noteStart);
          
          osc1.frequency.linearRampToValueAtTime(450, noteStart + noteDur * 0.4);
          osc1.frequency.exponentialRampToValueAtTime(280, noteStart + noteDur);

          const throatLfo = ctx.createOscillator();
          const lfoGain = registerGain(ctx.createGain());
          throatLfo.frequency.setValueAtTime(45, noteStart);
          lfoGain.gain.setValueAtTime(80, noteStart);
          throatLfo.connect(lfoGain);
          lfoGain.connect(osc1.frequency);
          lfoGain.connect(osc2.frequency);

          const lp = ctx.createBiquadFilter();
          lp.type = "lowpass";
          lp.frequency.setValueAtTime(1400, noteStart);

          gain.gain.setValueAtTime(0, noteStart);
          gain.gain.linearRampToValueAtTime(0.28, noteStart + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

          osc1.connect(lp);
          osc2.connect(lp);
          lp.connect(gain);
          routeToOutput(gain);

          throatLfo.start(noteStart);
          osc1.start(noteStart);
          osc2.start(noteStart);
          throatLfo.stop(noteStart + noteDur);
          osc1.stop(noteStart + noteDur);
          osc2.stop(noteStart + noteDur);

          playBreathNoise(noteStart, noteDur, 0.15, 1200);
        }
      } else {
        // Doves / Pigeons: Soft, warm, rhythmic pulsing coo "coo-coo-coo-coo"
        const notes = 4;
        const pattern = [0, 0.28, 0.60, 0.95];
        const durations = [0.24, 0.32, 0.20, 0.26];
        const frequencies = [280, 310, 260, 240];
        
        for (let i = 0; i < notes; i++) {
          const noteStart = now + pattern[i] * speedRatio;
          const noteDur = durations[i] * speedRatio;

          const osc = createOsc("sine");
          const gain = registerGain(ctx.createGain());

          osc.frequency.setValueAtTime(frequencies[i] + pitchOffset * 0.15, noteStart);
          const lp = ctx.createBiquadFilter();
          lp.type = "lowpass";
          lp.frequency.setValueAtTime(380, noteStart);

          gain.gain.setValueAtTime(0, noteStart);
          gain.gain.linearRampToValueAtTime(0.25, noteStart + 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

          osc.connect(lp);
          lp.connect(gain);
          routeToOutput(gain);

          osc.start(noteStart);
          osc.stop(noteStart + noteDur);

          playBreathNoise(noteStart, noteDur, 0.04, 320);
        }
      }
    } else if (group === "Waders") {
      // 20. Shorebirds & Waders (Piping Whistles)
      const bleeps = 5;
      for (let i = 0; i < bleeps; i++) {
        const noteStart = now + (i * 0.18) * speedRatio;
        const noteDur = 0.10 * speedRatio;

        const osc = createOsc("sine");
        const gain = registerGain(ctx.createGain());
        osc.frequency.setValueAtTime(1700 + (i * 140) + pitchOffset, noteStart);
        osc.frequency.exponentialRampToValueAtTime(2200 + (i * 140) + pitchOffset, noteStart + noteDur);

        osc.connect(gain);
        routeToOutput(gain);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.18, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDur);

        osc.start(noteStart);
        osc.stop(noteStart + noteDur);
      }
    } else {
      // 21. Universal Fallback: A beautiful, sweet double birdsong tweet
      const tweet1Start = now;
      const tweet1Dur = 0.14 * speedRatio;
      const osc1 = createOsc("sine");
      const gain1 = registerGain(ctx.createGain());
      osc1.frequency.setValueAtTime(3200 + pitchOffset, tweet1Start);
      osc1.frequency.exponentialRampToValueAtTime(4200 + pitchOffset, tweet1Start + tweet1Dur);
      gain1.gain.setValueAtTime(0, tweet1Start);
      gain1.gain.linearRampToValueAtTime(0.18, tweet1Start + 0.02);
      gain1.gain.exponentialRampToValueAtTime(0.001, tweet1Start + tweet1Dur);
      osc1.connect(gain1);
      routeToOutput(gain1);
      osc1.start(tweet1Start);
      osc1.stop(tweet1Start + tweet1Dur);

      const tweet2Start = now + 0.22 * speedRatio;
      const tweet2Dur = 0.18 * speedRatio;
      const osc2 = createOsc("sine");
      const gain2 = registerGain(ctx.createGain());
      osc2.frequency.setValueAtTime(3600 + pitchOffset, tweet2Start);
      osc2.frequency.exponentialRampToValueAtTime(4800 + pitchOffset, tweet2Start + tweet2Dur);
      gain2.gain.setValueAtTime(0, tweet2Start);
      gain2.gain.linearRampToValueAtTime(0.18, tweet2Start + 0.02);
      gain2.gain.exponentialRampToValueAtTime(0.001, tweet2Start + tweet2Dur);
      osc2.connect(gain2);
      routeToOutput(gain2);
      osc2.start(tweet2Start);
      osc2.stop(tweet2Start + tweet2Dur);
    }
  } catch (err) {
    console.warn("Web Audio API not fully initialized or blocked by browser gesture:", err);
  }
  });
}

/**
 * Procedural synthesized UI audio effects!
 */
export function playUiClick() {
  withRunningContext((ctx) => {
    try {
      const now = ctx.currentTime;
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(200, now + 0.08);
      
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.linearRampToValueAtTime(0.001, now + 0.08);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      if (analyserNode) {
        gain.connect(analyserNode);
      }
      
      osc.start(now);
      osc.stop(now + 0.08);
    } catch (e) {}
  });
}

export function playUiAward() {
  withRunningContext((ctx) => {
    try {
      const now = ctx.currentTime;
      
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(523.25, now); // C5
      osc1.frequency.setValueAtTime(659.25, now + 0.08); // E5
      osc1.frequency.setValueAtTime(783.99, now + 0.16); // G5
      osc1.frequency.setValueAtTime(1046.50, now + 0.24); // C6
      
      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(261.63, now); // C4
      osc2.frequency.setValueAtTime(329.63, now + 0.16); // E4

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.15, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      if (analyserNode) {
        gain.connect(analyserNode);
      }
      
      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.45);
      osc2.stop(now + 0.45);
    } catch (e) {}
  });
}

/**
 * Plays background ambient forest sounds (leaves blowing, gentle breeze, and accidental distant tweets!)
 */
export function startAmbientForest() {
  if (forestNode) return; // Already running

  withRunningContext((ctx) => {
    if (forestNode) return; // Guard in case of fast double-clicks

    try {
      const now = ctx.currentTime;

      // 1. Synthesize background wind using filtered white noise
      const bufferSize = ctx.sampleRate * 2; // 2 seconds of noise buffer
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = buffer;
      noiseSource.loop = true;

      // Filter to resemble wind: slow modulation of cutoff frequency
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(450, now);
      filter.Q.setValueAtTime(1, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.06, now + 2); // Soft but clearly audible ambient level

      noiseSource.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      if (analyserNode) {
        gain.connect(analyserNode);
      }

      noiseSource.start();
      forestNode = gain as any;

      // Wind modulation LFO loop
      let lastModTime = now;
      const interval = setInterval(() => {
        try {
          const loopCtx = getAudioContext();
          filter.frequency.linearRampToValueAtTime(300 + Math.random() * 350, loopCtx.currentTime + 1.5);
        } catch (e) {}
      }, 2000);

      // Occasional sweet distant wild birds calling on intervals
      forestTimer = setInterval(() => {
        try {
          const groups = ["Songbirds", "Waders", "Raptors"];
          const chosen = groups[Math.floor(Math.random() * groups.length)];
          // Play very quiet distant call (does not clear or interrupt active user sounds!)
          playBirdSong(chosen, "Distant Wild call " + Math.random(), true);
        } catch (e) {}
      }, 12000);

      // Keep reference to cleanup interval
      (forestNode as any).noiseSource = noiseSource;
      (forestNode as any).modulationInterval = interval;

    } catch (err) {
      console.warn("Failed to activate background ecosystem synthesizer:", err);
    }
  });
}

export function stopAmbientForest() {
  if (forestNode) {
    try {
      const node = forestNode as any;
      if (node.noiseSource) {
        node.noiseSource.stop();
      }
      if (node.modulationInterval) {
        clearInterval(node.modulationInterval);
      }
      clearInterval(forestTimer);
    } catch(e) {}
    forestNode = null;
    forestTimer = null;
  }
}
