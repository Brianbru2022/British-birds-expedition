import { Player } from "../types";

export interface SightingRecord {
  birdId: string;
  spottedBy: string;
  date: string;
}

export interface ExpeditionScore {
  id: string;
  winner: string;
  winnerScore: number;
  players: { name: string; score: number }[];
  date: string;
}

const STORAGE_KEY_SIGHTINGS = "royal_avian_sightings_v1";
const STORAGE_KEY_LEADERBOARD = "royal_avian_leaderboard_v1";

export function getSightedBirds(): Record<string, SightingRecord> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SIGHTINGS);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

export function unlockBird(birdId: string, playerName: string): void {
  try {
    const sightings = getSightedBirds();
    if (!sightings[birdId]) {
      sightings[birdId] = {
        birdId,
        spottedBy: playerName,
        date: new Date().toLocaleDateString("en-GB", {
          day: "numeric",
          month: "short",
          year: "numeric",
        }),
      };
      localStorage.setItem(STORAGE_KEY_SIGHTINGS, JSON.stringify(sightings));
    }
  } catch (e) {
    console.error("Failed to unlock bird sighting:", e);
  }
}

export function getHighScores(): ExpeditionScore[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_LEADERBOARD);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

export function saveExpedition(players: Player[]): void {
  try {
    const sorted = [...players].sort((a, b) => b.score - a.score);
    const winner = sorted[0];
    if (!winner) return;

    const scores = getHighScores();
    const newRecord: ExpeditionScore = {
      id: Math.random().toString(36).substring(2, 9),
      winner: winner.name,
      winnerScore: winner.score,
      players: sorted.map((p) => ({ name: p.name, score: p.score })),
      date: new Date().toLocaleDateString("en-GB", {
        day: "numeric",
        month: "short",
        year: "numeric",
      }),
    };

    scores.push(newRecord);
    // Keep top 10 scores
    scores.sort((a, b) => b.winnerScore - a.winnerScore);
    localStorage.setItem(STORAGE_KEY_LEADERBOARD, JSON.stringify(scores.slice(0, 10)));
  } catch (e) {
    console.error("Failed to save expedition results:", e);
  }
}
