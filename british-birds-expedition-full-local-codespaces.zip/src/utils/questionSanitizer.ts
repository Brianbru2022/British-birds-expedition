import { BirdCard } from "../types";

/**
 * Clean up visual appearance cues and obvious identity markers from a bird's fun fact 
 * so it can function as a high-quality, non-cheatable trivia riddle in active gameplay.
 */
export function getSanitizedQuestionPrompt(bird: BirdCard): string {
  let text = bird.funFact || "";

  // 1. Strip sentences that describe physical visual attributes (color, markings, etc.).
  // These are too easy to cheat on since the bird cards display the visual drawings.
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  const visualNouns = [
    "breast", "chest", "cap", "crown", "beak", "bill", "plumage", "feather", "feathers",
    "wing", "wings", "tail", "belly", "throat", "eyestripe", "cheek", "cheeks", "stripe", "stripes",
    "markings", "plumage", "look", "collar", "patch", "eyepatch", "scales"
  ];
  
  const visualAdjectives = [
    "red", "blue", "yellow", "green", "black", "white", "grey", "gray", "brown", "orange",
    "pink", "crimson", "golden", "silver", "colorful", "bright", "vibrant", "dark-capped",
    "spotted", "spot", "bars", "barred", "barred", "buffy", "rufous", "pale"
  ];

  const filteredSentences = sentences.filter((sentence) => {
    const cleanLower = sentence.toLowerCase();
    
    // Check if sentence lists a color together with a body part/visual marker
    let hasVisualNoun = visualNouns.some(word => cleanLower.includes(word));
    let hasVisualAdjective = visualAdjectives.some(word => cleanLower.includes(word));
    
    // If it has both a body part and a pattern/color, skip it
    if (hasVisualNoun && hasVisualAdjective) {
      return false;
    }
    
    // Also skip sentences explicitly mentioning physical appearance patterns
    if (cleanLower.includes("black cap") || cleanLower.includes("red breast") || cleanLower.includes("white tail") || cleanLower.includes("yellow breast")) {
      return false;
    }
    
    return true;
  });

  // Re-assemble filtered sentences, or fall back to the original if filtering emptied it
  text = filteredSentences.length > 0 ? filteredSentences.join(" ") : text;

  // 2. Eradicate all instances of the bird's own name (common or scientific)
  const nameParts = bird.name.toLowerCase().split(/\s+/);
  const scientificParts = bird.scientificName.toLowerCase().split(/\s+/);

  // Filter out terms that are too generic and common to replace safely (avoiding breaking grammar)
  const stopWords = new Set([
    "common", "eurasian", "european", "british", "northern", "great", "little", "grey", "gray",
    "green", "red", "black", "gold", "golden", "under", "over", "of", "the", "and", "in", "with"
  ]);

  const specificTermsToMask = new Set<string>();

  // Use the full name as a whole phrase, and also plural/possessive forms
  const fullLower = bird.name.toLowerCase();
  specificTermsToMask.add(fullLower);
  specificTermsToMask.add(fullLower + "s");
  specificTermsToMask.add(fullLower + "es");
  specificTermsToMask.add(fullLower + "'s");

  // Also collect individual specific name words to search & replace
  nameParts.forEach(part => {
    if (part.length > 2 && !stopWords.has(part)) {
      specificTermsToMask.add(part);
      specificTermsToMask.add(part + "s");
      specificTermsToMask.add(part + "es");
      specificTermsToMask.add(part + "'s");
    }
  });

  // Also include scientific name parts
  scientificParts.forEach(part => {
    if (part.length > 2 && !stopWords.has(part)) {
      specificTermsToMask.add(part);
    }
  });

  // Order by length descending so longer phrases get replaced first
  const sortedMasks = Array.from(specificTermsToMask).sort((a, b) => b.length - a.length);

  for (const mask of sortedMasks) {
    const rx = new RegExp(`\\b${escapeRegExp(mask)}\\b`, "gi");
    text = text.replace(rx, "this bird");
  }

  // 3. Robust "Night Bird clue protection" - Avoid giving away birds starting/containing "Night" (e.g. Nightjar, Nightingale)
  // if the description contains words like "night", "nocturnal", "nighttime"
  const hasNightInName = bird.name.toLowerCase().includes("night");
  if (hasNightInName) {
    const nightTerms = ["nighttime", "night-hunting", "nighttime", "nightly", "nocturnal"];
    for (const term of nightTerms) {
      const rx = new RegExp(`\\b${escapeRegExp(term)}\\b`, "gi");
      text = text.replace(rx, "evening");
    }
    // Also change "night" to "dusk" or "dark" so there is no exact word match
    text = text.replace(/\bnight\b/gi, "dark hours");
  }

  // Final polishing to prevent double "this bird" clustering and uppercase beginning sentences
  text = text.replace(/\bthis bird this bird\b/gi, "this species");
  text = text.replace(/\bthis bird's this bird\b/gi, "its");
  
  // Make sure first letter is capitalized
  if (text.length > 0) {
    text = text.charAt(0).toUpperCase() + text.slice(1);
  }

  return text;
}

function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
