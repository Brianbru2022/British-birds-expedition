import { useState } from "react";
import { GameState, Player, PlayerGear, ActionCard } from "./types";
import { BIRD_DATASET } from "./data/birds";
import { ROUNDS_SET } from "./data/rounds";
import GameIntro from "./components/GameIntro";
import PlayerSetup from "./components/PlayerSetup";
import Scoreboard from "./components/Scoreboard";
import RoundScreen from "./components/RoundScreen";
import GameOver from "./components/GameOver";
import ExpeditionHub from "./components/ExpeditionHub";
import { ForestLeafIcon } from "./components/BirdIcons";
import { Volume2, VolumeX } from "lucide-react";
import { startAmbientForest, stopAmbientForest } from "./utils/audio";
import { saveExpedition } from "./utils/journal";
import ForestAmbientBackground from "./components/ForestAmbientBackground";
// @ts-ignore
import mistyForestBg from "./assets/images/misty_forest_bg_1780291918608.png";

export default function App() {
  const [ambientOn, setAmbientOn] = useState<boolean>(false);
  const [gameState, setGameState] = useState<GameState>({
    phase: "intro",
    players: [],
    activePlayerIndex: 0,
    currentRound: 1,
    roundScores: {},
    deck: BIRD_DATASET,
    usedBirdIds: [],
  });

  const handleToggleAmbient = () => {
    if (ambientOn) {
      stopAmbientForest();
      setAmbientOn(false);
    } else {
      startAmbientForest();
      setAmbientOn(true);
    }
  };

  const handleStartSetup = () => {
    setGameState((prev) => ({
      ...prev,
      phase: "setup",
    }));
  };

  const handleSetupComplete = (registeredPlayers: Player[]) => {
    setGameState((prev) => ({
      ...prev,
      phase: "gameplay",
      players: registeredPlayers,
      currentRound: 1,
    }));
  };

  const handleRoundComplete = (
    scoresGained: Record<string, number>,
    finalGearCharges?: Record<string, { binoculars: number; sonic: number; thermal: number }>,
    finalCardsInHand?: Record<string, ActionCard[]>,
    finalBirdsCollected?: Record<string, string[]>,
    streakProtected?: Record<string, boolean>
  ) => {
    const scoresArray = Object.values(scoresGained);
    const roundMax = scoresArray.length > 0 ? Math.max(...scoresArray) : 0;

    // Add round scores to players' cumulative records with Streak Combo multipliers
    const updatedPlayers = gameState.players.map((p) => {
      const added = scoresGained[p.id] || 0;
      
      let nextStreak = p.streak || 0;
      let streakBonus = 0;

      // A player gets a streak if they hit positive points this round
      if (added > 0) {
        nextStreak += 1;
        if (nextStreak === 2) {
          streakBonus = 3;
        } else if (nextStreak === 3) {
          streakBonus = 6;
        } else if (nextStreak >= 4) {
          streakBonus = 10;
        }
      } else {
        const isProtected = streakProtected?.[p.id];
        if (!isProtected) {
          nextStreak = 0; // Broken!
        }
      }

      const totalRoundGains = added + streakBonus;
      const bestStreakVal = Math.max(p.stats.bestStreak || 0, nextStreak);

      const playerGearRef = finalGearCharges?.[p.id];
      const mergedGear = playerGearRef && p.gear ? {
        ...p.gear,
        binoculars: playerGearRef.binoculars,
        sonic: playerGearRef.sonic,
        thermal: playerGearRef.thermal,
      } : p.gear;

      const mergedCards = finalCardsInHand?.[p.id] !== undefined ? finalCardsInHand[p.id] : p.cardsInHand;
      const roundBirds = finalBirdsCollected?.[p.id] || [];
      const updatedBirdsCollected = [...p.stats.birdsCollected, ...roundBirds];

      return {
        ...p,
        score: p.score + totalRoundGains,
        streak: nextStreak,
        gear: mergedGear,
        cardsInHand: mergedCards,
        stats: {
          ...p.stats,
          bestStreak: bestStreakVal,
          birdsCollected: updatedBirdsCollected,
          roundsWon: p.stats.roundsWon + (added === roundMax && added > 0 ? 1 : 0),
        },
      };
    });

    if (gameState.currentRound >= ROUNDS_SET.length) {
      // End game! Show final standings with podium honors
      saveExpedition(updatedPlayers);
      setGameState((prev) => ({
        ...prev,
        phase: "gameOver",
        players: updatedPlayers,
      }));
    } else {
      // Transition to Expedition Base Camp Hub to buy gear and select bioregional targets
      setGameState((prev) => ({
        ...prev,
        phase: "expeditionHub",
        players: updatedPlayers,
      }));
    }
  };

  const handleRestartGame = () => {
    setGameState({
      phase: "intro",
      players: [],
      activePlayerIndex: 0,
      currentRound: 1,
      roundScores: {},
      deck: BIRD_DATASET,
      usedBirdIds: [],
    });
  };

  const handleBuyGear = (playerId: string, itemKey: keyof PlayerGear, cost: number) => {
    setGameState((prev) => {
      const updatedPlayers = prev.players.map((p) => {
        if (p.id !== playerId) return p;
        
        const currentCharges = p.gear?.[itemKey] || 0;
        const currentScore = p.score;
        
        return {
          ...p,
          score: Math.max(0, currentScore - cost),
          gear: p.gear ? {
            ...p.gear,
            [itemKey]: currentCharges + 1
          } : {
            binoculars: 0,
            sonic: 0,
            thermal: 0,
            lures: 0,
            shields: 0,
            [itemKey]: 1
          }
        };
      });
      
      return {
        ...prev,
        players: updatedPlayers
      };
    });
  };

  const handleResumeExpedition = (chosenDestination: {
    name: string;
    modifierKey: string;
    modifierRule: string;
    themeName: string;
    description: string;
  }) => {
    setGameState((prev) => ({
      ...prev,
      phase: "gameplay",
      currentRound: prev.currentRound + 1,
      activeModifierKey: chosenDestination.modifierKey,
      activeModifierRule: chosenDestination.modifierRule,
      activeDestinationName: chosenDestination.name,
    }));
  };

  const activeRoundInfo = ROUNDS_SET[gameState.currentRound - 1];

  return (
    <div
      className="min-h-screen font-sans text-white flex flex-col relative overflow-x-hidden select-none bg-stone-950"
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(6, 44, 30, 0.94), rgba(12, 19, 16, 0.98)), url(${mistyForestBg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Interactive, procedural ambient natural leaf & spore particle effect layer */}
      <ForestAmbientBackground />

      {/* Vibrant Palette Radial Dot Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.06] pointer-events-none" 
        style={{ 
          backgroundImage: "radial-gradient(#ffffff 1px, transparent 1px)", 
          backgroundSize: "24px 24px" 
        }}
      />

      {/* Decorative Blur Spots / Glowing Spores in Custom Warm Palette Colors */}
      <div className="absolute top-10 left-10 w-44 h-44 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-emerald-400/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none animate-pulse duration-[8s]" />

      {/* Floating Procedural Forest Soundscape Toggle */}
      <button
        onClick={handleToggleAmbient}
        className="fixed top-4 right-4 bg-emerald-950/95 border-2 border-emerald-700 hover:bg-emerald-900 text-amber-400 hover:text-amber-300 px-3 py-1.5 rounded-full z-[100] text-xs font-mono font-bold flex items-center gap-1.5 shadow-xl active:scale-95 transition-all cursor-pointer"
        title="Toggle procedural forest ecosystem soundscape"
      >
        {ambientOn ? <Volume2 size={13} className="text-amber-400 animate-bounce" /> : <VolumeX size={13} />}
        <span className="hidden sm:inline">
          {ambientOn ? "AMBIENCE: ACTIVE" : "AMBIENCE: MUTED"}
        </span>
      </button>

      {/* Outer game screen bezel board frame */}
      <div className="flex-1 flex flex-col p-4 md:p-6 lg:p-8 z-10 w-full max-w-[1280px] mx-auto gap-6 justify-center">
        
        {/* Core Header Banner containing Active scorecard */}
        {gameState.phase === "gameplay" && gameState.players.length > 0 && (
          <div className="animate-fade-in">
            <Scoreboard
              players={gameState.players}
              currentRound={gameState.currentRound}
              totalRounds={ROUNDS_SET.length}
            />
          </div>
        )}

        {/* --- DYNAMIC STACK VIEW CONTROLLER --- */}
        <main className="flex-1 flex flex-col justify-center">
          {gameState.phase === "intro" && (
            <div className="animate-fade-in-up">
              <GameIntro onStart={handleStartSetup} />
            </div>
          )}

          {gameState.phase === "setup" && (
            <div className="animate-fade-in-up">
              <PlayerSetup onComplete={handleSetupComplete} />
            </div>
          )}

          {gameState.phase === "gameplay" && activeRoundInfo && (
            <div className="w-full">
              <RoundScreen
                round={activeRoundInfo}
                players={gameState.players}
                deck={gameState.deck}
                onRoundComplete={handleRoundComplete}
                activeModifierKey={gameState.activeModifierKey}
                activeModifierRule={gameState.activeModifierRule}
                activeDestinationName={gameState.activeDestinationName}
              />
            </div>
          )}

          {gameState.phase === "expeditionHub" && (
            <div className="w-full">
              <ExpeditionHub
                players={gameState.players}
                currentRound={gameState.currentRound}
                totalRounds={ROUNDS_SET.length}
                onBuyGear={handleBuyGear}
                onResumeExpedition={handleResumeExpedition}
              />
            </div>
          )}

          {gameState.phase === "gameOver" && (
            <div className="animate-fade-in-up">
              <GameOver players={gameState.players} onRestart={handleRestartGame} />
            </div>
          )}
        </main>

        {/* Decorative Nature Footnote line */}
        <footer className="w-full text-center text-stone-600 text-[10px] font-mono uppercase tracking-widest flex items-center justify-center gap-1.5 mt-4">
          <ForestLeafIcon size={12} className="text-amber-600/50" />
          <span>British Field Ornithology Guild ✦ pass-and-play match-play ✦ {BIRD_DATASET.length} wild species</span>
        </footer>
      </div>
    </div>
  );
}
