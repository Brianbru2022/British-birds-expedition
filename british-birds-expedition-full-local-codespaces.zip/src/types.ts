export type BirdGroup = 
  | "Songbirds" 
  | "Raptors" 
  | "Waterfowl" 
  | "Waders" 
  | "Seabirds" 
  | "Woodpeckers" 
  | "Pigeons & Game";

export type RarityLevel = 1 | 2 | 3 | 4 | 5; // 1 = Common, 5 = Extremely Rare

export type ConservationStatus = "Green" | "Amber" | "Red";

export type MigratoryStatus = "Resident" | "Summer Visitor" | "Winter Visitor" | "Passage Migrant";

export type PrimaryDiet = "Insects" | "Seeds" | "Fish" | "Mammals" | "Omnivore";

export type HabitatType = "Gardens" | "Woodlands" | "Coasts" | "Wetlands" | "Moorlands" | "Farmland";

export interface BirdCard {
  id: string;
  name: string;
  scientificName: string;
  group: BirdGroup;
  rarity: RarityLevel;
  wingspanAvg: number; // in cm
  lengthAvg: number; // in cm
  weightAvg: number; // in grams
  clutchAvg: number; // egg count
  conservationStatus: ConservationStatus;
  migratoryStatus: MigratoryStatus;
  primaryDiet: PrimaryDiet;
  habitat: HabitatType;
  funFact: string;
  color: string; // Tailwind hex color or color class
}

export type PlayerGender = "Male" | "Female" | "Diverse";

export interface PlayerGear {
  binoculars: number;
  sonic: number;
  thermal: number;
  lures: number;
  shields: number;
}

export interface ActionCard {
  id: string;
  name: string;
  description: string;
  icon: string;
  colorClass: string;
  actionType: "reveal_family" | "double_points" | "protect_streak" | "remove_wrong" | "swap_options" | "gain_binoculars";
}

export interface Player {
  id: string;
  name: string;
  gender: PlayerGender;
  avatarSeed: number; // To generate unique styling / colors
  avatarUrl?: string; // AI generated CGI character photo url
  realName?: string; // Actual name of the user
  cgiProfile?: string; // AI generated CGI character profile description/bio
  score: number;
  streak?: number;
  gear?: PlayerGear;
  cardsInHand?: ActionCard[];
  stats: {
    roundsWon: number;
    birdsCollected: string[];
    correctAnswers: number;
    totalAnswers: number;
    bestStreak?: number;
  };
}

export interface RoundInfo {
  number: number;
  title: string;
  theme: string;
  description: string;
  rules: string;
  style: 
    | "SINGLE_CHOICE"      // Solo quiz: choose 1 correct name
    | "DRAFT_WEIGHT"       // Two/more players take turns drafting birds, highest weight wins
    | "SORT_WINGSPAN"      // Personal task: sort 4 birds from largest to smallest wingspan
    | "ODD_ONE_OUT"       // Spot the odd out (e.g., only Seabird in wood dwellers or highest rarity)
    | "TRUE_FALSE"         // Quick True/False regarding conservation / traits
    | "DRAFT_LIGHTEST"     // Draft birds, lowest weight wins
    | "DIET_CLAIM"         // Category claim: match correct bird to diets (taking turns)
    | "MIGRATION_QUEST"    // Identify correct migrant bird
    | "DRAFT_CLUTCH"       // Draft birds, highest egg count wins
    | "HABITAT_CLAIM"      // Match bird cards to specified habitats (taking turns)
    | "LATIN_MATCH"        // Speed Latin translation match
    | "GRID_SEARCH"        // Timed grid search: pair up matching categories
    | "RAPTOR_TRUMP"       // Trump battle: Pick a stat to beat opponent's bird
    | "TRIVIA_MULTI"       // Multi-select quiz round
    | "SONIC_IDENTIFY"     // Ear Training: Listen to synthesized song and choose bird
    | "CALL_CHALLENGE"     // Onomatopoeia: Match phonetic described vocalization to bird
    | "SORT_WEIGHT"        // Personal sorting: heaviest to lightest body weight
    | "GROUP_MATCH"        // Taxonomic Match: drag/match birds to correct groups
    | "GRAND_FINALE";      // Combined scale scoring evaluation
}

export interface GameState {
  phase: "intro" | "setup" | "roundStart" | "gameplay" | "roundResult" | "gameOver" | "expeditionHub";
  players: Player[];
  activePlayerIndex: number; // Player whose turn it is
  currentRound: number; // 1 to 20 (dynamic ROUNDS_SET.length)
  roundScores: Record<string, number>; // Scores gathered in the current round
  deck: BirdCard[];
  usedBirdIds: string[];
  activeModifierKey?: string;
  activeModifierRule?: string;
  activeDestinationName?: string;
}
