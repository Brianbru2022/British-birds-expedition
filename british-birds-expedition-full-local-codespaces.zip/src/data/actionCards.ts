import { ActionCard } from "../types";

export const ACTION_DECK: Omit<ActionCard, "id">[] = [
  {
    name: "Scout's Field Eyes",
    description: "Eliminates 1 incorrect option card from your current question pool.",
    icon: "🧭",
    colorClass: "from-amber-500/10 to-amber-600/20 border-amber-500/40 text-amber-400 hover:bg-amber-500/20",
    actionType: "remove_wrong"
  },
  {
    name: "Nesting Treasure",
    description: "Doubles the score points of your next correct answer in this round.",
    icon: "💎",
    colorClass: "from-cyan-500/10 to-cyan-600/20 border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/20",
    actionType: "double_points"
  },
  {
    name: "Golden Plume Guard",
    description: "Protects your streak from resetting if you guess incorrectly this turn.",
    icon: "🛡️",
    colorClass: "from-emerald-500/10 to-emerald-600/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/20",
    actionType: "protect_streak"
  },
  {
    name: "Acoustic Bio-Echo",
    description: "Reveals the target bird's taxonomic group/family at the top of the interface.",
    icon: "🎶",
    colorClass: "from-indigo-500/10 to-indigo-600/20 border-indigo-500/40 text-indigo-300 hover:bg-indigo-500/20",
    actionType: "reveal_family"
  },
  {
    name: "Gale Flush Winds",
    description: "Swaps the current target bird with another random bird from the deck.",
    icon: "🍃",
    colorClass: "from-rose-500/10 to-rose-600/20 border-rose-500/40 text-rose-300 hover:bg-rose-500/20",
    actionType: "swap_options"
  },
  {
    name: "Field Battery Pack",
    description: "Gives you +1 charge for your Binoculars supply immediately.",
    icon: "⚡",
    colorClass: "from-yellow-400/10 to-yellow-500/20 border-yellow-400/40 text-yellow-300 hover:bg-yellow-400/20",
    actionType: "gain_binoculars"
  }
];

// Helper to draw random action cards
export function drawRandomActionCards(count: number): ActionCard[] {
  const cards: ActionCard[] = [];
  for (let i = 0; i < count; i++) {
    const template = ACTION_DECK[Math.floor(Math.random() * ACTION_DECK.length)];
    cards.push({
      ...template,
      id: `card_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`
    });
  }
  return cards;
}
