# iPad + GitHub Codespaces setup

Chrome on iPad is fine for GitHub Codespaces, but it does not make the iPad capable of running Node/Vite locally. The Node server runs inside Codespaces; the iPad only displays the browser editor and preview.

## Steps

1. Open GitHub in Safari or Chrome on the iPad.
2. Open the repository.
3. Tap **Code**.
4. Tap **Codespaces**.
5. Tap **Create codespace on main**.
6. Wait for setup.
7. Open the terminal and run:

```bash
npm run dev
```

8. Open the forwarded port labelled **Full game server** or port **3000**.

## Notes

- Add `GEMINI_API_KEY` in `.env.local` inside Codespaces.
- Do not commit `.env.local`.
- For local Windows play later, run the same command on the Windows PC and open its LAN IP on the iPad.
